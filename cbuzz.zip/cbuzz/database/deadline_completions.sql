-- Run this in your MySQL database: capstone_db

CREATE TABLE IF NOT EXISTS deadline_completions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    deadline_id INT NOT NULL,
    done_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uniq_user_deadline (user_id, deadline_id),
    INDEX idx_deadline_id (deadline_id),
    CONSTRAINT fk_deadline_completions_user
        FOREIGN KEY (user_id) REFERENCES users(id)
        ON DELETE CASCADE,
    CONSTRAINT fk_deadline_completions_deadline
        FOREIGN KEY (deadline_id) REFERENCES deadlines(id)
        ON DELETE CASCADE
);
