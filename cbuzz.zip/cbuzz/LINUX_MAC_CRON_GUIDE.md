# Linux/Mac Cron Job - Step-by-Step Guide

## Overview

This guide will help you set up automatic push notifications on Linux or Mac using cron jobs.

**Time needed:** 5 minutes
**Difficulty:** Easy

---

## What is Cron?

Cron is a task scheduler that runs commands at specified times. It's perfect for running the scheduler every 5 minutes.

---

## Step 1: Open Terminal

### On Mac:
1. Press `Cmd + Space`
2. Type: `Terminal`
3. Press `Enter`

### On Linux:
1. Press `Ctrl + Alt + T` (most distributions)
2. Or search for "Terminal" in applications

**Result:** Terminal window opens with a command prompt

---

## Step 2: Find PHP Path

First, find where PHP is installed:

```bash
which php
```

**Output example:**
```
/usr/bin/php
```

**Note:** Remember this path - you'll need it in the next step.

---

## Step 3: Edit Crontab

Type this command:

```bash
crontab -e
```

**What happens:**
- A text editor opens (usually nano or vi)
- You'll see existing cron jobs (if any)
- Cursor is ready for input

---

## Step 4: Add the Cron Job

Go to the **end of the file** and add this line:

```bash
*/5 * * * * /usr/bin/php /var/www/html/cbuzz/api/scheduler.php >> /var/www/html/cbuzz/logs/cron.log 2>&1
```

**Explanation of each part:**
- `*/5` = Every 5 minutes
- `* * * *` = Every hour, every day, every month, every day of week
- `/usr/bin/php` = Path to PHP (use your path from Step 2)
- `/var/www/html/cbuzz/api/scheduler.php` = Path to scheduler script
- `>> /var/www/html/cbuzz/logs/cron.log 2>&1` = Log output to file

**Adjust paths if needed:**
- If your web root is different, update `/var/www/html/cbuzz/`
- If PHP is at different location, update `/usr/bin/php`

---

## Step 5: Save and Exit

### If using nano editor:
1. Press `Ctrl + X`
2. Press `Y` (for yes)
3. Press `Enter` to confirm filename

### If using vi editor:
1. Press `Esc`
2. Type: `:wq`
3. Press `Enter`

**Result:** You're back at the terminal prompt

---

## Step 6: Verify the Cron Job

List all your cron jobs:

```bash
crontab -l
```

**Expected output:**
```
*/5 * * * * /usr/bin/php /var/www/html/cbuzz/api/scheduler.php >> /var/www/html/cbuzz/logs/cron.log 2>&1
```

If you see your line, it's installed correctly!

---

## Step 7: Wait and Check Logs

Wait 5-10 minutes, then check if the cron job ran:

```bash
tail -f /var/www/html/cbuzz/logs/cron.log
```

**Expected output:**
```
[2026-03-01 22:45:00] === Scheduler Started ===
[2026-03-01 22:45:00] Current time: 2026-03-01 22:45:00
[2026-03-01 22:45:03] === Scheduler Completed ===
[2026-03-01 22:50:00] === Scheduler Started ===
[2026-03-01 22:50:00] Current time: 2026-03-01 22:50:00
[2026-03-01 22:50:03] === Scheduler Completed ===
```

Press `Ctrl + C` to stop watching the log.

---

## Step 8: Test with a Deadline

1. Log in to admin dashboard: `http://localhost/cbuzz/admin/dashboard.php`
2. Create a new deadline for **35 minutes from now**
3. Wait 5 minutes
4. Check logs again - you should see the reminder being sent
5. Check your device for a notification

---

## Troubleshooting

### Cron job doesn't run

**Check if cron service is running:**

```bash
# On macOS
sudo launchctl list | grep cron

# On Linux
sudo service cron status
```

**If not running, start it:**

```bash
# On macOS
sudo launchctl start com.vixie.cron

# On Linux
sudo service cron start
```

### Cron job runs but nothing happens

**Check the scheduler logs:**

```bash
tail -f /var/www/html/cbuzz/logs/scheduler.log
```

**Test PHP manually:**

```bash
/usr/bin/php /var/www/html/cbuzz/api/scheduler.php
```

**Check if PHP can access the database:**

```bash
/usr/bin/php -r "include '/var/www/html/cbuzz/config/db.php'; echo 'Database connected';"
```

### Permission denied error

**Make script executable:**

```bash
chmod +x /var/www/html/cbuzz/api/scheduler.php
```

**Make logs directory writable:**

```bash
chmod 777 /var/www/html/cbuzz/logs
```

### PHP not found error

**Find correct PHP path:**

```bash
which php
```

**Update crontab with correct path:**

```bash
crontab -e
```

Replace `/usr/bin/php` with the path from `which php`

### Cron logs not being created

**Check if logs directory exists:**

```bash
ls -la /var/www/html/cbuzz/logs/
```

**If not, create it:**

```bash
mkdir -p /var/www/html/cbuzz/logs
chmod 777 /var/www/html/cbuzz/logs
```

---

## Common Cron Schedules

| Schedule | Cron Expression |
|----------|-----------------|
| Every minute | `* * * * *` |
| Every 5 minutes | `*/5 * * * *` |
| Every 10 minutes | `*/10 * * * *` |
| Every 30 minutes | `*/30 * * * *` |
| Every hour | `0 * * * *` |
| Every day at 9 AM | `0 9 * * *` |
| Every Monday at 9 AM | `0 9 * * 1` |
| Every day at midnight | `0 0 * * *` |

---

## Cron Syntax Explained

```
*/5 * * * * /path/to/command
│   │ │ │ │
│   │ │ │ └─── Day of week (0-6, 0=Sunday)
│   │ │ └───── Month (1-12)
│   │ └─────── Day of month (1-31)
│   └───────── Hour (0-23)
└───────────── Minute (0-59)
```

**Special characters:**
- `*` = Any value
- `*/5` = Every 5 units
- `0,15,30,45` = Specific values
- `1-5` = Range

---

## View Cron Logs

### On macOS:
```bash
log stream --predicate 'process == "cron"'
```

### On Linux:
```bash
grep CRON /var/log/syslog
```

Or:
```bash
journalctl -u cron
```

---

## Edit or Remove Cron Job

### Edit existing cron job:
```bash
crontab -e
```

### Remove all cron jobs:
```bash
crontab -r
```

### Remove specific cron job:
```bash
crontab -e
```
Then delete the line and save.

---

## Verify Everything Works

### Checklist:
- [ ] Terminal opened successfully
- [ ] Found PHP path with `which php`
- [ ] Edited crontab with `crontab -e`
- [ ] Added cron job line
- [ ] Saved and exited editor
- [ ] Verified with `crontab -l`
- [ ] Waited 5-10 minutes
- [ ] Checked logs with `tail -f`
- [ ] Saw scheduler execution logs
- [ ] Created test deadline
- [ ] Received notification after 5 minutes

---

## Next Steps

1. ✅ Cron job is set up
2. Create deadlines in admin panel
3. Wait for automatic notifications
4. Monitor logs to ensure everything works

---

## Quick Reference

| Command | Purpose |
|---------|---------|
| `which php` | Find PHP path |
| `crontab -e` | Edit cron jobs |
| `crontab -l` | List cron jobs |
| `crontab -r` | Remove all cron jobs |
| `tail -f /var/www/html/cbuzz/logs/cron.log` | Watch logs |
| `sudo service cron status` | Check cron service (Linux) |

---

## Cron Job Template

Copy and paste this, then adjust paths:

```bash
*/5 * * * * /usr/bin/php /var/www/html/cbuzz/api/scheduler.php >> /var/www/html/cbuzz/logs/cron.log 2>&1
```

**Adjust:**
- `/usr/bin/php` → Your PHP path (from `which php`)
- `/var/www/html/cbuzz/` → Your web root path

---

## Support

**Something not working?**

1. Check logs: `tail -f /var/www/html/cbuzz/logs/scheduler.log`
2. Run diagnostics: `http://localhost/cbuzz/api/diagnose_push.php`
3. Test manually: `/usr/bin/php /var/www/html/cbuzz/api/scheduler.php`
4. Check admin panel: `http://localhost/cbuzz/admin/scheduler.php`
5. Verify cron is running: `sudo service cron status`
