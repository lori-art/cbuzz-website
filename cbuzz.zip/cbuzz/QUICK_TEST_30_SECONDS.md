# Quick Testing Guide - 30 Second Reminders

## Easy Testing Setup

I've added a **30-second reminder window** so you can test push notifications easily without waiting 24 hours!

## How to Test

### Step 1: Create a Test Deadline
1. Log in as admin: `http://localhost/cbuzz/admin/dashboard.php`
2. Click "Add Deadline"
3. Fill in:
   - **Title:** "Test Deadline"
   - **Description:** "This is a test"
   - **Deadline:** Set to **30 seconds from now**
   - Example: If it's 3:45:00 PM, set deadline to 3:45:30 PM
4. Click "Save"

### Step 2: Open Student Dashboard
1. Log in as student: `http://localhost/cbuzz/student/dashboard.php`
2. Allow notifications when prompted
3. Wait for "Push: Connected" status (bottom-right, green)
4. Open browser console: Press `F12` → Go to **Console** tab

### Step 3: Wait for Notification
1. Keep the dashboard open
2. Wait 30 seconds
3. You should see in console:
   ```
   Checking for reminders in background...
   Reminder check result: {ok: true, sent: 1, triggered: 1, ...}
   ```
4. **You should receive a push notification!** 🎉

### Step 4: Verify
- Check your device/browser for the notification
- It should say: "Deadline Reminder - Test Deadline is due in 30s."

## Reminder Schedule (Updated)

| Reminder | Time Before Deadline |
|----------|---------------------|
| 30s | 30 seconds (NEW - for testing!) |
| 24h | 24 hours |
| 12h | 12 hours |
| 1h | 1 hour |
| 30m | 30 minutes |

## Troubleshooting

### No notification received?

1. **Check console logs:**
   - Should show "Checking for reminders in background..."
   - Should show "Reminder check result: {ok: true, sent: 1, ...}"

2. **Check if device is registered:**
   - Should see "Push: Connected" in green (bottom-right)

3. **Check if deadline exists:**
   - Go to admin dashboard
   - Verify deadline was created
   - Check deadline time is correct

4. **Check logs:**
   - Visit: `http://localhost/cbuzz/admin/scheduler.php`
   - Should show recent reminders sent

5. **Run diagnostics:**
   - Visit: `http://localhost/cbuzz/api/diagnose_push.php`
   - All items should be green/true

### Notification shows but says "30s"?

That's correct! The 30-second reminder is working. Once you verify it works, you can:
- Remove the 30s reminder from production
- Or keep it for easy testing

## Remove 30-Second Reminder (When Done Testing)

Edit `api/check_reminders.php` and remove the "30s" line:

```php
$reminders = $isTestMode
    ? ["30s_test" => 30]
    : [
        // "30s" => 30,        // Remove this line when done testing
        "24h" => 86400,
        "12h" => 43200,
        "1h" => 3600,
        "30m" => 1800
    ];
```

## Quick Test Checklist

- [ ] Created test deadline for 30 seconds from now
- [ ] Logged in to student dashboard
- [ ] Allowed notifications
- [ ] See "Push: Connected" status
- [ ] Opened browser console (F12)
- [ ] Waited 30 seconds
- [ ] Saw "Checking for reminders in background..." in console
- [ ] Saw "Reminder check result: {ok: true, sent: 1, ...}" in console
- [ ] Received push notification on device
- [ ] Notification says "Test Deadline is due in 30s."

## Next Steps

Once testing is complete:

1. **Remove 30-second reminder** from production (optional)
2. **Set up scheduler** to run automatically (Windows Task Scheduler or cron)
3. **Create real deadlines** with actual times
4. **Enjoy automatic notifications!** 🎉

## Support

If something doesn't work:

1. Check browser console (F12)
2. Check logs: `logs/reminders.log`
3. Run diagnostics: `http://localhost/cbuzz/api/diagnose_push.php`
4. Check admin panel: `http://localhost/cbuzz/admin/scheduler.php`
