# Scheduler Setup - Complete Documentation

## 📚 Documentation Files

I've created comprehensive guides for setting up the scheduler on all platforms:

### Main Guides

1. **SCHEDULER_SETUP_COMPLETE.md** ← **START HERE**
   - Overview of all setup options
   - Quick summary
   - Verification checklist
   - Troubleshooting

2. **WINDOWS_TASK_SCHEDULER_GUIDE.md**
   - Step-by-step Windows setup
   - Visual descriptions
   - Screenshots descriptions
   - Troubleshooting for Windows

3. **LINUX_MAC_CRON_GUIDE.md**
   - Step-by-step Linux/Mac setup
   - Terminal commands
   - Cron syntax explained
   - Troubleshooting for Linux/Mac

4. **SCHEDULER_INSTALLATION.md**
   - Detailed installation guide
   - Common cron schedules
   - Quick reference
   - Support information

---

## 🚀 Quick Start

### For Windows Users:
1. Open: **WINDOWS_TASK_SCHEDULER_GUIDE.md**
2. Follow steps 1-11
3. Time: ~10 minutes

### For Mac/Linux Users:
1. Open: **LINUX_MAC_CRON_GUIDE.md**
2. Follow steps 1-8
3. Time: ~5 minutes

---

## 📋 What Each Guide Covers

### WINDOWS_TASK_SCHEDULER_GUIDE.md
- ✅ How to open Task Scheduler
- ✅ Creating a new task
- ✅ Setting up triggers (every 5 minutes)
- ✅ Configuring the program to run
- ✅ Advanced settings
- ✅ Verification steps
- ✅ Troubleshooting

### LINUX_MAC_CRON_GUIDE.md
- ✅ Opening Terminal
- ✅ Finding PHP path
- ✅ Editing crontab
- ✅ Adding cron job
- ✅ Saving and exiting
- ✅ Verification steps
- ✅ Troubleshooting
- ✅ Cron syntax explained

### SCHEDULER_INSTALLATION.md
- ✅ Detailed Windows setup
- ✅ Detailed Linux/Mac setup
- ✅ Common cron schedules
- ✅ Verification methods
- ✅ Troubleshooting guide
- ✅ Quick reference table

---

## 🎯 Setup Summary

### Windows
```
Program: C:\xampp\php\php.exe
Arguments: C:\xampp\htdocs\cbuzz\api\scheduler.php
Frequency: Every 5 minutes
Run whether user is logged in: Yes
```

### Linux/Mac
```
Command: */5 * * * * /usr/bin/php /var/www/html/cbuzz/api/scheduler.php >> /var/www/html/cbuzz/logs/cron.log 2>&1
Frequency: Every 5 minutes
```

---

## ✅ Verification Steps

After setup, verify it works:

1. **Check logs:**
   - Windows: `C:\xampp\htdocs\cbuzz\logs\scheduler.log`
   - Linux/Mac: `/var/www/html/cbuzz/logs/scheduler.log`

2. **Run manually:**
   - Windows: `C:\xampp\php\php.exe C:\xampp\htdocs\cbuzz\api\scheduler.php`
   - Linux/Mac: `/usr/bin/php /var/www/html/cbuzz/api/scheduler.php`

3. **Check admin panel:**
   - Visit: `http://localhost/cbuzz/admin/scheduler.php`

4. **Test with deadline:**
   - Create deadline for 35 minutes from now
   - Wait 5 minutes
   - Check for notification

---

## 🔍 Troubleshooting Quick Reference

| Problem | Windows Solution | Linux/Mac Solution |
|---------|------------------|-------------------|
| Doesn't run | Check "Run whether user is logged in" | Check cron service status |
| Nothing happens | Check logs, verify database | Check logs, verify PHP path |
| Permission denied | Run as admin | `chmod +x scheduler.php` |
| PHP not found | Verify PHP path | `which php` to find path |
| No notifications | Verify device registered | Verify device registered |

---

## 📞 Support Resources

| Resource | Purpose |
|----------|---------|
| `SCHEDULER_SETUP_COMPLETE.md` | Overview and quick start |
| `WINDOWS_TASK_SCHEDULER_GUIDE.md` | Windows detailed guide |
| `LINUX_MAC_CRON_GUIDE.md` | Linux/Mac detailed guide |
| `SCHEDULER_INSTALLATION.md` | Technical reference |
| `http://localhost/cbuzz/admin/scheduler.php` | Admin panel |
| `http://localhost/cbuzz/api/diagnose_push.php` | System diagnostics |

---

## 🎓 Learning Resources

### Understanding Cron (Linux/Mac)
- `*/5` = Every 5 minutes
- `* * * *` = Every hour, day, month, day of week
- `>> file.log 2>&1` = Log output to file

### Understanding Task Scheduler (Windows)
- Trigger = When to run
- Action = What to run
- Conditions = Additional requirements
- Settings = Advanced options

---

## 📊 What Gets Installed

### Windows
- **Location:** Task Scheduler Library
- **Name:** Classbuzz Reminder Scheduler
- **Type:** Scheduled Task
- **Frequency:** Every 5 minutes

### Linux/Mac
- **Location:** User's crontab
- **Type:** Cron job
- **Frequency:** Every 5 minutes

---

## 🔄 How It Works

```
Every 5 Minutes:
  ↓
Scheduler runs
  ↓
Checks all deadlines
  ↓
Finds deadlines within reminder windows (24h, 12h, 1h, 30m)
  ↓
Sends push notifications to all registered devices
  ↓
Logs all activity
  ↓
Prevents duplicate reminders
```

---

## 📝 Reminder Schedule

| Reminder | Time Before Deadline |
|----------|---------------------|
| 1st | 24 hours |
| 2nd | 12 hours |
| 3rd | 1 hour |
| 4th | 30 minutes |

Each reminder is sent only once per deadline.

---

## 🎯 Next Steps

1. **Choose your platform:**
   - Windows → WINDOWS_TASK_SCHEDULER_GUIDE.md
   - Mac/Linux → LINUX_MAC_CRON_GUIDE.md

2. **Follow the setup guide** (10-15 minutes)

3. **Verify it works:**
   - Check logs
   - Run manually
   - Create test deadline
   - Receive notification

4. **Monitor regularly:**
   - Check admin panel
   - Review logs
   - Verify reminders are being sent

---

## ✨ Success Indicators

You'll know it's working when:

✅ Scheduler runs every 5 minutes (check logs)
✅ Reminders are triggered for upcoming deadlines
✅ Notifications appear on your device
✅ Admin panel shows recent reminders
✅ No errors in logs

---

## 📞 Getting Help

If you have issues:

1. **Check the appropriate guide:**
   - Windows: WINDOWS_TASK_SCHEDULER_GUIDE.md
   - Linux/Mac: LINUX_MAC_CRON_GUIDE.md

2. **Run diagnostics:**
   - `http://localhost/cbuzz/api/diagnose_push.php`

3. **Check logs:**
   - `logs/scheduler.log`

4. **Visit admin panel:**
   - `http://localhost/cbuzz/admin/scheduler.php`

5. **Test manually:**
   - Windows: `C:\xampp\php\php.exe C:\xampp\htdocs\cbuzz\api\scheduler.php`
   - Linux/Mac: `/usr/bin/php /var/www/html/cbuzz/api/scheduler.php`

---

## 🎉 You're Ready!

Everything is set up and documented. Choose your platform and follow the guide.

**Estimated time: 15-20 minutes**

After setup, your system will automatically send push notifications for upcoming deadlines without any further action needed!
