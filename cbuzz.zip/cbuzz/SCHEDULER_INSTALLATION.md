# How to Set Up Automatic Scheduler

## Windows Task Scheduler Setup

### Step 1: Open Task Scheduler

1. Press `Win + R` on your keyboard
2. Type `taskschd.msc` and press Enter
3. Task Scheduler window will open

### Step 2: Create a New Task

1. In the left panel, click on **"Task Scheduler Library"**
2. In the right panel, click **"Create Basic Task..."**
3. A dialog box will appear

### Step 3: Name Your Task

1. **Name:** `Classbuzz Reminder Scheduler`
2. **Description:** `Automatically sends push notifications for upcoming deadlines`
3. Click **"Next >"**

### Step 4: Set the Trigger (When to Run)

1. Select **"Daily"**
2. Click **"Next >"**
3. In the next screen:
   - **Start:** Set to today's date
   - **Recur every:** 1 day
   - Click **"Next >"**

### Step 5: Set Repeat Pattern

1. Click **"New..."** button
2. A "Repeat pattern" dialog will appear
3. Check the box: **"Repeat task every:"**
4. Set to: **5 minutes**
5. Duration: **For a duration of: 1 day** (or leave blank for indefinite)
6. Click **"OK"**
7. Click **"Next >"**

### Step 6: Set the Action (What to Run)

1. Select **"Start a program"**
2. Click **"Next >"**
3. Fill in the following:

   **Program/script:**
   ```
   C:\xampp\php\php.exe
   ```

   **Add arguments (optional):**
   ```
   C:\xampp\htdocs\cbuzz\api\scheduler.php
   ```

   **Start in (optional):**
   ```
   C:\xampp\htdocs\cbuzz
   ```

4. Click **"Next >"**

### Step 7: Review and Finish

1. Review all settings
2. Check the box: **"Open the Properties dialog for this task when I click Finish"**
3. Click **"Finish"**

### Step 8: Configure Advanced Settings

A Properties dialog will open. Go to the **"General"** tab:

1. Check: **"Run whether user is logged in or not"**
2. Check: **"Run with highest privileges"** (optional, for better reliability)
3. Go to **"Conditions"** tab:
   - Uncheck: **"Start the task only if the computer is on AC power"** (if you want it to run on battery)
4. Go to **"Settings"** tab:
   - Check: **"Allow task to be run on demand"**
   - Check: **"Run task as soon as possible after a scheduled start is missed"**
5. Click **"OK"**

### Step 9: Verify the Task

1. In Task Scheduler, find **"Classbuzz Reminder Scheduler"** in the list
2. Right-click it and select **"Run"** to test it
3. Check the logs: `C:\xampp\htdocs\cbuzz\logs\scheduler.log`
4. You should see entries like:
   ```
   [2026-03-01 22:45:00] === Scheduler Started ===
   [2026-03-01 22:45:00] Current time: 2026-03-01 22:45:00
   [2026-03-01 22:45:03] === Scheduler Completed ===
   ```

### Troubleshooting Windows Task Scheduler

**Task doesn't run automatically:**
- Right-click task → Properties → General → Check "Run whether user is logged in or not"
- Check if Task Scheduler service is running (Services.msc)

**Task runs but nothing happens:**
- Right-click task → View History to see errors
- Check logs: `C:\xampp\htdocs\cbuzz\logs\scheduler.log`
- Verify PHP path is correct: `C:\xampp\php\php.exe`

**Task runs but shows error:**
- Check if XAMPP is running
- Verify database connection in `config/db.php`
- Check if all required tables exist

---

## Linux/Mac Cron Job Setup

### Step 1: Open Terminal

1. Open Terminal application
2. You'll see a command prompt like: `user@computer:~$`

### Step 2: Edit Crontab

Type this command:
```bash
crontab -e
```

This will open the crontab editor (usually nano or vi).

### Step 3: Add the Cron Job

Add this line at the end of the file:

```bash
*/5 * * * * /usr/bin/php /var/www/html/cbuzz/api/scheduler.php >> /var/www/html/cbuzz/logs/cron.log 2>&1
```

**Explanation:**
- `*/5` = Every 5 minutes
- `* * * *` = Every hour, every day, every month, every day of week
- `/usr/bin/php` = Path to PHP executable
- `/var/www/html/cbuzz/api/scheduler.php` = Path to scheduler script
- `>> /var/www/html/cbuzz/logs/cron.log 2>&1` = Log output to file

### Step 4: Save and Exit

**If using nano editor:**
1. Press `Ctrl + X`
2. Press `Y` (for yes)
3. Press `Enter` to confirm filename

**If using vi editor:**
1. Press `Esc`
2. Type `:wq` and press `Enter`

### Step 5: Verify the Cron Job

Type this command to list your cron jobs:
```bash
crontab -l
```

You should see your new line:
```
*/5 * * * * /usr/bin/php /var/www/html/cbuzz/api/scheduler.php >> /var/www/html/cbuzz/logs/cron.log 2>&1
```

### Step 6: Check Logs

After a few minutes, check if the cron job is running:

```bash
tail -f /var/www/html/cbuzz/logs/cron.log
```

You should see output like:
```
[2026-03-01 22:45:00] === Scheduler Started ===
[2026-03-01 22:45:00] Current time: 2026-03-01 22:45:00
[2026-03-01 22:45:03] === Scheduler Completed ===
```

### Troubleshooting Linux/Mac Cron

**Cron job doesn't run:**
1. Check if cron service is running:
   ```bash
   sudo service cron status
   ```

2. Verify PHP path:
   ```bash
   which php
   ```
   Use the output path in your cron job

3. Check cron logs:
   ```bash
   # On macOS
   log stream --predicate 'process == "cron"'
   
   # On Linux
   grep CRON /var/log/syslog
   ```

**Cron job runs but nothing happens:**
1. Check scheduler logs:
   ```bash
   tail -f /var/www/html/cbuzz/logs/scheduler.log
   ```

2. Verify PHP can access the database:
   ```bash
   /usr/bin/php /var/www/html/cbuzz/api/scheduler.php
   ```

3. Check file permissions:
   ```bash
   chmod 755 /var/www/html/cbuzz/api/scheduler.php
   chmod 755 /var/www/html/cbuzz/logs
   ```

**Permission denied error:**
1. Make script executable:
   ```bash
   chmod +x /var/www/html/cbuzz/api/scheduler.php
   ```

2. Make logs directory writable:
   ```bash
   chmod 777 /var/www/html/cbuzz/logs
   ```

---

## Common Cron Schedules

| Schedule | Cron Expression |
|----------|-----------------|
| Every minute | `* * * * *` |
| Every 5 minutes | `*/5 * * * *` |
| Every 10 minutes | `*/10 * * * *` |
| Every 30 minutes | `*/30 * * * *` |
| Every hour | `0 * * * *` |
| Every day at 9 AM | `0 9 * * *` |
| Every Monday at 9 AM | `0 9 * * 1` |

---

## Verify It's Working

### Check Logs

**Windows:**
```
C:\xampp\htdocs\cbuzz\logs\scheduler.log
```

**Linux/Mac:**
```bash
tail -f /var/www/html/cbuzz/logs/scheduler.log
```

### Manual Test

**Windows (Command Prompt):**
```cmd
C:\xampp\php\php.exe C:\xampp\htdocs\cbuzz\api\scheduler.php
```

**Linux/Mac (Terminal):**
```bash
/usr/bin/php /var/www/html/cbuzz/api/scheduler.php
```

### Check Admin Panel

Visit: `http://localhost/cbuzz/admin/scheduler.php`

You should see:
- Recent reminders sent
- Scheduler logs
- Upcoming deadlines

---

## Quick Reference

### Windows Task Scheduler
- **Program:** `C:\xampp\php\php.exe`
- **Arguments:** `C:\xampp\htdocs\cbuzz\api\scheduler.php`
- **Frequency:** Every 5 minutes
- **Run whether user is logged in:** Yes

### Linux/Mac Cron
- **Command:** `*/5 * * * * /usr/bin/php /var/www/html/cbuzz/api/scheduler.php >> /var/www/html/cbuzz/logs/cron.log 2>&1`
- **Frequency:** Every 5 minutes

---

## Support

If you have issues:

1. **Check logs:**
   - Windows: `C:\xampp\htdocs\cbuzz\logs\scheduler.log`
   - Linux/Mac: `/var/www/html/cbuzz/logs/scheduler.log`

2. **Run diagnostics:**
   - Visit: `http://localhost/cbuzz/api/diagnose_push.php`

3. **Test manually:**
   - Windows: `C:\xampp\php\php.exe C:\xampp\htdocs\cbuzz\api\scheduler.php`
   - Linux/Mac: `/usr/bin/php /var/www/html/cbuzz/api/scheduler.php`

4. **Check admin panel:**
   - Visit: `http://localhost/cbuzz/admin/scheduler.php`
