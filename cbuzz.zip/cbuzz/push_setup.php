<?php
session_start();
include "config/db.php";

$isAdmin = isset($_SESSION['user']) && $_SESSION['user']['role'] === 'admin';
$isLoggedIn = isset($_SESSION['user']);
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Push Notifications Setup - Classbuzz</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Sora:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<style>
:root {
    --bg: #f4f6f8;
    --surface: #ffffff;
    --text: #1e2228;
    --muted: #5d6674;
    --brand: #cfa430;
    --ink: #101216;
    --line: #e6e9ef;
    --success: #2f7a46;
}
* { box-sizing: border-box; margin: 0; padding: 0; }
body {
    font-family: "Sora", sans-serif;
    background: var(--bg);
    color: var(--text);
    min-height: 100vh;
}
.container {
    max-width: 1000px;
    margin: 0 auto;
    padding: 40px 20px;
}
h1 {
    font-size: 32px;
    margin-bottom: 12px;
    color: var(--ink);
}
.subtitle {
    font-size: 16px;
    color: var(--muted);
    margin-bottom: 32px;
}
.grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
    gap: 20px;
    margin-bottom: 40px;
}
.card {
    background: var(--surface);
    border: 1px solid var(--line);
    border-radius: 12px;
    padding: 24px;
    text-decoration: none;
    color: inherit;
    transition: all 0.2s ease;
}
.card:hover {
    border-color: var(--brand);
    box-shadow: 0 8px 24px rgba(26, 38, 54, 0.1);
    transform: translateY(-2px);
}
.card h2 {
    font-size: 18px;
    margin-bottom: 8px;
    color: var(--ink);
}
.card p {
    font-size: 14px;
    color: var(--muted);
    line-height: 1.5;
}
.card .icon {
    font-size: 32px;
    margin-bottom: 12px;
}
.section {
    background: var(--surface);
    border: 1px solid var(--line);
    border-radius: 12px;
    padding: 24px;
    margin-bottom: 24px;
}
.section h2 {
    font-size: 20px;
    margin-bottom: 16px;
    padding-bottom: 12px;
    border-bottom: 1px solid var(--line);
}
.step {
    display: flex;
    gap: 16px;
    margin-bottom: 16px;
}
.step-number {
    background: var(--brand);
    color: #1f180a;
    width: 32px;
    height: 32px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: 700;
    flex-shrink: 0;
}
.step-content h3 {
    font-size: 14px;
    font-weight: 600;
    margin-bottom: 4px;
}
.step-content p {
    font-size: 13px;
    color: var(--muted);
}
.code {
    background: #f9fafb;
    border: 1px solid var(--line);
    border-radius: 6px;
    padding: 12px;
    font-family: monospace;
    font-size: 12px;
    overflow-x: auto;
    margin: 8px 0;
}
.btn {
    display: inline-block;
    padding: 10px 16px;
    background: var(--brand);
    color: #1f180a;
    border-radius: 8px;
    text-decoration: none;
    font-weight: 600;
    font-size: 14px;
    transition: background 0.2s ease;
}
.btn:hover {
    background: #b8932a;
}
.btn-secondary {
    background: var(--surface);
    border: 1px solid var(--line);
    color: var(--text);
}
.btn-secondary:hover {
    border-color: var(--brand);
}
.status {
    display: inline-block;
    padding: 4px 8px;
    border-radius: 4px;
    font-size: 12px;
    font-weight: 600;
}
.status-ok {
    background: #e7f7ec;
    color: var(--success);
}
.status-warning {
    background: #fff5db;
    color: #8f5e12;
}
.info-box {
    background: #e8f4f8;
    border-left: 4px solid #0288d1;
    padding: 12px;
    border-radius: 4px;
    margin-bottom: 16px;
    font-size: 13px;
    color: #01579b;
}
.disabled {
    opacity: 0.5;
    pointer-events: none;
}
</style>
</head>
<body>

<div class="container">
    <h1>🔔 Push Notifications Setup</h1>
    <p class="subtitle">Get automatic reminders for your upcoming deadlines</p>

    <div class="info-box">
        ℹ️ This page will guide you through setting up automatic push notifications. You'll receive reminders 24 hours, 12 hours, 1 hour, and 30 minutes before each deadline.
    </div>

    <div class="grid">
        <a href="api/setup_push.php" class="card">
            <div class="icon">⚙️</div>
            <h2>1. Setup Database</h2>
            <p>Create the required database tables for storing tokens and reminder logs.</p>
        </a>

        <a href="api/diagnose_push.php" class="card">
            <div class="icon">🔍</div>
            <h2>2. Run Diagnostics</h2>
            <p>Check if everything is configured correctly and test Firebase connectivity.</p>
        </a>

        <a href="student/dashboard.php" class="card">
            <div class="icon">📱</div>
            <h2>3. Enable Notifications</h2>
            <p>Log in and allow notifications. You'll see "Push: Connected" when ready.</p>
        </a>

        <?php if ($isAdmin): ?>
        <a href="admin/scheduler.php" class="card">
            <div class="icon">⏰</div>
            <h2>4. Manage Scheduler</h2>
            <p>View statistics, check reminders, and monitor scheduler logs.</p>
        </a>
        <?php endif; ?>

        <a href="PUSH_NOTIFICATIONS_QUICK_START.md" target="_blank" class="card">
            <div class="icon">📖</div>
            <h2>Quick Start Guide</h2>
            <p>Step-by-step instructions to get push notifications working.</p>
        </a>

        <a href="SCHEDULER_SETUP.md" target="_blank" class="card">
            <div class="icon">🛠️</div>
            <h2>Scheduler Setup</h2>
            <p>Detailed guide for setting up Windows Task Scheduler or cron jobs.</p>
        </a>
    </div>

    <div class="section">
        <h2>Quick Start (5 Minutes)</h2>
        <div class="step">
            <div class="step-number">1</div>
            <div class="step-content">
                <h3>Create Database Tables</h3>
                <p>Visit <a href="api/setup_push.php" style="color: var(--brand);">setup_push.php</a> to create the required tables.</p>
            </div>
        </div>
        <div class="step">
            <div class="step-number">2</div>
            <div class="step-content">
                <h3>Enable Notifications</h3>
                <p>Log in to <a href="student/dashboard.php" style="color: var(--brand);">student dashboard</a> and allow notifications. Wait for "Push: Connected" status.</p>
            </div>
        </div>
        <div class="step">
            <div class="step-number">3</div>
            <div class="step-content">
                <h3>Set Up Scheduler</h3>
                <p>Follow the <a href="SCHEDULER_SETUP.md" target="_blank" style="color: var(--brand);">scheduler setup guide</a> to enable automatic reminders.</p>
            </div>
        </div>
        <div class="step">
            <div class="step-number">4</div>
            <div class="step-content">
                <h3>Test It</h3>
                <p>Create a deadline and wait for automatic notifications (or manually visit <a href="api/check_reminders.php" style="color: var(--brand);">check_reminders.php</a>).</p>
            </div>
        </div>
    </div>

    <div class="section">
        <h2>How It Works</h2>
        <p style="margin-bottom: 16px;">Your system will automatically check for upcoming deadlines every 5 minutes and send notifications at these times:</p>
        <ul style="margin-left: 20px; margin-bottom: 16px;">
            <li><strong>24 hours</strong> before deadline</li>
            <li><strong>12 hours</strong> before deadline</li>
            <li><strong>1 hour</strong> before deadline</li>
            <li><strong>30 minutes</strong> before deadline</li>
        </ul>
        <p style="color: var(--muted);">Each reminder is sent only once per deadline to avoid duplicate notifications.</p>
    </div>

    <div class="section">
        <h2>Useful Links</h2>
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 12px;">
            <a href="api/setup_push.php" class="btn btn-secondary">Setup Database</a>
            <a href="api/diagnose_push.php" class="btn btn-secondary">Run Diagnostics</a>
            <a href="api/check_reminders.php" class="btn btn-secondary">Check Reminders Now</a>
            <?php if ($isAdmin): ?>
            <a href="admin/scheduler.php" class="btn btn-secondary">Scheduler Panel</a>
            <?php endif; ?>
            <a href="PUSH_NOTIFICATIONS_QUICK_START.md" target="_blank" class="btn btn-secondary">Quick Start</a>
            <a href="SCHEDULER_SETUP.md" target="_blank" class="btn btn-secondary">Setup Guide</a>
        </div>
    </div>

    <div class="section">
        <h2>Troubleshooting</h2>
        <p style="margin-bottom: 16px;"><strong>Not receiving notifications?</strong></p>
        <ul style="margin-left: 20px; margin-bottom: 16px;">
            <li>Check <a href="api/diagnose_push.php" style="color: var(--brand);">diagnostics page</a> for system status</li>
            <li>Verify you see "Push: Connected" on student dashboard</li>
            <li>Check browser console (F12) for errors</li>
            <li>Ensure scheduler is running (check logs/scheduler.log)</li>
            <li>Verify deadline is within reminder window</li>
        </ul>
        <p style="margin-bottom: 16px;"><strong>Need help?</strong></p>
        <ul style="margin-left: 20px;">
            <li>Read <a href="PUSH_NOTIFICATIONS_QUICK_START.md" target="_blank" style="color: var(--brand);">Quick Start Guide</a></li>
            <li>Check <a href="SCHEDULER_SETUP.md" target="_blank" style="color: var(--brand);">Scheduler Setup Guide</a></li>
            <li>View logs in <code>logs/</code> directory</li>
        </ul>
    </div>
</div>

</body>
</html>
