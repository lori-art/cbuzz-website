#!/usr/bin/env php
<?php
/**
 * Push Notifications Quick Test Script
 * Run from command line: php test_push.php
 */

echo "\n";
echo "╔════════════════════════════════════════════════════════════╗\n";
echo "║     Classbuzz Push Notifications - Quick Test Script       ║\n";
echo "╚════════════════════════════════════════════════════════════╝\n\n";

$baseUrl = "http://localhost/cbuzz";

// Test 1: Setup
echo "Step 1: Setting up database tables...\n";
$setupResponse = @file_get_contents("$baseUrl/api/setup_push.php");
if ($setupResponse) {
    $setupData = json_decode($setupResponse, true);
    if ($setupData['fcm_tokens_verified'] && $setupData['deadline_reminder_logs_verified']) {
        echo "✅ Database tables created successfully\n\n";
    } else {
        echo "❌ Database setup failed\n";
        echo json_encode($setupData, JSON_PRETTY_PRINT) . "\n\n";
    }
} else {
    echo "❌ Could not reach setup endpoint\n\n";
}

// Test 2: Diagnostics
echo "Step 2: Running diagnostics...\n";
$diagResponse = @file_get_contents("$baseUrl/api/diagnose_push.php");
if ($diagResponse) {
    $diagData = json_decode($diagResponse, true);
    
    echo "Database Status:\n";
    echo "  - fcm_tokens table: " . ($diagData['database']['fcm_tokens_exists'] ? "✅ Exists" : "❌ Missing") . "\n";
    echo "  - Registered tokens: " . ($diagData['database']['fcm_tokens_count'] ?? 0) . "\n";
    
    echo "\nService Account Status:\n";
    echo "  - File exists: " . ($diagData['service_account']['file_exists'] ? "✅ Yes" : "❌ No") . "\n";
    if ($diagData['service_account']['file_exists']) {
        echo "  - Valid JSON: " . ($diagData['service_account']['valid_json'] ? "✅ Yes" : "❌ No") . "\n";
        echo "  - Project ID: " . ($diagData['service_account']['project_id'] ?? 'N/A') . "\n";
    }
    
    echo "\nFCM Connectivity:\n";
    if (isset($diagData['fcm_connectivity']['oauth_success'])) {
        echo "  - OAuth: " . ($diagData['fcm_connectivity']['oauth_success'] ? "✅ Connected" : "❌ Failed") . "\n";
        if (isset($diagData['fcm_connectivity']['test_message_sent'])) {
            echo "  - Test message: " . ($diagData['fcm_connectivity']['test_message_sent'] ? "✅ Sent" : "❌ Failed") . "\n";
        }
    } else {
        echo "  - No tokens to test\n";
    }
    
    echo "\n";
} else {
    echo "❌ Could not reach diagnostic endpoint\n\n";
}

// Test 3: Send test notification
echo "Step 3: Sending test notification...\n";
$testResponse = @file_get_contents("$baseUrl/api/send_push.php?test=1");
if ($testResponse) {
    $testData = json_decode($testResponse, true);
    echo "  - Sent: " . ($testData['sent'] ?? 0) . "\n";
    echo "  - Failed: " . ($testData['failed'] ?? 0) . "\n";
    if ($testData['error']) {
        echo "  - Error: " . $testData['error'] . "\n";
    } else {
        echo "  - Status: ✅ Success\n";
    }
    echo "\n";
} else {
    echo "❌ Could not reach test endpoint\n\n";
}

echo "╔════════════════════════════════════════════════════════════╗\n";
echo "║                    Test Complete                           ║\n";
echo "╚═══════════════════════════════���════════════════════════════╝\n\n";

echo "Next steps:\n";
echo "1. Log in to http://localhost/cbuzz/student/dashboard.php\n";
echo "2. Watch for 'Push: Connected' status in bottom-right\n";
echo "3. Check browser console (F12) for detailed logs\n";
echo "4. Visit http://localhost/cbuzz/api/diagnose_push.php for full diagnostics\n\n";
?>
