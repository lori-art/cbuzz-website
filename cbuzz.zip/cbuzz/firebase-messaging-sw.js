importScripts("https://www.gstatic.com/firebasejs/10.12.0/firebase-app-compat.js");
importScripts("https://www.gstatic.com/firebasejs/10.12.0/firebase-messaging-compat.js");

firebase.initializeApp({
  apiKey: "AIzaSyCPhUXosh6YAmufvin64W2P9FC4ll46Psk",
  authDomain: "capstone-e841f.firebaseapp.com",
  projectId: "capstone-e841f",
  messagingSenderId: "358000455074",
  appId: "1:358000455074:web:23683661492484109a96fb",
});

const messaging = firebase.messaging();

messaging.onBackgroundMessage(function(payload) {
  console.log('[firebase-messaging-sw.js] Received background message:', payload);
  
  const notificationTitle = payload.notification?.title || 'Classbuzz';
  const notificationBody = payload.notification?.body || 'You have a new notification';
  const notificationData = payload.data || {};
  
  const options = {
    body: notificationBody,
    icon: '/cbuzz/images/classbuzz-logo.svg',
    badge: '/cbuzz/images/classbuzz-logo.svg',
    tag: 'classbuzz-notification',
    renotify: true,
    data: {
      url: notificationData.url || 'http://localhost:8012/cbuzz/auth/login.php'
    }
  };
  
  self.registration.showNotification(notificationTitle, options);
});

// Handle notification click
self.addEventListener('notificationclick', function(event) {
  console.log('[firebase-messaging-sw.js] Notification click:', event);
  event.notification.close();
  
  const urlToOpen = event.notification.data?.url || 'http://localhost:8012/cbuzz/auth/login.php';
  
  event.waitUntil(
    clients.matchAll({ type: 'window', includeUncontrolled: true })
      .then(function(clientList) {
        // If a window is already open, focus it
        for (const client of clientList) {
          if (client.url === urlToOpen && 'focus' in client) {
            return client.focus();
          }
        }
        // Otherwise open a new window
        if (clients.openWindow) {
          return clients.openWindow(urlToOpen);
        }
      })
  );
});
