<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Classbuzz - Track Your Deadlines</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Sora:wght@400;500;600;700;800&family=Source+Serif+4:wght@600;700&display=swap" rel="stylesheet">
<style>
    :root {
        --bg: #f4f6f8;
        --surface: #ffffff;
        --text: #1e2228;
        --muted: #5d6674;
        --brand: #cfa430;
        --brand-deep: #9f7d1d;
        --ink: #101216;
        --line: #e6e9ef;
    }

    * {
        box-sizing: border-box;
        margin: 0;
        padding: 0;
    }

    body {
        font-family: "Sora", sans-serif;
        background: radial-gradient(circle at 10% -10%, #fff7de 0%, var(--bg) 46%), var(--bg);
        color: var(--text);
        line-height: 1.6;
    }

    a {
        text-decoration: none;
    }

    nav {
        position: sticky;
        top: 0;
        z-index: 50;
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 16px 40px;
        background: rgba(255, 255, 255, 0.88);
        backdrop-filter: blur(8px);
        border-bottom: 1px solid var(--line);
    }

    .logo {
        display: flex;
        align-items: center;
        gap: 10px;
        color: var(--ink);
        font-weight: 700;
        font-size: 22px;
    }

    .logo img {
        width: 34px;
        height: 34px;
    }

    nav ul {
        list-style: none;
        display: flex;
        gap: 20px;
        align-items: center;
    }

    nav ul a {
        color: var(--ink);
        font-weight: 500;
        transition: color 0.2s ease;
    }

    nav ul a:hover {
        color: var(--brand-deep);
    }

    .nav-cta {
        background: var(--ink);
        color: #fff;
        padding: 10px 16px;
        border-radius: 999px;
    }

    .nav-cta:hover {
        color: #fff;
        background: #1b1e24;
    }

    .hero {
        max-width: 1180px;
        margin: 34px auto 24px;
        padding: 0 24px;
        display: grid;
        grid-template-columns: 1.15fr 0.85fr;
        gap: 26px;
    }

    .hero-copy {
        background: linear-gradient(120deg, #171a20 0%, #232834 100%);
        color: #fff;
        border-radius: 22px;
        padding: 42px;
        box-shadow: 0 16px 40px rgba(16, 18, 22, 0.18);
    }

    .eyebrow {
        color: #f0d184;
        letter-spacing: 0.12em;
        text-transform: uppercase;
        font-size: 12px;
        font-weight: 700;
    }

    .hero h1 {
        margin-top: 10px;
        font-family: "Source Serif 4", serif;
        font-size: clamp(2rem, 3vw, 3rem);
        line-height: 1.1;
    }

    .hero p {
        margin-top: 16px;
        color: #cdd3df;
        max-width: 60ch;
    }

    .hero-actions {
        margin-top: 26px;
        display: flex;
        flex-wrap: wrap;
        gap: 12px;
    }

    .btn {
        padding: 12px 18px;
        border-radius: 10px;
        font-weight: 600;
        display: inline-block;
    }

    .btn-primary {
        background: var(--brand);
        color: #18120a;
    }

    .btn-secondary {
        border: 1px solid #41495a;
        color: #f3f5f9;
    }

    .hero-stat {
        background: var(--surface);
        border: 1px solid var(--line);
        border-radius: 22px;
        padding: 28px;
        display: grid;
        gap: 16px;
        align-content: center;
    }

    .metric-row {
        display: flex;
        justify-content: space-between;
        align-items: baseline;
        padding-bottom: 14px;
        border-bottom: 1px dashed #d9dde5;
    }

    .metric-row:last-child {
        border-bottom: none;
        padding-bottom: 0;
    }

    .metric-row strong {
        font-size: 34px;
        color: var(--ink);
    }

    .features {
        max-width: 1180px;
        margin: 0 auto;
        padding: 14px 24px 62px;
    }

    .section-title {
        font-family: "Source Serif 4", serif;
        font-size: clamp(1.6rem, 2vw, 2.2rem);
        margin-bottom: 8px;
    }

    .section-sub {
        color: var(--muted);
        margin-bottom: 24px;
    }

    .features-grid {
        display: grid;
        grid-template-columns: repeat(3, 1fr);
        gap: 16px;
    }

    .feature-card {
        background: var(--surface);
        border: 1px solid var(--line);
        border-radius: 14px;
        padding: 18px;
    }

    .feature-card h3 {
        margin-bottom: 8px;
        color: var(--ink);
        font-size: 17px;
    }

    .feature-card p {
        color: var(--muted);
        font-size: 14px;
    }

    .reminder-section {
        background: linear-gradient(180deg, #fff 0%, #f7f9fc 100%);
        border: 1px solid var(--line);
        border-radius: 20px;
        padding: 32px;
        margin: 24px;
    }

    .reminder-list {
        display: flex;
        justify-content: center;
        gap: 24px;
        flex-wrap: wrap;
        margin-top: 20px;
    }

    .reminder-item {
        background: var(--surface);
        border: 1px solid var(--line);
        border-radius: 12px;
        padding: 16px 24px;
        text-align: center;
    }

    .reminder-item span {
        display: block;
        font-size: 24px;
        font-weight: 700;
        color: var(--brand);
    }

    .reminder-item small {
        color: var(--muted);
        font-size: 13px;
    }

    .cta {
        margin: 24px;
        background: linear-gradient(95deg, #12151b 0%, #222837 100%);
        border-radius: 18px;
        color: #f4f6fb;
        padding: 24px;
        display: flex;
        flex-wrap: wrap;
        justify-content: space-between;
        align-items: center;
        gap: 14px;
    }

    .cta p {
        color: #c4cbda;
    }

    footer {
        text-align: center;
        padding: 22px;
        color: #6c7482;
        font-size: 14px;
    }

    @media (max-width: 1024px) {
        .hero {
            grid-template-columns: 1fr;
        }

        .features-grid {
            grid-template-columns: 1fr 1fr;
        }

        .reminder-list {
            gap: 12px;
        }
    }

    @media (max-width: 760px) {
        nav {
            padding: 14px 16px;
            flex-direction: column;
            align-items: flex-start;
            gap: 12px;
        }

        nav ul {
            gap: 14px;
            flex-wrap: wrap;
        }

        .hero,
        .features,
        .reminder-section,
        .cta {
            padding-left: 16px;
            padding-right: 16px;
        }

        .hero-copy {
            padding: 26px 20px;
        }

        .features-grid {
            grid-template-columns: 1fr;
        }
    }
</style>
</head>
<body>

<nav>
    <a class="logo" href="index.php">
        <img src="images/classbuzz-logo.svg" alt="Classbuzz logo">
        <span>Classbuzz</span>
    </a>
    <ul>
        <li><a href="index.php">Home</a></li>
        <li><a href="about_us.php">About Us</a></li>
        <li><a class="nav-cta" href="auth/login.php">Login</a></li>
    </ul>
</nav>

<section class="hero">
    <div class="hero-copy">
        <div class="eyebrow">Student-first platform</div>
        <h1>Never Miss a Deadline Again</h1>
        <p>Classbuzz helps students stay on track with smart deadline reminders, easy task tracking, and clear progress visibility.</p>
        <div class="hero-actions">
            <a class="btn btn-primary" href="auth/register.php">Get Started Free</a>
            <a class="btn btn-secondary" href="about_us.php">Learn More</a>
        </div>
    </div>
    <aside class="hero-stat">
        <div class="metric-row">
            <span>Active learners</span>
            <strong>2,000+</strong>
        </div>
        <div class="metric-row">
            <span>Tasks tracked monthly</span>
            <strong>15k+</strong>
        </div>
        <div class="metric-row">
            <span>On-time submissions</span>
            <strong>94%</strong>
        </div>
    </aside>
</section>

<main class="features">
    <h2 class="section-title">Why Choose Classbuzz?</h2>
    <p class="section-sub">Everything you need to manage your deadlines effectively</p>

    <div class="features-grid">
        <article class="feature-card">
            <h3>🔔 Smart Reminders</h3>
            <p>Get notified at 24h, 12h, 1h, 30min, and even 30 seconds before your deadlines.</p>
        </article>
        <article class="feature-card">
            <h3>📊 Progress Tracking</h3>
            <p>Visualize your progress with completion rates and track your academic performance.</p>
        </article>
        <article class="feature-card">
            <h3>📅 Calendar View</h3>
            <p>See all your deadlines in a clean calendar view to plan your schedule effectively.</p>
        </article>
        <article class="feature-card">
            <h3>✅ Easy Completion</h3>
            <p>Mark tasks as done with just one click and track your achievements.</p>
        </article>
        <article class="feature-card">
            <h3>📧 Email Notifications</h3>
            <p>Receive email reminders in addition to push notifications for important deadlines.</p>
        </article>
        <article class="feature-card">
            <h3>🔒 Secure & Private</h3>
            <p>Your data is safe with secure authentication and privacy-focused design.</p>
        </article>
    </div>

    <div class="cta">
        <div>
            <h3>Ready to get organized?</h3>
            <p>Join thousands of students who never miss their deadlines.</p>
        </div>
        <a class="btn btn-primary" href="auth/register.php">Create Free Account</a>
    </div>
</main>

<footer>
    &copy; 2026 Classbuzz. All rights reserved.
</footer>

</body>
</html>
