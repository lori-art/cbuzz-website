# Windows Task Scheduler - Visual Step-by-Step Guide

## Overview

This guide will help you set up automatic push notifications on Windows using Task Scheduler.

**Time needed:** 10 minutes
**Difficulty:** Easy

---

## Step 1: Open Task Scheduler

### Method 1: Using Run Dialog (Fastest)
1. Press `Win + R` on your keyboard
2. Type: `taskschd.msc`
3. Press `Enter`

### Method 2: Using Search
1. Click Windows Start button
2. Type: `Task Scheduler`
3. Click on "Task Scheduler" in results

### Method 3: Using Control Panel
1. Open Control Panel
2. Go to Administrative Tools
3. Double-click Task Scheduler

**Result:** Task Scheduler window opens

---

## Step 2: Create a New Task

1. Look at the **right panel** (Actions)
2. Click **"Create Basic Task..."**

**Screenshot description:**
- Left panel shows "Task Scheduler Library"
- Right panel shows action buttons
- Click the one that says "Create Basic Task..."

---

## Step 3: Name Your Task

**Dialog: Create Basic Task**

Fill in:
- **Name:** `Classbuzz Reminder Scheduler`
- **Description:** `Automatically sends push notifications for upcoming deadlines`

Click **"Next >"**

---

## Step 4: Choose When to Run

**Dialog: Trigger**

1. Select **"Daily"**
2. Click **"Next >"**

**Next screen:**
- **Start:** Today's date (auto-filled)
- **Recur every:** 1 day
- Click **"Next >"**

---

## Step 5: Set Repeat Pattern

**Dialog: Daily**

1. Click **"New..."** button
2. **Repeat pattern dialog** opens

Fill in:
- Check: ☑ **"Repeat task every:"**
- Set to: **5** minutes
- Duration: Leave blank (or set to 1 day)

Click **"OK"**
Click **"Next >"**

---

## Step 6: Choose Action

**Dialog: Action**

1. Select **"Start a program"**
2. Click **"Next >"**

---

## Step 7: Configure Program

**Dialog: Start a Program**

Fill in these fields:

**Program/script:**
```
C:\xampp\php\php.exe
```

**Add arguments (optional):**
```
C:\xampp\htdocs\cbuzz\api\scheduler.php
```

**Start in (optional):**
```
C:\xampp\htdocs\cbuzz
```

Click **"Next >"**

---

## Step 8: Review Settings

**Dialog: Summary**

Review all your settings:
- ✓ Name: Classbuzz Reminder Scheduler
- ✓ Trigger: Daily, repeat every 5 minutes
- ✓ Action: Start C:\xampp\php\php.exe with arguments

Check: ☑ **"Open the Properties dialog for this task when I click Finish"**

Click **"Finish"**

---

## Step 9: Advanced Settings

**Dialog: Properties**

### General Tab
- ☑ **"Run whether user is logged in or not"** (IMPORTANT!)
- ☑ **"Run with highest privileges"** (optional)

### Conditions Tab
- ☐ Uncheck: "Start the task only if the computer is on AC power"

### Settings Tab
- ☑ **"Allow task to be run on demand"**
- ☑ **"Run task as soon as possible after a scheduled start is missed"**

Click **"OK"**

---

## Step 10: Verify It Works

### In Task Scheduler:
1. Find **"Classbuzz Reminder Scheduler"** in the list
2. Right-click it
3. Select **"Run"**
4. Status should change to "Running" then "Ready"

### Check the Logs:
1. Open File Explorer
2. Navigate to: `C:\xampp\htdocs\cbuzz\logs\`
3. Open: `scheduler.log`
4. You should see entries like:
   ```
   [2026-03-01 22:45:00] === Scheduler Started ===
   [2026-03-01 22:45:00] Current time: 2026-03-01 22:45:00
   [2026-03-01 22:45:03] === Scheduler Completed ===
   ```

---

## Step 11: Test with a Deadline

1. Log in to admin dashboard: `http://localhost/cbuzz/admin/dashboard.php`
2. Create a new deadline for **35 minutes from now**
3. Wait 5 minutes
4. Check logs again - you should see the reminder being sent
5. Check your device for a notification

---

## Troubleshooting

### Task doesn't run automatically

**Solution:**
1. Right-click the task → **Properties**
2. Go to **General** tab
3. Check: ☑ **"Run whether user is logged in or not"**
4. Click **OK**

### Task runs but nothing happens

**Solution:**
1. Right-click the task → **View History**
2. Look for error messages
3. Check logs: `C:\xampp\htdocs\cbuzz\logs\scheduler.log`

### "Access Denied" error

**Solution:**
1. Right-click the task → **Properties**
2. Go to **General** tab
3. Check: ☑ **"Run with highest privileges"**
4. Click **OK**

### PHP not found error

**Solution:**
1. Verify PHP path:
   - Open Command Prompt
   - Type: `C:\xampp\php\php.exe -v`
   - Should show PHP version
2. If error, update the path in Task Scheduler

### XAMPP not running

**Solution:**
1. Start XAMPP Control Panel
2. Click "Start" for Apache and MySQL
3. Wait for them to show "Running"
4. Then test the task

---

## Verify Everything Works

### Checklist:
- [ ] Task Scheduler opened successfully
- [ ] Created "Classbuzz Reminder Scheduler" task
- [ ] Set to run every 5 minutes
- [ ] Program: `C:\xampp\php\php.exe`
- [ ] Arguments: `C:\xampp\htdocs\cbuzz\api\scheduler.php`
- [ ] "Run whether user is logged in or not" is checked
- [ ] Task runs successfully when clicked manually
- [ ] Logs show successful execution
- [ ] Created test deadline
- [ ] Received notification after 5 minutes

---

## Next Steps

1. ✅ Task Scheduler is set up
2. Create deadlines in admin panel
3. Wait for automatic notifications
4. Monitor logs to ensure everything works

---

## Quick Reference

| Setting | Value |
|---------|-------|
| Task Name | Classbuzz Reminder Scheduler |
| Trigger | Daily, repeat every 5 minutes |
| Program | C:\xampp\php\php.exe |
| Arguments | C:\xampp\htdocs\cbuzz\api\scheduler.php |
| Run whether user logged in | Yes |
| Run with highest privileges | Yes (optional) |

---

## Support

**Something not working?**

1. Check logs: `C:\xampp\htdocs\cbuzz\logs\scheduler.log`
2. Run diagnostics: `http://localhost/cbuzz/api/diagnose_push.php`
3. Test manually: `C:\xampp\php\php.exe C:\xampp\htdocs\cbuzz\api\scheduler.php`
4. Check admin panel: `http://localhost/cbuzz/admin/scheduler.php`
