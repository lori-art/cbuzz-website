# Push Notifications Setup & Testing Guide

## Quick Start

### Step 1: Create Database Tables
Visit this URL in your browser to automatically create the required tables:
```
http://localhost/cbuzz/api/setup_push.php
```

You should see JSON output confirming the tables were created:
```json
{
  "timestamp": "2026-03-01 22:36:07",
  "tables_created": ["fcm_tokens", "deadline_reminder_logs"],
  "errors": [],
  "fcm_tokens_verified": true,
  "deadline_reminder_logs_verified": true
}
```

### Step 2: Verify Configuration
Visit this URL to run diagnostics:
```
http://localhost/cbuzz/api/diagnose_push.php
```

This will check:
- ✅ Database tables exist and have correct structure
- ✅ Service account JSON is valid
- ✅ Firebase OAuth connectivity
- ✅ FCM message delivery

### Step 3: Test Push Notifications
1. **Log in** to your student account at http://localhost/cbuzz/auth/login.php
2. **Open** the student dashboard at http://localhost/cbuzz/student/dashboard.php
3. **Watch** the bottom-right corner for the push status indicator
   - Should show "Push: Connected" in green
   - If it shows an error, check the browser console (F12 > Console tab)

### Step 4: Send a Test Notification
Visit this URL to send a test push notification:
```
http://localhost/cbuzz/api/send_push.php?test=1
```

You should see JSON output like:
```json
{
  "sent": 1,
  "failed": 0,
  "error": null
}
```

If you see `"sent": 1`, check your device for a notification!

## Troubleshooting

### Issue: "Push: Permission denied" (red status)
**Solution:** 
- Click the lock icon in your browser's address bar
- Find "Notifications" and change it to "Allow"
- Refresh the page

### Issue: "Push: No token" (red status)
**Solution:**
- Check browser console (F12 > Console)
- Look for errors about VAPID key or service worker
- Verify you're on HTTPS or localhost (required for push)

### Issue: "Push: Save failed" (red status)
**Solution:**
- Check browser console for the error message
- Common causes:
  - Not logged in (must be on authenticated page)
  - Database table doesn't exist (run setup_push.php)
  - Session not set properly

### Issue: Test sends but no notification appears
**Solution:**
- Check browser notification settings (OS level)
- On Windows: Check Focus Assist settings
- Verify notification permission is granted in browser
- Check if browser is in focus (background notifications may not show)

### Issue: Diagnostic shows "No FCM tokens registered"
**Solution:**
- Log in and open the student dashboard
- Wait 5 seconds for the token to be saved
- Refresh the diagnostic page

## Logs

Push notification logs are saved to:
- `logs/push_tokens.log` - Token save requests
- `logs/push_send.log` - Push send attempts

Check these files to debug issues:
```bash
# View token save logs
cat logs/push_tokens.log

# View push send logs
cat logs/push_send.log
```

## Manual Database Setup (if setup_push.php doesn't work)

If the automatic setup fails, run these SQL commands in phpMyAdmin:

```sql
CREATE TABLE IF NOT EXISTS fcm_tokens (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL UNIQUE,
    token VARCHAR(512) NOT NULL UNIQUE,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_fcm_tokens_user
        FOREIGN KEY (user_id) REFERENCES users(id)
        ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS deadline_reminder_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    deadline_id INT NOT NULL,
    reminder_type VARCHAR(20) NOT NULL,
    sent_count INT NOT NULL DEFAULT 0,
    failed_count INT NOT NULL DEFAULT 0,
    sent_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uniq_deadline_reminder (deadline_id, reminder_type),
    CONSTRAINT fk_deadline_reminder_logs_deadline
        FOREIGN KEY (deadline_id) REFERENCES deadlines(id)
        ON DELETE CASCADE
);
```

## How It Works

1. **Client (firebase.js)**
   - Requests notification permission
   - Registers service worker
   - Gets FCM token from Firebase
   - Sends token to backend

2. **Backend (save_token.php)**
   - Receives token from client
   - Stores in fcm_tokens table
   - Associates with logged-in user

3. **Scheduler (check_reminders.php)**
   - Runs periodically (via cron or manual trigger)
   - Checks for upcoming deadlines
   - Calls send_push_notifications for each deadline

4. **Sender (send_push.php)**
   - Gets OAuth token from service account
   - Sends message to FCM for each registered token
   - FCM delivers to user's device

5. **Service Worker (firebase-messaging-sw.js)**
   - Receives message from FCM
   - Shows notification on device

## Testing Reminders

To test the reminder system:

```
http://localhost/cbuzz/api/check_reminders.php?test=1
```

This will trigger reminders for deadlines due in 30 seconds (test mode).

Create a deadline with a time 30 seconds in the future, then visit the URL above to test.
