<?php
session_start();
include "../config/db.php";
include "../api/send_email.php";
include "../api/send_push.php";

if (!isset($_SESSION['user']) || $_SESSION['user']['role'] != 'student') {
    header("Location: ../auth/login.php");
    exit;
}

$studentName = isset($_SESSION['user']['name']) && $_SESSION['user']['name'] !== ''
    ? $_SESSION['user']['name']
    : 'Student';

$hour = (int)date('H');
$greeting = 'Hello';
if ($hour < 12) {
    $greeting = 'Good morning';
} elseif ($hour < 18) {
    $greeting = 'Good afternoon';
} else {
    $greeting = 'Good evening';
}

$view = isset($_GET['view']) ? $_GET['view'] : 'upcoming';
$allowedViews = ['all', 'upcoming', 'completed', 'past_due', 'new'];
if (!in_array($view, $allowedViews, true)) {
    $view = 'upcoming';
}

$studentId = isset($_SESSION['user']['id']) ? (int)$_SESSION['user']['id'] : 0;
if ($studentId <= 0 && isset($_SESSION['user']['email'])) {
    $safeEmail = $conn->real_escape_string($_SESSION['user']['email']);
    $userRes = $conn->query("SELECT id FROM users WHERE email='$safeEmail' LIMIT 1");
    if ($userRes && $userRes->num_rows > 0) {
        $studentId = (int)$userRes->fetch_assoc()['id'];
        $_SESSION['user']['id'] = $studentId;
    }
}

$res = $conn->query("
    SELECT
        d.*,
        CASE WHEN dc.id IS NULL THEN 0 ELSE 1 END AS is_done,
        dc.done_at
    FROM deadlines d
    LEFT JOIN deadline_completions dc
        ON dc.deadline_id = d.id
        AND dc.user_id = $studentId
    ORDER BY d.deadline_datetime ASC
");

$allDeadlines = [];
$counts = [
    'all' => 0,
    'upcoming' => 0,
    'completed' => 0,
    'past_due' => 0,
    'new' => 0
];

$nowTs = time();
$subjectStats = [];
while ($res && $row = $res->fetch_assoc()) {
    $deadlineTs = strtotime($row['deadline_datetime']);

    if ((int)$row['is_done'] === 1) {
        $state = 'completed';
    } elseif ($deadlineTs !== false && $deadlineTs < $nowTs) {
        $state = 'past_due';
    } else {
        $state = 'upcoming';
    }

    $row['state'] = $state;
    $allDeadlines[] = $row;

    $counts['all']++;
    $counts[$state]++;

    // Track subject progress
    $subject = trim($row['title']);
    if (!isset($subjectStats[$subject])) {
        $subjectStats[$subject] = ['total' => 0, 'completed' => 0];
    }
    $subjectStats[$subject]['total']++;
    if ($state === 'completed') {
        $subjectStats[$subject]['completed']++;
    }
}

$subjects = ['PEH 300', 'ICT LECTURE', 'ICT 400', 'PILOSOPHY', 'RESEARCH', 'ENTREPRENEUR', 'IMMERSION'];
$subjectFilter = isset($_GET['subject']) ? trim($_GET['subject']) : 'all';
if ($subjectFilter !== 'all' && !in_array($subjectFilter, $subjects, true) && $subjectFilter !== 'Other') {
    $subjectFilter = 'all';
}

$viewFilteredDeadlines = [];
foreach ($allDeadlines as $deadline) {
    if ($view === 'all' || $deadline['state'] === $view) {
        $viewFilteredDeadlines[] = $deadline;
    }
}

$subjectCounts = [];
foreach ($subjects as $subject) {
    $subjectCounts[$subject] = 0;
}
$subjectCounts['Other'] = 0;
foreach ($viewFilteredDeadlines as $deadline) {
    $subject = isset($deadline['title']) ? trim($deadline['title']) : '';
    if (isset($subjectCounts[$subject])) {
        $subjectCounts[$subject]++;
    } else {
        $subjectCounts['Other']++;
    }
}

$filteredDeadlines = [];
$newDeadlineIds = [];
$newRes = $conn->query("SELECT id FROM deadlines ORDER BY id DESC LIMIT 8");
if ($newRes) {
    while ($newRow = $newRes->fetch_assoc()) {
        $newDeadlineIds[] = (int)$newRow['id'];
    }
}
$counts['new'] = count($newDeadlineIds);

foreach ($viewFilteredDeadlines as $deadline) {
    $taskSubject = isset($deadline['title']) ? trim($deadline['title']) : '';
    $normalizedTaskSubject = in_array($taskSubject, $subjects, true) ? $taskSubject : 'Other';
    $isNew = in_array((int)$deadline['id'], $newDeadlineIds, true);
    $viewMatch = ($view === 'new') ? $isNew : true;
    if (($subjectFilter === 'all' || $subjectFilter === $normalizedTaskSubject) && $viewMatch) {
        $filteredDeadlines[] = $deadline;
    }
}

$subjectColumns = [];
foreach ($subjects as $subject) {
    $subjectColumns[$subject] = [];
}
$subjectColumns['Other'] = [];

foreach ($filteredDeadlines as $deadline) {
    $subject = isset($deadline['title']) ? trim($deadline['title']) : '';
    if (isset($subjectColumns[$subject])) {
        $subjectColumns[$subject][] = $deadline;
    } else {
        $subjectColumns['Other'][] = $deadline;
    }
}

$calendarStatusByDate = [];
$statusPriority = ['completed' => 1, 'upcoming' => 2, 'past_due' => 3];
foreach ($allDeadlines as $deadline) {
    $taskSubject = isset($deadline['title']) ? trim($deadline['title']) : '';
    $normalizedTaskSubject = in_array($taskSubject, $subjects, true) ? $taskSubject : 'Other';
    if ($subjectFilter !== 'all' && $subjectFilter !== $normalizedTaskSubject) {
        continue;
    }

    $dateKey = substr((string)$deadline['deadline_datetime'], 0, 10);
    if ($dateKey === '') {
        continue;
    }

    $state = isset($deadline['state']) ? $deadline['state'] : 'upcoming';
    if (!isset($statusPriority[$state])) {
        continue;
    }

    if (!isset($calendarStatusByDate[$dateKey])) {
        $calendarStatusByDate[$dateKey] = $state;
        continue;
    }

    $existingState = $calendarStatusByDate[$dateKey];
    if ($statusPriority[$state] > $statusPriority[$existingState]) {
        $calendarStatusByDate[$dateKey] = $state;
    }
}

// Calculate overall progress
$overallProgress = $counts['all'] > 0 ? round(($counts['completed'] / $counts['all']) * 100) : 0;

// Get upcoming deadlines count for next 24h
$upcoming24h = 0;
foreach ($allDeadlines as $d) {
    if ($d['state'] === 'upcoming') {
        $deadlineTs = strtotime($d['deadline_datetime']);
        if ($deadlineTs && $deadlineTs - $nowTs <= 86400) {
            $upcoming24h++;
        }
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Student Dashboard - Classbuzz</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Sora:wght@400;500;600;700;800&family=Source+Serif+4:wght@600;700&display=swap" rel="stylesheet">
<style>
:root {
    --bg: #f4f6f8;
    --surface: #ffffff;
    --text: #1e2228;
    --muted: #5d6674;
    --brand: #cfa430;
    --brand-deep: #9f7d1d;
    --ink: #101216;
    --line: #e6e9ef;
    --danger: #d94d4d;
    --success: #2f7a46;
}
* { box-sizing: border-box; margin: 0; padding: 0; }
body {
    font-family: "Sora", sans-serif;
    background: radial-gradient(circle at 10% -10%, #fff7de 0%, var(--bg) 46%), var(--bg);
    color: var(--text);
    min-height: 100vh;
}
a { text-decoration: none; }
.topbar {
    position: sticky;
    top: 0;
    z-index: 30;
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 14px 24px;
    background: rgba(255, 255, 255, 0.88);
    backdrop-filter: blur(8px);
    border-bottom: 1px solid var(--line);
}
.logo {
    display: flex;
    align-items: center;
    gap: 10px;
    color: var(--ink);
    font-weight: 700;
    font-size: 21px;
}
.logo img { width: 32px; height: 32px; }
.logout-btn {
    border: none;
    background: var(--danger);
    color: #fff;
    border-radius: 999px;
    padding: 9px 14px;
    cursor: pointer;
    font-weight: 600;
}
.topbar-right {
    display: flex;
    align-items: center;
    gap: 14px;
}
.datetime-wrap {
    display: flex;
    align-items: baseline;
    gap: 12px;
    color: #2f3339;
}
.datetime-time {
    font-size: 28px;
    font-weight: 700;
    line-height: 1;
    letter-spacing: 0.01em;
}
.datetime-date {
    font-size: 16px;
    color: #666c76;
    font-weight: 600;
    line-height: 1;
}
.layout {
    max-width: 1320px;
    margin: 18px auto;
    padding: 0 16px 24px;
    display: grid;
    grid-template-columns: 290px 1fr;
    gap: 18px;
}
.sidebar {
    background: var(--surface);
    border: 1px solid var(--line);
    border-radius: 16px;
    padding: 14px;
    align-self: start;
    position: sticky;
    top: 78px;
    max-height: calc(100vh - 96px);
    overflow-y: auto;
    box-shadow: 0 10px 22px rgba(30, 38, 53, 0.06);
}
.greeting {
    background: linear-gradient(120deg, #171a20 0%, #232834 100%);
    color: #fff;
    border-radius: 12px;
    padding: 12px;
    margin-bottom: 14px;
}
.greeting strong { display: block; font-size: 16px; }
.greeting span { color: #d4d9e7; font-size: 12px; }
.side-title {
    font-size: 11px;
    color: var(--muted);
    text-transform: uppercase;
    letter-spacing: 0.1em;
    margin: 12px 0 8px;
}
.side-links { display: grid; gap: 8px; }
.side-link {
    border: 1px solid var(--line);
    border-radius: 10px;
    padding: 9px 10px;
    color: #2d3440;
    font-size: 14px;
    font-weight: 600;
}
.side-link:hover { border-color: #dcc57f; }
.subject-dropdown-form { margin-top: 4px; }
.subject-dropdown {
    width: 100%;
    border: 1px solid var(--line);
    border-radius: 10px;
    padding: 9px 10px;
    font-family: inherit;
    font-size: 13px;
    color: #2d3440;
    background: #fff;
}
.calendar-widget {
    border: 1px solid #d8e5f7;
    border-radius: 14px;
    background: #fff;
    overflow: hidden;
}
.cal-head {
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 8px;
    padding: 10px;
    background: linear-gradient(90deg, #e9f5ff 0%, #edf3ff 100%);
    border-bottom: 1px solid #d8e5f7;
}
.cal-left { display: flex; align-items: center; gap: 8px; }
.cal-title { font-size: 13px; font-weight: 800; color: #2b3340; min-width: 112px; text-align: center; }
.cal-nav {
    border: 1px solid #bfd7f2;
    background: #f8fcff;
    border-radius: 8px;
    width: 30px;
    height: 30px;
    cursor: pointer;
}
.cal-view { display: flex; gap: 6px; align-items: center; }
.cal-pill {
    border: 1px solid #bcd7f7;
    background: #f7fbff;
    color: #2e76c9;
    border-radius: 999px;
    font-size: 11px;
    font-weight: 700;
    padding: 5px 10px;
}
.cal-pill.active { background: #1990e6; color: #fff; border-color: #1990e6; }
.cal-today {
    border: 1px solid #1990e6;
    background: #fff;
    color: #1990e6;
    border-radius: 10px;
    font-size: 11px;
    font-weight: 800;
    padding: 6px 9px;
    cursor: pointer;
}
.cal-weekdays, .cal-days {
    display: grid;
    grid-template-columns: repeat(7, 1fr);
    gap: 4px;
    padding: 8px 10px 0;
}
.cal-weekdays span { font-size: 10px; color: var(--muted); text-align: center; padding: 2px 0; font-weight: 700; }
.cal-day {
    border: 1px solid transparent;
    background: #fff;
    border-radius: 8px;
    height: 32px;
    font-size: 12px;
    cursor: pointer;
    color: #2e3745;
    position: relative;
}
.cal-day:hover { border-color: #b8d5f5; }
.cal-day.muted { color: #aab2bf; }
.cal-day.active {
    outline: 2px solid #2f80e7;
    border-color: #2f80e7;
    z-index: 2;
}
.cal-day.today { border-color: #cfd7e6; }
.cal-day.status-upcoming { background: #eaf3ff; border-color: #9fc1ee; color: #2c65bc; font-weight: 700; }
.cal-day.status-past_due { background: #ffecee; border-color: #edb0b5; color: #b43a3f; font-weight: 700; }
.cal-day.status-completed { background: #eaf9ef; border-color: #a8d9b6; color: #2f7c47; font-weight: 700; }
.cal-clear {
    margin: 8px 10px 10px;
    width: calc(100% - 20px);
    border: 1px solid #d8e3f2;
    background: #f9fbff;
    color: var(--muted);
    border-radius: 8px;
    padding: 7px;
    font-size: 12px;
    font-weight: 600;
    cursor: pointer;
}
.cal-legend {
    display: flex;
    gap: 10px;
    padding: 0 10px 8px;
    align-items: center;
    flex-wrap: wrap;
}
.cal-legend span {
    font-size: 10px;
    color: #4f5968;
    display: inline-flex;
    align-items: center;
    gap: 5px;
}
.dot {
    width: 8px;
    height: 8px;
    border-radius: 999px;
    display: inline-block;
}
.dot-red { background: #d86060; }
.dot-blue { background: #4f89d7; }
.dot-green { background: #3fa464; }
.main { display: grid; gap: 14px; }
.quick-overview {
    display: grid;
    grid-template-columns: repeat(4, minmax(0, 1fr));
    gap: 10px;
}
.overview-item {
    display: block;
    border: 1px solid var(--line);
    border-radius: 12px;
    background: #fff;
    padding: 10px;
}
.overview-item:hover {
    border-color: #d8c38a;
    box-shadow: 0 6px 16px rgba(26, 33, 45, 0.06);
}
.overview-item strong {
    display: block;
    font-size: 18px;
    color: #1f2735;
}
.overview-item span {
    font-size: 11px;
    color: var(--muted);
}
.progress-card {
    display: grid;
    grid-template-columns: 1fr auto;
    gap: 20px;
    align-items: center;
    background: linear-gradient(135deg, #fff 0%, #f8faf4 100%);
    border: 1px solid #d4dfb8;
    border-radius: 12px;
    padding: 16px;
}
.progress-info h3 {
    font-size: 14px;
    color: var(--ink);
    margin-bottom: 6px;
}
.progress-percentage {
    font-size: 32px;
    font-weight: 800;
    color: var(--success);
}
.progress-bar-container {
    width: 180px;
    height: 12px;
    background: #e8ebe4;
    border-radius: 999px;
    overflow: hidden;
    margin-top: 8px;
}
.progress-bar {
    height: 100%;
    background: linear-gradient(90deg, #4caf50 0%, #8bc34a 100%);
    border-radius: 999px;
    transition: width 0.5s ease;
}
.progress-stats {
    display: flex;
    gap: 16px;
    margin-top: 8px;
}
.progress-stat {
    font-size: 12px;
    color: var(--muted);
}
.progress-stat strong {
    color: var(--text);
}
.quick-stats {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 10px;
}
.stat-item {
    background: #fff;
    border: 1px solid var(--line);
    border-radius: 10px;
    padding: 12px;
    text-align: center;
}
.stat-item .number {
    font-size: 24px;
    font-weight: 800;
    color: var(--brand);
}
.stat-item .label {
    font-size: 11px;
    color: var(--muted);
    margin-top: 4px;
}
.row { display: grid; grid-template-columns: 1fr; gap: 14px; }
.card {
    background: var(--surface);
    border: 1px solid var(--line);
    border-radius: 16px;
    padding: 18px;
    box-shadow: 0 10px 24px rgba(24, 30, 43, 0.05);
}
.card h2 {
    font-family: "Source Serif 4", serif;
    font-size: 26px;
    margin-bottom: 4px;
}
.sub { color: var(--muted); font-size: 13px; margin-bottom: 12px; }
.filter-bar { display: flex; flex-wrap: wrap; gap: 8px; margin-bottom: 10px; }
.filter-chip {
    border: 1px solid var(--line);
    color: #2f3743;
    border-radius: 999px;
    padding: 6px 10px;
    font-size: 12px;
    font-weight: 700;
    cursor: pointer;
    transition: all 0.2s;
}
.filter-chip:hover { border-color: #d4c76a; }
.filter-chip.active {
    border-color: #dfc776;
    background: #fff8e2;
    color: #7c5c12;
}
.task-list { display: grid; gap: 8px; }
.task-scroll {
    max-height: 60vh;
    overflow-y: auto;
    padding-right: 6px;
}
.task-scroll::-webkit-scrollbar { width: 8px; }
.task-scroll::-webkit-scrollbar-thumb {
    background: #d6dce8;
    border-radius: 999px;
}
.task-scroll::-webkit-scrollbar-track { background: #f4f6fa; border-radius: 999px; }
.subject-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));
    gap: 12px;
}
.subject-col {
    border: 1px solid var(--line);
    border-radius: 12px;
    padding: 12px;
    background: #fbfcff;
}
.subject-col h3 {
    font-size: 13px;
    color: #273040;
    margin-bottom: 8px;
    display: flex;
    align-items: center;
    gap: 8px;
}
.subject-progress {
    font-size: 10px;
    background: #e8f5e9;
    color: #2e7d32;
    padding: 2px 6px;
    border-radius: 999px;
    font-weight: 600;
}
.task-item {
    border: 1px solid var(--line);
    border-left: 4px solid #d4b458;
    border-radius: 10px;
    padding: 10px;
    background: #fff;
    transition: transform 0.2s, box-shadow 0.2s;
}
.task-item:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(0,0,0,0.08);
}
.task-item[data-state="completed"] { border-left-color: #55a76a; background: #f8fcf9; }
.task-item[data-state="past_due"] { border-left-color: #d46363; background: #fff8f8; }
.task-head { display: flex; justify-content: space-between; gap: 10px; align-items: center; }
.task-title { font-size: 14px; font-weight: 700; color: #202734; }
.badge {
    border-radius: 999px;
    padding: 3px 8px;
    font-size: 11px;
    font-weight: 700;
}
.badge-upcoming { color: #8e6510; background: #fff5db; border: 1px solid #f3e0a7; }
.badge-completed { color: #2b7340; background: #e7f7ec; border: 1px solid #bfe7ca; }
.badge-past { color: #9a3333; background: #ffecec; border: 1px solid #f4caca; }
.task-desc { margin-top: 5px; color: #505968; font-size: 13px; }
.task-time { margin-top: 4px; color: var(--muted); font-size: 12px; display: flex; align-items: center; gap: 6px; }
.task-time .countdown {
    font-weight: 600;
    color: #d4a430;
}
.done-btn {
    margin-top: 8px;
    border: none;
    border-radius: 8px;
    background: var(--brand);
    color: #1f180a;
    font-weight: 700;
    font-family: inherit;
    font-size: 12px;
    padding: 7px 11px;
    cursor: pointer;
    transition: background 0.2s;
}
.done-btn:hover {
    background: var(--brand-deep);
}
.done-meta { margin-top: 7px; color: #3d8a54; font-size: 12px; font-weight: 600; }
.empty { font-size: 13px; color: var(--muted); padding: 8px; border: 1px dashed #cfd6e3; border-radius: 10px; text-align: center; }
.study-tip {
    background: linear-gradient(135deg, #fff8e1 0%, #fffde7 100%);
    border: 1px solid #ffe082;
    border-radius: 10px;
    padding: 12px;
    margin-top: 12px;
}
.study-tip h4 {
    font-size: 12px;
    color: #f57c00;
    margin-bottom: 4px;
}
.study-tip p {
    font-size: 12px;
    color: #795548;
}
@media (max-width: 980px) {
    .layout { grid-template-columns: 1fr; }
    .sidebar { position: static; }
    .row { grid-template-columns: 1fr; }
    .quick-overview { grid-template-columns: repeat(2, minmax(0, 1fr)); }
    .datetime-wrap { flex-direction: column; align-items: flex-end; gap: 2px; }
    .datetime-time { font-size: 22px; }
    .datetime-date { font-size: 13px; }
    .progress-card { grid-template-columns: 1fr; }
    .quick-stats { grid-template-columns: 1fr 1fr; }
}
@media (max-width: 1200px) {
    .layout { grid-template-columns: 270px 1fr; }
    .subject-grid { grid-template-columns: repeat(auto-fit, minmax(230px, 1fr)); }
}
</style>
</head>
<body>
<header class="topbar">
    <a class="logo" href="../index.php">
        <img src="../images/classbuzz-logo.svg" alt="Classbuzz logo">
        <span>Classbuzz</span>
    </a>
    <div class="topbar-right">
        <div class="datetime-wrap" aria-live="polite">
            <span class="datetime-time" id="liveTime">--:--</span>
            <span class="datetime-date" id="liveDate">--</span>
        </div>
        <button class="logout-btn" onclick="location.href='../auth/logout.php'">Logout</button>
    </div>
</header>

<div class="layout">
    <aside class="sidebar">
        <div class="greeting">
            <strong><?php echo htmlspecialchars($greeting . ', ' . $studentName); ?></strong>
            <span>Student dashboard</span>
        </div>

        <div class="side-title">Menu</div>
        <div class="side-links">
            <a class="side-link" href="dashboard.php">Dashboard</a>
            <a class="side-link" href="calendar.php">Calendar</a>
        </div>

        <div class="side-title">Subjects</div>
        <form class="subject-dropdown-form" method="GET">
            <input type="hidden" name="view" value="<?php echo htmlspecialchars($view); ?>">
            <select class="subject-dropdown" name="subject" onchange="this.form.submit()">
                <option value="all" <?php echo $subjectFilter === 'all' ? 'selected' : ''; ?>>
                    All Subjects (<?php echo count($viewFilteredDeadlines); ?>)
                </option>
                <?php foreach ($subjectCounts as $subjectName => $count): ?>
                    <option value="<?php echo htmlspecialchars($subjectName); ?>" <?php echo $subjectFilter === $subjectName ? 'selected' : ''; ?>>
                        <?php echo htmlspecialchars($subjectName); ?> (<?php echo (int)$count; ?>)
                    </option>
                <?php endforeach; ?>
            </select>
        </form>

        <div class="side-title">Calendar</div>
        <div class="calendar-widget" id="miniCalendar">
            <div class="cal-head">
                <div class="cal-left">
                    <button class="cal-nav" type="button" id="calPrev">&#8249;</button>
                    <div class="cal-title" id="calTitle"></div>
                    <button class="cal-nav" type="button" id="calNext">&#8250;</button>
                </div>
                <button class="cal-today" type="button" id="calToday">Today</button>
            </div>
            <div class="cal-weekdays">
                <span>Su</span><span>Mo</span><span>Tu</span><span>We</span><span>Th</span><span>Fr</span><span>Sa</span>
            </div>
            <div class="cal-days" id="calDays"></div>
            <div class="cal-legend">
                <span><i class="dot dot-red"></i>Due</span>
                <span><i class="dot dot-blue"></i>Upcoming</span>
                <span><i class="dot dot-green"></i>Done</span>
            </div>
            <button class="cal-clear" type="button" id="calClear">Show All</button>
        </div>

        <div class="study-tip">
            <h4>💡 Study Tip</h4>
            <p id="studyTip">Break your work into smaller tasks and take short breaks to stay focused!</p>
        </div>
    </aside>

    <main class="main" id="dashboard">
        <!-- Progress Card -->
        <div class="progress-card">
            <div class="progress-info">
                <h3>Your Progress</h3>
                <div class="progress-percentage"><?php echo $overallProgress; ?>%</div>
                <div class="progress-bar-container">
                    <div class="progress-bar" style="width: <?php echo $overallProgress; ?>%"></div>
                </div>
                <div class="progress-stats">
                    <span class="progress-stat"><strong><?php echo $counts['completed']; ?></strong> completed</span>
                    <span class="progress-stat"><strong><?php echo $counts['upcoming']; ?></strong> remaining</span>
                </div>
            </div>
            <div class="quick-stats">
                <div class="stat-item">
                    <div class="number"><?php echo $upcoming24h; ?></div>
                    <div class="label">Due in 24h</div>
                </div>
                <div class="stat-item">
                    <div class="number"><?php echo $counts['past_due']; ?></div>
                    <div class="label">Overdue</div>
                </div>
                <div class="stat-item">
                    <div class="number"><?php echo $counts['all']; ?></div>
                    <div class="label">Total Tasks</div>
                </div>
            </div>
        </div>

        <!-- Quick Overview -->
        <section class="quick-overview">
            <a class="overview-item" href="?view=upcoming&subject=<?php echo urlencode($subjectFilter); ?>">
                <strong><?php echo (int)$counts['upcoming']; ?></strong>
                <span>Upcoming</span>
            </a>
            <a class="overview-item" href="?view=completed&subject=<?php echo urlencode($subjectFilter); ?>">
                <strong><?php echo (int)$counts['completed']; ?></strong>
                <span>Completed</span>
            </a>
            <a class="overview-item" href="?view=past_due&subject=<?php echo urlencode($subjectFilter); ?>">
                <strong><?php echo (int)$counts['past_due']; ?></strong>
                <span>Past Due</span>
            </a>
            <a class="overview-item" href="?view=all&subject=all">
                <strong><?php echo htmlspecialchars($subjectFilter === 'all' ? 'All' : $subjectFilter); ?></strong>
                <span>Subject View</span>
            </a>
        </section>

        <section class="row">
            <section class="card">
                <h2>Tasks</h2>
                <p class="sub">Track your deadlines by subject and status.</p>

                <div class="filter-bar">
                    <a class="filter-chip <?php echo $view === 'all' ? 'active' : ''; ?>" href="?view=all&subject=<?php echo urlencode($subjectFilter); ?>">All (<?php echo (int)$counts['all']; ?>)</a>
                    <a class="filter-chip <?php echo $view === 'upcoming' ? 'active' : ''; ?>" href="?view=upcoming&subject=<?php echo urlencode($subjectFilter); ?>">Upcoming (<?php echo (int)$counts['upcoming']; ?>)</a>
                    <a class="filter-chip <?php echo $view === 'completed' ? 'active' : ''; ?>" href="?view=completed&subject=<?php echo urlencode($subjectFilter); ?>">Completed (<?php echo (int)$counts['completed']; ?>)</a>
                    <a class="filter-chip <?php echo $view === 'past_due' ? 'active' : ''; ?>" href="?view=past_due&subject=<?php echo urlencode($subjectFilter); ?>">Past Due (<?php echo (int)$counts['past_due']; ?>)</a>
                </div>

                <div class="task-scroll">
                <div class="subject-grid" id="taskList">
                    <?php if (count($filteredDeadlines) === 0): ?>
                        <div class="empty">No tasks found for this filter.</div>
                    <?php else: ?>
                        <?php foreach ($subjectColumns as $subject => $items): ?>
                            <?php if ($subjectFilter === 'all' && count($items) === 0) { continue; } ?>
                            <section class="subject-col">
                                <h3>
                                    <?php echo htmlspecialchars($subject); ?> 
                                    <?php 
                                    // Show progress for each subject
                                    if (isset($subjectStats[$subject])) {
                                        $subProgress = $subjectStats[$subject]['total'] > 0 
                                            ? round(($subjectStats[$subject]['completed'] / $subjectStats[$subject]['total']) * 100) 
                                            : 0;
                                        echo '<span class="subject-progress">' . $subProgress . '%</span>';
                                    }
                                    ?>
                                    (<?php echo count($items); ?>)
                                </h3>
                                <?php if (count($items) === 0): ?>
                                    <div class="empty">No tasks.</div>
                                <?php else: ?>
                                    <div class="task-list">
                                        <?php foreach ($items as $row): ?>
                                            <?php
                                            $badgeClass = 'badge-upcoming';
                                            $badgeText = 'Upcoming';
                                            if ($row['state'] === 'completed') {
                                                $badgeClass = 'badge-completed';
                                                $badgeText = 'Completed';
                                            } elseif ($row['state'] === 'past_due') {
                                                $badgeClass = 'badge-past';
                                                $badgeText = 'Past Due';
                                            }
                                            
                                            // Calculate time remaining
                                            $deadlineTs = strtotime($row['deadline_datetime']);
                                            $timeRemaining = '';
                                            if ($deadlineTs && $row['state'] === 'upcoming') {
                                                $diff = $deadlineTs - $nowTs;
                                                if ($diff > 0) {
                                                    if ($diff < 3600) {
                                                        $timeRemaining = round($diff/60) . 'm left';
                                                    } elseif ($diff < 86400) {
                                                        $timeRemaining = round($diff/3600) . 'h left';
                                                    } else {
                                                        $timeRemaining = round($diff/86400) . 'd left';
                                                    }
                                                }
                                            }
                                            ?>
                                            <article class="task-item" data-state="<?php echo htmlspecialchars($row['state']); ?>" data-date="<?php echo htmlspecialchars(substr($row['deadline_datetime'], 0, 10)); ?>">
                                                <div class="task-head">
                                                    <div class="task-title"><?php echo htmlspecialchars($row['title']); ?></div>
                                                    <span class="badge <?php echo $badgeClass; ?>"><?php echo $badgeText; ?></span>
                                                </div>
                                                <div class="task-desc">
                                                    <?php
                                                    $descText = isset($row['description']) ? trim($row['description']) : '';
                                                    echo $descText !== '' ? htmlspecialchars($descText) : 'No description provided.';
                                                    ?>
                                                </div>
                                                <div class="task-time">
                                                    <?php echo htmlspecialchars($row['deadline_datetime']); ?>
                                                    <?php if ($timeRemaining): ?>
                                                        <span class="countdown">⏱ <?php echo $timeRemaining; ?></span>
                                                    <?php endif; ?>
                                                </div>

                                                <?php if ((int)$row['is_done'] === 0): ?>
                                                    <form action="mark_done.php" method="POST">
                                                        <input type="hidden" name="deadline_id" value="<?php echo (int)$row['id']; ?>">
                                                        <button class="done-btn" type="submit">✓ Mark as Done</button>
                                                    </form>
                                                <?php else: ?>
                                                    <div class="done-meta">✓ Completed<?php echo !empty($row['done_at']) ? ' on ' . htmlspecialchars($row['done_at']) : ''; ?></div>
                                                <?php endif; ?>
                                            </article>
                                        <?php endforeach; ?>
                                    </div>
                                <?php endif; ?>
                            </section>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
                </div>
            </section>

        </section>
    </main>
</div>

<script>
function updateTopbarDateTime() {
    const liveTime = document.getElementById('liveTime');
    const liveDate = document.getElementById('liveDate');
    if (!liveTime || !liveDate) return;

    const nowDt = new Date();
    liveTime.textContent = nowDt.toLocaleTimeString('en-US', {
        hour: 'numeric',
        minute: '2-digit',
        hour12: true
    });
    liveDate.textContent = nowDt.toLocaleDateString('en-US', {
        weekday: 'long',
        month: 'long',
        day: 'numeric'
    });
}

updateTopbarDateTime();
setInterval(updateTopbarDateTime, 30000);

// Study tips rotation
const studyTips = [
    "Break your work into smaller tasks and take short breaks to stay focused!",
    "Review your notes within 24 hours of class to improve retention.",
    "Use the Pomodoro Technique: 25 minutes of work, 5 minutes of break.",
    "Stay hydrated! Drinking water helps maintain focus and energy.",
    "Take notes by hand - it helps you remember better than typing.",
    "Start with the most difficult task when you're fresh.",
    "Set specific goals for each study session.",
    "Teach what you learn to someone else - it reinforces understanding."
];

document.getElementById('studyTip').textContent = studyTips[Math.floor(Math.random() * studyTips.length)];

const taskItems = document.querySelectorAll('#taskList .task-item');
let selectedDate = '';
let viewYear;
let viewMonth;
const now = new Date();
viewYear = now.getFullYear();
viewMonth = now.getMonth();

const calTitle = document.getElementById('calTitle');
const calDays = document.getElementById('calDays');
const calPrev = document.getElementById('calPrev');
const calNext = document.getElementById('calNext');
const calClear = document.getElementById('calClear');
const calToday = document.getElementById('calToday');
const calendarStatusByDate = <?php echo json_encode($calendarStatusByDate); ?>;

function applyDateFilter() {
    taskItems.forEach((item) => {
        const itemDate = item.getAttribute('data-date');
        item.style.display = !selectedDate || selectedDate === itemDate ? '' : 'none';
    });
}

function formatDate(y, m, d) {
    const mm = String(m + 1).padStart(2, '0');
    const dd = String(d).padStart(2, '0');
    return `${y}-${mm}-${dd}`;
}

function renderCalendar() {
    calDays.innerHTML = '';
    const firstDay = new Date(viewYear, viewMonth, 1);
    const startWeekday = firstDay.getDay();
    const daysInMonth = new Date(viewYear, viewMonth + 1, 0).getDate();

    calTitle.textContent = firstDay.toLocaleString('en-US', { month: 'long', year: 'numeric' });

    for (let i = 0; i < startWeekday; i++) {
        const blank = document.createElement('button');
        blank.type = 'button';
        blank.className = 'cal-day muted';
        blank.disabled = true;
        blank.textContent = '';
        calDays.appendChild(blank);
    }

    const today = new Date();
    const todayStr = formatDate(today.getFullYear(), today.getMonth(), today.getDate());

    for (let d = 1; d <= daysInMonth; d++) {
        const btn = document.createElement('button');
        btn.type = 'button';
        btn.className = 'cal-day';
        const dateStr = formatDate(viewYear, viewMonth, d);
        btn.textContent = d;
        const status = calendarStatusByDate[dateStr];
        if (status === 'past_due') btn.classList.add('status-past_due');
        if (status === 'upcoming') btn.classList.add('status-upcoming');
        if (status === 'completed') btn.classList.add('status-completed');
        if (dateStr === selectedDate) btn.classList.add('active');
        if (dateStr === todayStr) btn.classList.add('today');
        btn.addEventListener('click', () => {
            selectedDate = dateStr;
            applyDateFilter();
            renderCalendar();
        });
        calDays.appendChild(btn);
    }
}

calPrev.addEventListener('click', () => {
    viewMonth--;
    if (viewMonth < 0) {
        viewMonth = 11;
        viewYear--;
    }
    renderCalendar();
});

calNext.addEventListener('click', () => {
    viewMonth++;
    if (viewMonth > 11) {
        viewMonth = 0;
        viewYear++;
    }
    renderCalendar();
});

calClear.addEventListener('click', () => {
    selectedDate = '';
    applyDateFilter();
    renderCalendar();
});

calToday.addEventListener('click', () => {
    const t = new Date();
    viewYear = t.getFullYear();
    viewMonth = t.getMonth();
    selectedDate = formatDate(viewYear, viewMonth, t.getDate());
    applyDateFilter();
    renderCalendar();
});

renderCalendar();
</script>

<!-- Background Reminder Checker -->
<script>
function checkRemindersInBackground() {
    console.log("Checking for reminders in background...");
    
    fetch("../api/check_reminders.php")
        .then(response => response.json())
        .then(data => {
            console.log("Reminder check result:", data);
            if (data.ok && data.sent > 0) {
                console.log("Reminders sent: " + data.sent);
            }
        })
        .catch(error => console.error("Error checking reminders:", error));
}

checkRemindersInBackground();
setInterval(checkRemindersInBackground, 300000);

document.addEventListener("visibilitychange", function() {
    if (!document.hidden) {
        console.log("Dashboard became visible, checking reminders...");
        checkRemindersInBackground();
    }
});
</script>

<script type="module" src="../firebase.js"></script>
</body>
</html>
