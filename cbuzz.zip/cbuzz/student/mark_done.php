<?php
session_start();
include "../config/db.php";

if (!isset($_SESSION['user']) || $_SESSION['user']['role'] != 'student') {
    header("Location: ../auth/login.php");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !isset($_POST['deadline_id'])) {
    header("Location: dashboard.php");
    exit;
}

$deadlineId = (int)$_POST['deadline_id'];
if ($deadlineId <= 0) {
    header("Location: dashboard.php");
    exit;
}

$studentId = isset($_SESSION['user']['id']) ? (int)$_SESSION['user']['id'] : 0;
if ($studentId <= 0 && isset($_SESSION['user']['email'])) {
    $safeEmail = $conn->real_escape_string($_SESSION['user']['email']);
    $userRes = $conn->query("SELECT id FROM users WHERE email='$safeEmail' LIMIT 1");
    if ($userRes && $userRes->num_rows > 0) {
        $studentId = (int)$userRes->fetch_assoc()['id'];
        $_SESSION['user']['id'] = $studentId;
    }
}

if ($studentId <= 0) {
    header("Location: dashboard.php");
    exit;
}

$deadlineCheck = $conn->prepare("SELECT id FROM deadlines WHERE id = ? LIMIT 1");
$deadlineCheck->bind_param("i", $deadlineId);
$deadlineCheck->execute();
$deadlineResult = $deadlineCheck->get_result();
if (!$deadlineResult || $deadlineResult->num_rows === 0) {
    header("Location: dashboard.php");
    exit;
}

$stmt = $conn->prepare("
    INSERT INTO deadline_completions (user_id, deadline_id, done_at)
    VALUES (?, ?, NOW())
    ON DUPLICATE KEY UPDATE done_at = VALUES(done_at)
");
$stmt->bind_param("ii", $studentId, $deadlineId);
$stmt->execute();

header("Location: dashboard.php");
exit;
?>
