<?php
/**
 * High-Frequency Scheduler for 30-Second Reminders
 * This script should run frequently for 30-second reminders to work
 */

set_time_limit(30);

$logDir = __DIR__ . '/../logs';
if (!is_dir($logDir)) {
    @mkdir($logDir, 0755, true);
}
$logFile = $logDir . '/scheduler_30s.log';

function log_message($message) {
    global $logFile;
    $timestamp = date('Y-m-d H:i:s');
    $entry = "[$timestamp] $message\n";
    @file_put_contents($logFile, $entry, FILE_APPEND);
}

$now = time();
$forceTestAll = isset($_GET['force_all']) && $_GET['force_all'] === '1';

$clickUrl = "http://localhost:8012/cbuzz/auth/login.php";

log_message("=== 30s Scheduler Started ===");
log_message("Current time: " . date('Y-m-d H:i:s', $now));

try {
    include __DIR__ . '/../config/db.php';
    include __DIR__ . '/send_push.php';
    
    $res = $conn->query("SELECT id, title, deadline_datetime FROM deadlines");
    if (!$res) {
        log_message("ERROR: Failed to fetch deadlines - " . $conn->error);
        exit(1);
    }
    
    $hasReminderLogsTable = false;
    $logsTableRes = $conn->query("SHOW TABLES LIKE 'deadline_reminder_logs'");
    if ($logsTableRes && $logsTableRes->num_rows > 0) {
        $hasReminderLogsTable = true;
    }
    
    $triggered = 0;
    $totalSent = 0;
    $totalFailed = 0;
    
    $reminders = ["30s" => 30];
    $tolerance30s = 15;
    
    while ($row = $res->fetch_assoc()) {
        $deadline = strtotime($row['deadline_datetime']);
        if ($deadline === false) {
            continue;
        }
        
        $diff = $deadline - $now;
        $deadlineId = (int)$row['id'];
        $title = htmlspecialchars($row['title']);
        
        foreach ($reminders as $label => $targetSeconds) {
            $isWithinWindow = abs($diff - $targetSeconds) <= $tolerance30s;
            $hasPassedTarget = ($diff <= $targetSeconds) && ($diff > $targetSeconds - 60);
            
            if ($isWithinWindow || $hasPassedTarget || $forceTestAll) {
                log_message("Deadline '$title' (ID: $deadlineId) - $label reminder");
                
                if ($hasReminderLogsTable && !$forceTestAll) {
                    $checkStmt = $conn->prepare("
                        SELECT id FROM deadline_reminder_logs
                        WHERE deadline_id = ? AND reminder_type = ?
                        LIMIT 1
                    ");
                    if ($checkStmt) {
                        $checkStmt->bind_param("is", $deadlineId, $label);
                        $checkStmt->execute();
                        $alreadySent = $checkStmt->get_result();
                        if ($alreadySent && $alreadySent->num_rows > 0) {
                            log_message("  → Already sent, skipping");
                            continue;
                        }
                    }
                }
                
                $secondsRemaining = $diff;
                if ($secondsRemaining < 0) {
                    $body = "$title is due now!";
                } else {
                    $body = "$title is due in $secondsRemaining seconds!";
                }
                log_message("  → Sending notification: $body");
                
                $result = send_push_notifications("DEADLINE ALERT!", $body, [
                    "deadline_id" => (string)$deadlineId,
                    "reminder_type" => $label
                ], $clickUrl);
                
                $sent = isset($result['sent']) ? (int)$result['sent'] : 0;
                $failed = isset($result['failed']) ? (int)$result['failed'] : 0;
                
                log_message("  → Sent: $sent, Failed: $failed");
                
                $triggered++;
                $totalSent += $sent;
                $totalFailed += $failed;
                
                if (isset($result['error']) && $result['error'] !== null) {
                    log_message("  → Error: " . $result['error']);
                }
                
                if ($hasReminderLogsTable) {
                    $logStmt = $conn->prepare("
                        INSERT IGNORE INTO deadline_reminder_logs (deadline_id, reminder_type, sent_count, failed_count, sent_at)
                        VALUES (?, ?, ?, ?, NOW())
                    ");
                    if ($logStmt) {
                        $logStmt->bind_param("isii", $deadlineId, $label, $sent, $failed);
                        $logStmt->execute();
                    }
                }
            }
        }
    }
    
    log_message("=== 30s Scheduler Completed ===");
    log_message("Triggered: $triggered, Sent: $totalSent, Failed: $totalFailed");
    
    header("Content-Type: application/json");
    echo json_encode([
        "ok" => true,
        "triggered" => $triggered,
        "sent" => $totalSent,
        "failed" => $totalFailed
    ]);
    
} catch (Exception $e) {
    log_message("EXCEPTION: " . $e->getMessage());
    exit(1);
}

exit(0);
?>
