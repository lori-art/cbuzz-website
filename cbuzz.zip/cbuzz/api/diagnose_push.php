<?php
session_start();
include __DIR__ . '/../config/db.php';

header('Content-Type: application/json');

$diagnostics = [
    'timestamp' => date('Y-m-d H:i:s'),
    'session_user' => isset($_SESSION['user']) ? [
        'id' => $_SESSION['user']['id'] ?? null,
        'email' => $_SESSION['user']['email'] ?? null,
        'role' => $_SESSION['user']['role'] ?? null
    ] : null,
    'database' => [],
    'service_account' => [],
    'fcm_connectivity' => []
];

// Check fcm_tokens table
$tableRes = $conn->query("SHOW TABLES LIKE 'fcm_tokens'");
if ($tableRes && $tableRes->num_rows > 0) {
    $diagnostics['database']['fcm_tokens_exists'] = true;
    
    // Get table structure
    $structRes = $conn->query("DESCRIBE fcm_tokens");
    $columns = [];
    while ($col = $structRes->fetch_assoc()) {
        $columns[] = $col['Field'];
    }
    $diagnostics['database']['fcm_tokens_columns'] = $columns;
    
    // Count tokens
    $countRes = $conn->query("SELECT COUNT(*) as cnt FROM fcm_tokens");
    $countRow = $countRes->fetch_assoc();
    $diagnostics['database']['fcm_tokens_count'] = (int)$countRow['cnt'];
    
    // Get current user's token if logged in
    if (isset($_SESSION['user']['id'])) {
        $userId = (int)$_SESSION['user']['id'];
        $userTokenRes = $conn->query("SELECT token FROM fcm_tokens WHERE user_id = $userId LIMIT 1");
        if ($userTokenRes && $userTokenRes->num_rows > 0) {
            $tokenRow = $userTokenRes->fetch_assoc();
            $diagnostics['database']['current_user_token'] = [
                'exists' => true,
                'token_length' => strlen($tokenRow['token']),
                'token_preview' => substr($tokenRow['token'], 0, 20) . '...'
            ];
        } else {
            $diagnostics['database']['current_user_token'] = ['exists' => false];
        }
    }
} else {
    $diagnostics['database']['fcm_tokens_exists'] = false;
    $diagnostics['database']['error'] = 'fcm_tokens table not found. Run: CREATE TABLE IF NOT EXISTS fcm_tokens (id INT AUTO_INCREMENT PRIMARY KEY, user_id INT NOT NULL UNIQUE, token VARCHAR(255) NOT NULL UNIQUE, updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP, CONSTRAINT fk_fcm_tokens_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE);';
}

// Check deadline_reminder_logs table
$logsRes = $conn->query("SHOW TABLES LIKE 'deadline_reminder_logs'");
$diagnostics['database']['deadline_reminder_logs_exists'] = $logsRes && $logsRes->num_rows > 0;

// Check service account
$serviceAccountPath = __DIR__ . '/../service-account.json';
if (file_exists($serviceAccountPath)) {
    $diagnostics['service_account']['file_exists'] = true;
    $serviceAccount = json_decode(file_get_contents($serviceAccountPath), true);
    if (is_array($serviceAccount)) {
        $diagnostics['service_account']['valid_json'] = true;
        $diagnostics['service_account']['project_id'] = $serviceAccount['project_id'] ?? null;
        $diagnostics['service_account']['client_email'] = $serviceAccount['client_email'] ?? null;
        $diagnostics['service_account']['has_private_key'] = !empty($serviceAccount['private_key']);
    } else {
        $diagnostics['service_account']['valid_json'] = false;
        $diagnostics['service_account']['error'] = 'Invalid JSON in service-account.json';
    }
} else {
    $diagnostics['service_account']['file_exists'] = false;
    $diagnostics['service_account']['error'] = 'service-account.json not found at ' . $serviceAccountPath;
}

// Test FCM connectivity (if we have a token)
if ($diagnostics['database']['fcm_tokens_exists'] && $diagnostics['database']['fcm_tokens_count'] > 0) {
    $tokenRes = $conn->query("SELECT token FROM fcm_tokens LIMIT 1");
    if ($tokenRes && $tokenRow = $tokenRes->fetch_assoc()) {
        $testToken = $tokenRow['token'];
        
        // Try to get OAuth token
        if ($diagnostics['service_account']['file_exists'] && $diagnostics['service_account']['valid_json']) {
            $serviceAccount = json_decode(file_get_contents($serviceAccountPath), true);
            
            function base64url_encode($data) {
                return rtrim(strtr(base64_encode($data), '+/', '-_'), '=');
            }
            
            $header = base64url_encode(json_encode([
                "alg" => "RS256",
                "typ" => "JWT"
            ]));
            
            $now = time();
            $payload = base64url_encode(json_encode([
                "iss" => $serviceAccount['client_email'],
                "scope" => "https://www.googleapis.com/auth/firebase.messaging",
                "aud" => "https://oauth2.googleapis.com/token",
                "exp" => $now + 3600,
                "iat" => $now
            ]));
            
            $signature = '';
            $ok = openssl_sign("$header.$payload", $signature, $serviceAccount['private_key'], 'SHA256');
            
            if ($ok) {
                $jwt = "$header.$payload." . base64url_encode($signature);
                
                $ch = curl_init("https://oauth2.googleapis.com/token");
                curl_setopt($ch, CURLOPT_POST, true);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query([
                    "grant_type" => "urn:ietf:params:oauth:grant-type:jwt-bearer",
                    "assertion" => $jwt
                ]));
                curl_setopt($ch, CURLOPT_TIMEOUT, 10);
                $raw = curl_exec($ch);
                $curlErr = curl_error($ch);
                $status = curl_getinfo($ch, CURLINFO_HTTP_CODE);
                curl_close($ch);
                
                if ($status === 200) {
                    $response = json_decode($raw, true);
                    if (isset($response['access_token'])) {
                        $diagnostics['fcm_connectivity']['oauth_success'] = true;
                        $diagnostics['fcm_connectivity']['access_token_preview'] = substr($response['access_token'], 0, 20) . '...';
                        
                        // Try sending a test message
                        $projectId = $serviceAccount['project_id'];
                        $message = [
                            "token" => $testToken,
                            "notification" => [
                                "title" => "Classbuzz Diagnostic Test",
                                "body" => "If you see this, push notifications are working!"
                            ]
                        ];
                        $payload = ["message" => $message];
                        
                        $ch = curl_init("https://fcm.googleapis.com/v1/projects/$projectId/messages:send");
                        curl_setopt($ch, CURLOPT_POST, true);
                        curl_setopt($ch, CURLOPT_HTTPHEADER, [
                            "Authorization: Bearer " . $response['access_token'],
                            "Content-Type: application/json"
                        ]);
                        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
                        curl_setopt($ch, CURLOPT_TIMEOUT, 10);
                        $responseRaw = curl_exec($ch);
                        $curlErr = curl_error($ch);
                        $status = curl_getinfo($ch, CURLINFO_HTTP_CODE);
                        curl_close($ch);
                        
                        if ($status >= 200 && $status < 300) {
                            $diagnostics['fcm_connectivity']['test_message_sent'] = true;
                            $diagnostics['fcm_connectivity']['test_message_status'] = $status;
                        } else {
                            $diagnostics['fcm_connectivity']['test_message_sent'] = false;
                            $diagnostics['fcm_connectivity']['test_message_status'] = $status;
                            $diagnostics['fcm_connectivity']['test_message_error'] = json_decode($responseRaw, true);
                        }
                    } else {
                        $diagnostics['fcm_connectivity']['oauth_success'] = false;
                        $diagnostics['fcm_connectivity']['oauth_error'] = json_decode($raw, true);
                    }
                } else {
                    $diagnostics['fcm_connectivity']['oauth_success'] = false;
                    $diagnostics['fcm_connectivity']['oauth_status'] = $status;
                    $diagnostics['fcm_connectivity']['oauth_error'] = $curlErr ?: $raw;
                }
            } else {
                $diagnostics['fcm_connectivity']['jwt_sign_error'] = 'Failed to sign JWT';
            }
        }
    }
}

echo json_encode($diagnostics, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
?>
