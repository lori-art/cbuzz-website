<?php
/**
 * Automated Reminder Scheduler
 * This script should be called every 5 minutes by a cron job or task scheduler
 */

set_time_limit(60);

$logDir = __DIR__ . '/../logs';
if (!is_dir($logDir)) {
    @mkdir($logDir, 0755, true);
}
$logFile = $logDir . '/scheduler.log';

function log_message($message) {
    global $logFile;
    $timestamp = date('Y-m-d H:i:s');
    $entry = "[$timestamp] $message\n";
    @file_put_contents($logFile, $entry, FILE_APPEND);
    echo $entry;
}

$now = time();
$forceTestAll = isset($_GET['force_all']) && $_GET['force_all'] === '1';
$skipDuplicateCheck = $forceTestAll;

$clickUrl = "http://localhost:8012/cbuzz/auth/login.php";

$mode = "NORMAL";
if ($forceTestAll) $mode = "FORCE_ALL_TEST";

log_message("=== Scheduler Started (Mode: $mode) ===");
log_message("Current time: " . date('Y-m-d H:i:s', $now));

try {
    include __DIR__ . '/../config/db.php';
    include __DIR__ . '/send_push.php';
    
    $res = $conn->query("SELECT id, title, deadline_datetime FROM deadlines");
    if (!$res) {
        log_message("ERROR: Failed to fetch deadlines - " . $conn->error);
        exit(1);
    }
    
    $hasReminderLogsTable = false;
    $logsTableRes = $conn->query("SHOW TABLES LIKE 'deadline_reminder_logs'");
    if ($logsTableRes && $logsTableRes->num_rows > 0) {
        $hasReminderLogsTable = true;
    }
    
    $triggered = 0;
    $totalSent = 0;
    $totalFailed = 0;
    
    $reminders = [
        "24h" => 86400,
        "12h" => 43200,
        "1h" => 3600,
        "30m" => 1800,
        "30s" => 30
    ];
    
    // Different tolerance for 30s reminder (more strict)
    $toleranceSeconds = 600; 
    $tolerance30s = 15; // 15 seconds tolerance for 30s reminder
    
    while ($row = $res->fetch_assoc()) {
        $deadline = strtotime($row['deadline_datetime']);
        if ($deadline === false) {
            continue;
        }
        
        $diff = $deadline - $now;
        $deadlineId = (int)$row['id'];
        $title = htmlspecialchars($row['title']);
        
        foreach ($reminders as $label => $targetSeconds) {
            // Use stricter tolerance for 30s reminder
            $tolerance = ($label === "30s") ? $tolerance30s : $toleranceSeconds;
            $isWithinWindow = abs($diff - $targetSeconds) <= $tolerance;
            $hasPassedTarget = ($diff < $targetSeconds) && ($diff > $targetSeconds - 900);
            
            if ($isWithinWindow || $hasPassedTarget || $forceTestAll) {
                log_message("Deadline '$title' (ID: $deadlineId) - $label reminder");
                
                if ($hasReminderLogsTable && !$skipDuplicateCheck) {
                    $checkStmt = $conn->prepare("
                        SELECT id FROM deadline_reminder_logs
                        WHERE deadline_id = ? AND reminder_type = ?
                        LIMIT 1
                    ");
                    if ($checkStmt) {
                        $checkStmt->bind_param("is", $deadlineId, $label);
                        $checkStmt->execute();
                        $alreadySent = $checkStmt->get_result();
                        if ($alreadySent && $alreadySent->num_rows > 0) {
                            log_message("  → Already sent, skipping");
                            continue;
                        }
                    }
                }
                
                $body = "$title is due in $label.";
                log_message("  → Sending notification: $body");
                
                $result = send_push_notifications("Deadline Reminder", $body, [
                    "deadline_id" => (string)$deadlineId,
                    "reminder_type" => $label
                ], $clickUrl);
                
                $sent = isset($result['sent']) ? (int)$result['sent'] : 0;
                $failed = isset($result['failed']) ? (int)$result['failed'] : 0;
                
                log_message("  → Sent: $sent, Failed: $failed");
                
                $triggered++;
                $totalSent += $sent;
                $totalFailed += $failed;
                
                if (isset($result['error']) && $result['error'] !== null) {
                    log_message("  → Error: " . $result['error']);
                }
                
                // Use INSERT IGNORE to avoid duplicate key errors
                if ($hasReminderLogsTable) {
                    $logStmt = $conn->prepare("
                        INSERT IGNORE INTO deadline_reminder_logs (deadline_id, reminder_type, sent_count, failed_count, sent_at)
                        VALUES (?, ?, ?, ?, NOW())
                    ");
                    if ($logStmt) {
                        $logStmt->bind_param("isii", $deadlineId, $label, $sent, $failed);
                        $logStmt->execute();
                        // Ignore duplicate key errors
                        if ($logStmt->error && strpos($logStmt->error, 'Duplicate') !== false) {
                            log_message("  → Note: Reminder already logged (duplicate)");
                        }
                    }
                }
            }
        }
    }
    
    log_message("=== Scheduler Completed ===");
    log_message("Triggered: $triggered, Sent: $totalSent, Failed: $totalFailed");
    
} catch (Exception $e) {
    log_message("EXCEPTION: " . $e->getMessage());
    exit(1);
}

exit(0);
?>
