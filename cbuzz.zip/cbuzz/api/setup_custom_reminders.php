<?php
/**
 * Setup database for customizable reminders and task assignments
 */

include __DIR__ . "/../config/db.php";

$results = [];

// Create deadline_reminder_settings table
$sql1 = "CREATE TABLE IF NOT EXISTS deadline_reminder_settings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    deadline_id INT NOT NULL,
    reminder_minutes INT NOT NULL,
    sent TINYINT(1) DEFAULT 0,
    sent_at DATETIME DEFAULT NULL,
    UNIQUE KEY unique_deadline_minute (deadline_id, reminder_minutes)
)";
if ($conn->query($sql1)) {
    $results['reminder_settings'] = "Created successfully";
} else {
    $results['reminder_settings'] = "Error: " . $conn->error;
}

// Create deadline_assignments table
$sql2 = "CREATE TABLE IF NOT EXISTS deadline_assignments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    deadline_id INT NOT NULL,
    student_id INT NOT NULL,
    assigned_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY unique_assignment (deadline_id, student_id)
)";
if ($conn->query($sql2)) {
    $results['assignments'] = "Created successfully";
} else {
    $results['assignments'] = "Error: " . $conn->error;
}

// Create default_reminder_templates table for admin to save preset reminder times
$sql3 = "CREATE TABLE IF NOT EXISTS reminder_templates (
    id INT AUTO_INCREMENT PRIMARY KEY,
    template_name VARCHAR(100) NOT NULL,
    minutes_before_deadline INT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
)";
if ($conn->query($sql3)) {
    $results['templates'] = "Created successfully";
} else {
    $results['templates'] = "Error: " . $conn->error;
}

// Insert default templates if table is empty
$checkTemplates = $conn->query("SELECT COUNT(*) as cnt FROM reminder_templates");
if ($checkTemplates && $checkTemplates->fetch_assoc()['cnt'] == 0) {
    $defaultTemplates = [
        ["30 seconds", 0.5],
        ["1 minute", 1],
        ["5 minutes", 5],
        ["15 minutes", 15],
        ["30 minutes", 30],
        ["1 hour", 60],
        ["2 hours", 120],
        ["6 hours", 360],
        ["12 hours", 720],
        ["24 hours", 1440]
    ];
    
    foreach ($defaultTemplates as $template) {
        $stmt = $conn->prepare("INSERT INTO reminder_templates (template_name, minutes_before_deadline) VALUES (?, ?)");
        $stmt->bind_param("si", $template[0], $template[1]);
        $stmt->execute();
    }
    $results['default_templates'] = "Inserted " . count($defaultTemplates) . " default templates";
}

header("Content-Type: application/json");
echo json_encode([
    "ok" => true,
    "results" => $results
]);
?>
