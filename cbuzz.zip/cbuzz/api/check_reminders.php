<?php
/**
 * Web-based Reminder Checker
 * Can be called via cron job or manually
 * Usage: curl http://localhost/cbuzz/api/check_reminders.php
 */

include __DIR__ . "/../config/db.php";
include __DIR__ . "/send_push.php";

$logDir = __DIR__ . '/../logs';
if (!is_dir($logDir)) {
    @mkdir($logDir, 0755, true);
}
$logFile = $logDir . '/reminders.log';

function log_reminder($message) {
    global $logFile;
    $timestamp = date('Y-m-d H:i:s');
    $entry = "[$timestamp] $message\n";
    @file_put_contents($logFile, $entry, FILE_APPEND);
}

$now = time();
$isTestMode = isset($_GET['test']) && $_GET['test'] === '1';
$forceTestAll = isset($_GET['force_all']) && $_GET['force_all'] === '1';
$toleranceSeconds = $isTestMode ? 15 : 300; // 5 minutes tolerance for normal mode, 15 for test
$skipDuplicateCheck = $forceTestAll;

$clickUrl = "http://localhost:8012/cbuzz/auth/login.php";

$mode = "NORMAL";
if ($isTestMode) $mode = "TEST_30_SECONDS";
if ($forceTestAll) $mode = "FORCE_ALL_TEST";

log_reminder("=== Reminder Check Started (Mode: $mode) ===");
log_reminder("Current time: " . date('Y-m-d H:i:s', $now));

$res = $conn->query("SELECT id, title, deadline_datetime FROM deadlines");
if (!$res) {
    log_reminder("ERROR: Failed to fetch deadlines - " . $conn->error);
    http_response_code(500);
    echo json_encode([
        "ok" => false,
        "error" => "Failed to fetch deadlines",
        "db_error" => $conn->error
    ]);
    exit;
}

$hasReminderLogsTable = false;
$logsTableRes = $conn->query("SHOW TABLES LIKE 'deadline_reminder_logs'");
if ($logsTableRes && $logsTableRes->num_rows > 0) {
    $hasReminderLogsTable = true;
}

$triggered = 0;
$totalSent = 0;
$totalFailed = 0;
$lastError = null;

while ($row = $res->fetch_assoc()) {
    $deadline = strtotime($row['deadline_datetime']);
    if ($deadline === false) {
        continue;
    }
    $diff = $deadline - $now;

    $reminders = $isTestMode
        ? ["30s_test" => 30]
        : [
            "24h" => 86400,
            "12h" => 43200,
            "1h" => 3600,
            "30m" => 1800,
            "30s" => 30
        ];

    // Stricter tolerance for 30s reminder
    $tolerance30s = 15; 

    foreach ($reminders as $label => $targetSeconds) {
        // Use stricter tolerance for 30s reminder
        $tolerance = ($label === "30s" || $label === "30s_test") ? $tolerance30s : $toleranceSeconds;
        $isWithinWindow = abs($diff - $targetSeconds) <= $tolerance;
        $hasPassedTarget = ($diff < $targetSeconds) && ($diff > $targetSeconds - 900);
        
        if ($isWithinWindow || $hasPassedTarget || $forceTestAll) {
            $deadlineId = (int)$row['id'];

            if ($hasReminderLogsTable && !$skipDuplicateCheck) {
                $checkStmt = $conn->prepare("
                    SELECT id
                    FROM deadline_reminder_logs
                    WHERE deadline_id = ? AND reminder_type = ?
                    LIMIT 1
                ");
                if ($checkStmt) {
                    $checkStmt->bind_param("is", $deadlineId, $label);
                    $checkStmt->execute();
                    $alreadySent = $checkStmt->get_result();
                    if ($alreadySent && $alreadySent->num_rows > 0) {
                        log_reminder("Deadline ID $deadlineId - $label reminder already sent, skipping");
                        continue;
                    }
                }
            }

            $title = "Deadline Reminder";
            $body = $isTestMode
                ? $row['title'] . " is due in 30 seconds (test)."
                : $row['title'] . " is due in " . $label . ".";

            log_reminder("Sending reminder for deadline ID $deadlineId: $body");

            $result = send_push_notifications($title, $body, [
                "deadline_id" => (string)$deadlineId,
                "reminder_type" => $label
            ], $clickUrl);

            $sent = isset($result['sent']) ? (int)$result['sent'] : 0;
            $failed = isset($result['failed']) ? (int)$result['failed'] : 0;
            $triggered++;
            $totalSent += $sent;
            $totalFailed += $failed;
            if (isset($result['error']) && $result['error'] !== null) {
                $lastError = $result['error'];
                log_reminder("Error: " . $result['error']);
            }

            log_reminder("Result: Sent=$sent, Failed=$failed");

            // Use INSERT IGNORE to avoid duplicate key errors
            if ($hasReminderLogsTable) {
                $logStmt = $conn->prepare("
                    INSERT IGNORE INTO deadline_reminder_logs (deadline_id, reminder_type, sent_count, failed_count, sent_at)
                    VALUES (?, ?, ?, ?, NOW())
                ");
                if ($logStmt) {
                    $logStmt->bind_param("isii", $deadlineId, $label, $sent, $failed);
                    $logStmt->execute();
                    // Ignore duplicate key errors
                    if ($logStmt->error && strpos($logStmt->error, 'Duplicate') !== false) {
                        log_reminder("Note: Reminder already logged (duplicate)");
                    }
                }
            }
        }
    }
}

log_reminder("=== Reminder Check Completed ===");
log_reminder("Total Triggered: $triggered, Sent: $totalSent, Failed: $totalFailed\n");

header("Content-Type: application/json");
echo json_encode([
    "ok" => true,
    "mode" => $isTestMode ? "test_30_seconds" : ($forceTestAll ? "force_all" : "normal"),
    "triggered" => $triggered,
    "sent" => $totalSent,
    "failed" => $totalFailed,
    "has_reminder_logs_table" => $hasReminderLogsTable,
    "error" => $lastError
]);
?>
