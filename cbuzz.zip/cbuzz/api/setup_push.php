<?php
session_start();
include __DIR__ . '/../config/db.php';

header('Content-Type: application/json');

$results = [
    'timestamp' => date('Y-m-d H:i:s'),
    'tables_created' => [],
    'errors' => [],
    'notes' => []
];

// Check if fcm_tokens table exists
$tableRes = $conn->query("SHOW TABLES LIKE 'fcm_tokens'");
$fcmTokensExists = $tableRes && $tableRes->num_rows > 0;

if (!$fcmTokensExists) {
    // Create fcm_tokens table
    $fcmTokensSQL = "CREATE TABLE IF NOT EXISTS fcm_tokens (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT NOT NULL UNIQUE,
        token VARCHAR(512) NOT NULL UNIQUE,
        updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        CONSTRAINT fk_fcm_tokens_user
            FOREIGN KEY (user_id) REFERENCES users(id)
            ON DELETE CASCADE
    )";

    if ($conn->query($fcmTokensSQL)) {
        $results['tables_created'][] = 'fcm_tokens';
    } else {
        $results['errors'][] = 'fcm_tokens: ' . $conn->error;
    }
} else {
    $results['notes'][] = 'fcm_tokens table already exists';
    
    // Check if updated_at column exists, if not add it
    $columnRes = $conn->query("SHOW COLUMNS FROM fcm_tokens LIKE 'updated_at'");
    if (!$columnRes || $columnRes->num_rows === 0) {
        $addColumnSQL = "ALTER TABLE fcm_tokens ADD COLUMN updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP";
        if ($conn->query($addColumnSQL)) {
            $results['notes'][] = 'Added updated_at column to fcm_tokens';
        } else {
            $results['errors'][] = 'Failed to add updated_at: ' . $conn->error;
        }
    }
}

// Create deadline_reminder_logs table
$reminderLogsSQL = "CREATE TABLE IF NOT EXISTS deadline_reminder_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    deadline_id INT NOT NULL,
    reminder_type VARCHAR(20) NOT NULL,
    sent_count INT NOT NULL DEFAULT 0,
    failed_count INT NOT NULL DEFAULT 0,
    sent_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uniq_deadline_reminder (deadline_id, reminder_type),
    CONSTRAINT fk_deadline_reminder_logs_deadline
        FOREIGN KEY (deadline_id) REFERENCES deadlines(id)
        ON DELETE CASCADE
)";

if ($conn->query($reminderLogsSQL)) {
    $results['tables_created'][] = 'deadline_reminder_logs';
} else {
    $results['errors'][] = 'deadline_reminder_logs: ' . $conn->error;
}

// Create deadline_reminder_settings table (for custom reminder times per deadline)
$reminderSettingsSQL = "CREATE TABLE IF NOT EXISTS deadline_reminder_settings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    deadline_id INT NOT NULL,
    reminder_minutes INT NOT NULL,
    UNIQUE KEY uniq_deadline_minutes (deadline_id, reminder_minutes),
    CONSTRAINT fk_reminder_settings_deadline
        FOREIGN KEY (deadline_id) REFERENCES deadlines(id)
        ON DELETE CASCADE
)";

$tableCheck = $conn->query("SHOW TABLES LIKE 'deadline_reminder_settings'");
if (!$tableCheck || $tableCheck->num_rows === 0) {
    if ($conn->query($reminderSettingsSQL)) {
        $results['tables_created'][] = 'deadline_reminder_settings';
    } else {
        $results['errors'][] = 'deadline_reminder_settings: ' . $conn->error;
    }
} else {
    $results['notes'][] = 'deadline_reminder_settings table already exists';
}

// Create deadline_assignments table (for assigning students to deadlines)
$assignmentsSQL = "CREATE TABLE IF NOT EXISTS deadline_assignments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    deadline_id INT NOT NULL,
    student_id INT NOT NULL,
    UNIQUE KEY uniq_deadline_student (deadline_id, student_id),
    CONSTRAINT fk_assignments_deadline
        FOREIGN KEY (deadline_id) REFERENCES deadlines(id)
        ON DELETE CASCADE,
    CONSTRAINT fk_assignments_student
        FOREIGN KEY (student_id) REFERENCES users(id)
        ON DELETE CASCADE
)";

$tableCheck = $conn->query("SHOW TABLES LIKE 'deadline_assignments'");
if (!$tableCheck || $tableCheck->num_rows === 0) {
    if ($conn->query($assignmentsSQL)) {
        $results['tables_created'][] = 'deadline_assignments';
    } else {
        $results['errors'][] = 'deadline_assignments: ' . $conn->error;
    }
} else {
    $results['notes'][] = 'deadline_assignments table already exists';
}

// Verify tables exist
$tableRes = $conn->query("SHOW TABLES LIKE 'fcm_tokens'");
$results['fcm_tokens_verified'] = $tableRes && $tableRes->num_rows > 0;

$logsRes = $conn->query("SHOW TABLES LIKE 'deadline_reminder_logs'");
$results['deadline_reminder_logs_verified'] = $logsRes && $logsRes->num_rows > 0;

$settingsRes = $conn->query("SHOW TABLES LIKE 'deadline_reminder_settings'");
$results['deadline_reminder_settings_verified'] = $settingsRes && $settingsRes->num_rows > 0;

$assignRes = $conn->query("SHOW TABLES LIKE 'deadline_assignments'");
$results['deadline_assignments_verified'] = $assignRes && $assignRes->num_rows > 0;

echo json_encode($results, JSON_PRETTY_PRINT);
?>
