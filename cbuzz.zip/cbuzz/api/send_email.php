<?php
require_once __DIR__ . '/../PHPMailer/src/Exception.php';
require_once __DIR__ . '/../PHPMailer/src/PHPMailer.php';
require_once __DIR__ . '/../PHPMailer/src/SMTP.php';

use PHPMailer\PHPMailer\PHPMailer;

include "../config/db.php";

$mail=new PHPMailer();
$mail->isSMTP();
$mail->Host = 'smtp.gmail.com';
$mail->SMTPAuth = true;
$mail->Username = 'lorraineradores133@gmail.com';
$mail->Password = 'rztosaqimkmpqkda';
$mail->SMTPSecure = 'tls';
$mail->Port = 587;

$res=$conn->query("SELECT email FROM users WHERE role='student'");

while($row=$res->fetch_assoc()){
    $mail->addAddress($row['email']);
}

$mail->Subject="New Deadline Uploaded";
$mail->Body="A new deadline has been added.";

$mail->send();
?>

