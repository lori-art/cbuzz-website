<?php
include_once __DIR__ . "/../config/db.php";

$cachedAccessToken = null;
$cachedTokenExpiry = 0;

function base64url_encode($data) {
    return rtrim(strtr(base64_encode($data), '+/', '-_'), '=');
}

function release_curl_handle(&$ch) {
    $ch = null;
}

function truncate_text($text, $max = 400) {
    $text = (string)$text;
    if (strlen($text) <= $max) {
        return $text;
    }
    return substr($text, 0, $max) . "...";
}

function normalize_fcm_data_payload($dataPayload) {
    $normalized = [];
    if (!is_array($dataPayload)) {
        return $normalized;
    }

    foreach ($dataPayload as $key => $value) {
        $finalKey = is_string($key) ? $key : ('k_' . (string)$key);
        $normalized[$finalKey] = (string)$value;
    }
    return $normalized;
}

function get_firebase_access_token($serviceAccountPath, $forceRefresh = false) {
    global $cachedAccessToken, $cachedTokenExpiry;
    
    if (!$forceRefresh && $cachedAccessToken !== null && time() < $cachedTokenExpiry) {
        return [$cachedAccessToken, null];
    }
    
    if (!file_exists($serviceAccountPath)) {
        return [null, "Missing service-account.json"];
    }

    $serviceAccount = json_decode(file_get_contents($serviceAccountPath), true);
    if (!is_array($serviceAccount) || empty($serviceAccount['client_email']) || empty($serviceAccount['private_key'])) {
        return [null, "Invalid service-account.json"];
    }

    $header = base64url_encode(json_encode([
        "alg" => "RS256",
        "typ" => "JWT"
    ]));

    $now = time();
    $payload = base64url_encode(json_encode([
        "iss" => $serviceAccount['client_email'],
        "scope" => "https://www.googleapis.com/auth/firebase.messaging",
        "aud" => "https://oauth2.googleapis.com/token",
        "exp" => $now + 3600,
        "iat" => $now
    ]));

    $signature = '';
    $ok = openssl_sign("$header.$payload", $signature, $serviceAccount['private_key'], 'SHA256');
    if (!$ok) {
        return [null, "Failed to sign JWT"];
    }

    $jwt = "$header.$payload." . base64url_encode($signature);

    $maxRetries = 3;
    $retryDelay = 1000000;
    
    for ($attempt = 1; $attempt <= $maxRetries; $attempt++) {
        $ch = curl_init("https://oauth2.googleapis.com/token");
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query([
            "grant_type" => "urn:ietf:params:oauth:grant-type:jwt-bearer",
            "assertion" => $jwt
        ]));
        curl_setopt($ch, CURLOPT_TIMEOUT, 30);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 10);
        
        $raw = curl_exec($ch);
        $curlErr = curl_error($ch);
        $status = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        release_curl_handle($ch);

        $response = json_decode($raw, true);
        
        if ($status === 200 && isset($response['access_token'])) {
            $cachedAccessToken = $response['access_token'];
            $cachedTokenExpiry = time() + 3300;
            return [$response['access_token'], null];
        }
        
        $shouldRetry = false;
        
        if (!empty($curlErr)) {
            $shouldRetry = true;
        }
        
        if ($status === 500 || $status === 502 || $status === 503 || $status === 504) {
            $shouldRetry = true;
        }
        
        if (isset($response['error']) && $response['error'] === 'invalid_grant') {
            $shouldRetry = true;
        }
        
        if ($shouldRetry && $attempt < $maxRetries) {
            usleep($retryDelay * $attempt);
            continue;
        }
        
        $errParts = ["OAuth token request failed"];
        if ($status > 0) {
            $errParts[] = "HTTP $status";
        }
        if ($curlErr !== '') {
            $errParts[] = "cURL: " . $curlErr;
        }
        if (is_array($response) && isset($response['error'])) {
            $errParts[] = "API: " . truncate_text(json_encode($response['error']));
        } elseif (is_string($raw) && trim($raw) !== '') {
            $errParts[] = "Body: " . truncate_text($raw);
        }
        
        $cachedAccessToken = null;
        $cachedTokenExpiry = 0;
        
        return [null, implode(" | ", $errParts)];
    }
    
    return [null, "OAuth failed after $maxRetries attempts"];
}

function send_push_notifications($title, $body, $dataPayload = [], $clickUrl = null) {
    global $conn;

    $projectId = "capstone-e841f";
    $serviceAccountPath = __DIR__ . "/../service-account.json";

    list($accessToken, $tokenErr) = get_firebase_access_token($serviceAccountPath);
    if ($tokenErr !== null) {
        return ["sent" => 0, "failed" => 0, "error" => $tokenErr];
    }

    $res = $conn->query("SELECT token FROM fcm_tokens WHERE token <> ''");
    if (!$res) {
        return ["sent" => 0, "failed" => 0, "error" => "Failed to fetch FCM tokens"];
    }
    if ($res->num_rows === 0) {
        return ["sent" => 0, "failed" => 0, "error" => "No FCM tokens registered"];
    }

    $sent = 0;
    $failed = 0;
    $errors = [];
    $maxRetries = 2;
    
    // Default click URL to login page
    if ($clickUrl === null) {
        $clickUrl = "http://localhost:8012/cbuzz/auth/login.php";
    }
    
    $tokens = [];
    while ($row = $res->fetch_assoc()) {
        $tokens[] = $row['token'];
    }

    foreach ($tokens as $token) {
        // Add URL to data payload for the service worker to use
        $dataWithUrl = $dataPayload;
        $dataWithUrl['url'] = $clickUrl;
        
        // Build message with click action
        $message = [
            "token" => $token,
            "notification" => [
                "title" => $title,
                "body" => $body
            ],
            "webpush" => [
                "fcmOptions" => [
                    "link" => $clickUrl
                ]
            ]
        ];
        
        $normalizedData = normalize_fcm_data_payload($dataWithUrl);
        if (!empty($normalizedData)) {
            $message["data"] = $normalizedData;
        }
        $payload = ["message" => $message];
        
        $success = false;
        
        for ($attempt = 1; $attempt <= $maxRetries; $attempt++) {
            $ch = curl_init("https://fcm.googleapis.com/v1/projects/$projectId/messages:send");
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_HTTPHEADER, [
                "Authorization: Bearer $accessToken",
                "Content-Type: application/json"
            ]);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
            curl_setopt($ch, CURLOPT_TIMEOUT, 30);
            curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 10);
            
            $responseRaw = curl_exec($ch);
            $curlErr = curl_error($ch);
            $status = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            release_curl_handle($ch);

            if ($status >= 200 && $status < 300) {
                $success = true;
                break;
            }
            
            $shouldRetry = false;
            if (!empty($curlErr)) {
                $shouldRetry = true;
            }
            if ($status === 500 || $status === 502 || $status === 503 || $status === 504) {
                $shouldRetry = true;
            }
            
            if (!$shouldRetry || $attempt >= $maxRetries) {
                break;
            }
            
            usleep(500000);
        }

        if ($success) {
            $sent++;
        } else {
            $failed++;
            $responseData = json_decode($responseRaw, true);
            $errorLabel = "FCM send failed";
            if ($status > 0) {
                $errorLabel .= " (HTTP $status)";
            }
            if ($curlErr !== '') {
                $errorLabel .= " cURL: " . $curlErr;
            } elseif (is_array($responseData) && isset($responseData['error'])) {
                $errorLabel .= " API: " . truncate_text(json_encode($responseData['error']));
            } elseif (is_string($responseRaw) && trim($responseRaw) !== '') {
                $errorLabel .= " Body: " . truncate_text($responseRaw);
            }
            $errors[] = $errorLabel;

            if (isset($responseData['error']['details']) && is_array($responseData['error']['details'])) {
                foreach ($responseData['error']['details'] as $detail) {
                    if (isset($detail['errorCode']) && in_array($detail['errorCode'], ["UNREGISTERED", "INVALID_ARGUMENT"], true)) {
                        $stmt = $conn->prepare("DELETE FROM fcm_tokens WHERE token = ? LIMIT 1");
                        $stmt->bind_param("s", $token);
                        $stmt->execute();
                    }
                }
            }
        }
    }

    return [
        "sent" => $sent,
        "failed" => $failed,
        "error" => count($errors) > 0 ? $errors[0] : null
    ];
}

if (php_sapi_name() !== 'cli' && isset($_GET['test'])) {
    $logDir = __DIR__ . '/../logs';
    if (!is_dir($logDir)) {
        @mkdir($logDir, 0755, true);
    }
    $logFile = $logDir . '/push_send.log';
    $logEntry = date('Y-m-d H:i:s') . " | TEST REQUEST | ";
    
    $clickUrl = "http://localhost:8012/cbuzz/auth/login.php";
    $result = send_push_notifications("Classbuzz Test", "Push notifications are working. Click to login!", [], $clickUrl);
    
    $logEntry .= "Sent: " . $result['sent'] . " | Failed: " . $result['failed'] . " | Error: " . ($result['error'] ?? 'none') . "\n";
    @file_put_contents($logFile, $logEntry, FILE_APPEND);
    
    header("Content-Type: application/json");
    echo json_encode($result);
    exit;
}
?>
