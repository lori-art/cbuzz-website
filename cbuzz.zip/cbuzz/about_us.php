<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>About Us - Classbuzz</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Sora:wght@400;500;600;700;800&family=Source+Serif+4:wght@600;700&display=swap" rel="stylesheet">
<style>
    :root {
        --bg: #f4f6f8;
        --surface: #ffffff;
        --text: #1e2228;
        --muted: #5d6674;
        --brand: #cfa430;
        --brand-deep: #9f7d1d;
        --ink: #101216;
        --line: #e6e9ef;
    }

    * {
        box-sizing: border-box;
        margin: 0;
        padding: 0;
    }

    body {
        font-family: "Sora", sans-serif;
        background: radial-gradient(circle at 10% -10%, #fff7de 0%, var(--bg) 46%), var(--bg);
        color: var(--text);
        line-height: 1.6;
    }

    a {
        text-decoration: none;
    }

    nav {
        position: sticky;
        top: 0;
        z-index: 50;
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 16px 40px;
        background: rgba(255, 255, 255, 0.88);
        backdrop-filter: blur(8px);
        border-bottom: 1px solid var(--line);
    }

    .logo {
        display: flex;
        align-items: center;
        gap: 10px;
        color: var(--ink);
        font-weight: 700;
        font-size: 22px;
    }

    .logo img {
        width: 34px;
        height: 34px;
    }

    nav ul {
        list-style: none;
        display: flex;
        gap: 20px;
        align-items: center;
    }

    nav ul a {
        color: var(--ink);
        font-weight: 500;
        transition: color 0.2s ease;
    }

    nav ul a:hover {
        color: var(--brand-deep);
    }

    .nav-cta {
        background: var(--ink);
        color: #fff;
        padding: 10px 16px;
        border-radius: 999px;
    }

    .nav-cta:hover {
        color: #fff;
        background: #1b1e24;
    }

    .hero {
        max-width: 1180px;
        margin: 34px auto 24px;
        padding: 0 24px;
        display: grid;
        grid-template-columns: 1.15fr 0.85fr;
        gap: 26px;
    }

    .hero-copy {
        background: linear-gradient(120deg, #171a20 0%, #232834 100%);
        color: #fff;
        border-radius: 22px;
        padding: 42px;
        box-shadow: 0 16px 40px rgba(16, 18, 22, 0.18);
    }

    .eyebrow {
        color: #f0d184;
        letter-spacing: 0.12em;
        text-transform: uppercase;
        font-size: 12px;
        font-weight: 700;
    }

    .hero h1 {
        margin-top: 10px;
        font-family: "Source Serif 4", serif;
        font-size: clamp(2rem, 3vw, 3rem);
        line-height: 1.1;
    }

    .hero p {
        margin-top: 16px;
        color: #cdd3df;
        max-width: 60ch;
    }

    .hero-actions {
        margin-top: 26px;
        display: flex;
        flex-wrap: wrap;
        gap: 12px;
    }

    .btn {
        padding: 12px 18px;
        border-radius: 10px;
        font-weight: 600;
        display: inline-block;
    }

    .btn-primary {
        background: var(--brand);
        color: #18120a;
    }

    .btn-secondary {
        border: 1px solid #41495a;
        color: #f3f5f9;
    }

    .hero-stat {
        background: var(--surface);
        border: 1px solid var(--line);
        border-radius: 22px;
        padding: 28px;
        display: grid;
        gap: 16px;
        align-content: center;
    }

    .metric-row {
        display: flex;
        justify-content: space-between;
        align-items: baseline;
        padding-bottom: 14px;
        border-bottom: 1px dashed #d9dde5;
    }

    .metric-row:last-child {
        border-bottom: none;
        padding-bottom: 0;
    }

    .metric-row strong {
        font-size: 34px;
        color: var(--ink);
    }

    .content {
        max-width: 1180px;
        margin: 0 auto;
        padding: 14px 24px 62px;
    }

    .section-title {
        font-family: "Source Serif 4", serif;
        font-size: clamp(1.6rem, 2vw, 2.2rem);
        margin-bottom: 8px;
    }

    .section-sub {
        color: var(--muted);
        margin-bottom: 24px;
    }

    .values-grid {
        display: grid;
        grid-template-columns: repeat(3, 1fr);
        gap: 16px;
        margin-bottom: 34px;
    }

    .value-card {
        background: var(--surface);
        border: 1px solid var(--line);
        border-radius: 14px;
        padding: 18px;
    }

    .value-card h3 {
        margin-bottom: 8px;
        color: var(--ink);
        font-size: 17px;
    }

    .value-card p {
        color: var(--muted);
        font-size: 14px;
    }

    .team-wrap {
        background: linear-gradient(180deg, #fff 0%, #f7f9fc 100%);
        border: 1px solid var(--line);
        border-radius: 20px;
        padding: 24px;
    }

    .team-grid {
        display: grid;
        grid-template-columns: repeat(4, 1fr);
        gap: 16px;
        margin-top: 16px;
    }

    .member-card {
        background: #fff;
        border: 1px solid #e7ebf2;
        border-radius: 14px;
        padding: 16px;
        text-align: center;
        transition: transform 0.2s ease, box-shadow 0.2s ease;
    }

    .member-card:hover {
        transform: translateY(-4px);
        box-shadow: 0 12px 24px rgba(17, 22, 31, 0.08);
    }

    .avatar {
        width: 84px;
        height: 84px;
        border-radius: 50%;
        margin: 0 auto 10px;
        border: 3px solid #f2f4f8;
        overflow: hidden;
        background: linear-gradient(135deg, #303745 0%, #56627a 100%);
    }

    .avatar img {
        width: 100%;
        height: 100%;
        object-fit: cover;
    }

    .member-card h3 {
        font-size: 16px;
        color: var(--ink);
    }

    .member-card p {
        color: var(--muted);
        font-size: 13px;
        margin-top: 4px;
    }

    .cta {
        margin-top: 26px;
        background: linear-gradient(95deg, #12151b 0%, #222837 100%);
        border-radius: 18px;
        color: #f4f6fb;
        padding: 24px;
        display: flex;
        flex-wrap: wrap;
        justify-content: space-between;
        align-items: center;
        gap: 14px;
    }

    .cta p {
        color: #c4cbda;
    }

    footer {
        text-align: center;
        padding: 22px;
        color: #6c7482;
        font-size: 14px;
    }

    @media (max-width: 1024px) {
        .hero {
            grid-template-columns: 1fr;
        }

        .values-grid {
            grid-template-columns: 1fr 1fr;
        }

        .team-grid {
            grid-template-columns: repeat(3, 1fr);
        }
    }

    @media (max-width: 760px) {
        nav {
            padding: 14px 16px;
            flex-direction: column;
            align-items: flex-start;
            gap: 12px;
        }

        nav ul {
            gap: 14px;
            flex-wrap: wrap;
        }

        .hero,
        .content {
            padding-left: 16px;
            padding-right: 16px;
        }

        .hero-copy {
            padding: 26px 20px;
        }

        .values-grid,
        .team-grid {
            grid-template-columns: 1fr;
        }
    }
</style>
</head>
<body>

<nav>
    <a class="logo" href="index.php">
        <img src="images/classbuzz-logo.svg" alt="Classbuzz logo">
        <span>Classbuzz</span>
    </a>
    <ul>
        <li><a href="index.php">Home</a></li>
        <li><a href="about_us.php">About Us</a></li>
        <li><a class="nav-cta" href="auth/login.php">Login</a></li>
    </ul>
</nav>

<section class="hero">
    <div class="hero-copy">
        <div class="eyebrow">Student-first platform</div>
        <h1>We Built Classbuzz To Make Deadlines Less Stressful</h1>
        <p>Classbuzz helps students, teachers, and organizations stay aligned through smart reminders, easy task tracking, and clear progress visibility. Our focus is convenience without complexity.</p>
        <div class="hero-actions">
            <a class="btn btn-primary" href="auth/register.php">Join Classbuzz</a>
            <a class="btn btn-secondary" href="#team">Meet the Team</a>
        </div>
    </div>
    <aside class="hero-stat">
        <div class="metric-row">
            <span>Active learners</span>
            <strong>2,000+</strong>
        </div>
        <div class="metric-row">
            <span>Tasks tracked monthly</span>
            <strong>15k+</strong>
        </div>
        <div class="metric-row">
            <span>On-time submissions</span>
            <strong>94%</strong>
        </div>
    </aside>
</section>

<main class="content">
    <h2 class="section-title">What Makes Us Different</h2>
    <p class="section-sub">We balance modern design with practical tools that students can use every day without a learning curve.</p>

    <section class="values-grid">
        <article class="value-card">
            <h3>Clear Task Visibility</h3>
            <p>Every assignment, exam, and reminder is organized in one view to reduce missed deadlines.</p>
        </article>
        <article class="value-card">
            <h3>Fast, Convenient Workflow</h3>
            <p>Simple actions and straightforward screens help users focus on results instead of figuring out controls.</p>
        </article>
        <article class="value-card">
            <h3>Built For Consistency</h3>
            <p>Reliable alerts and progress tracking help students develop strong habits and better time management.</p>
        </article>
    </section>

    <section class="team-wrap" id="team">
        <h2 class="section-title">Our Team</h2>
        <p class="section-sub">A multidisciplinary group committed to creating smarter student tools.</p>

        <div class="team-grid">
            <div class="member-card">
                <div class="avatar">
                    <img src="images/team/tifany.jpg" alt="Tifany Chanyongo" onerror="this.style.display='none';this.parentElement.style.background='linear-gradient(135deg, #cfa430 0%, #9f7d1d 100%)';this.parentElement.innerHTML='<span style=color:#fff;font-weight:700;font-size:24px;line-height:84px;>TC</span>'">
                </div>
                <h3>Tifany Chanyongo</h3>
                <p>Research Leader</p>
            </div>
            <div class="member-card">
                <div class="avatar">
                    <img src="images/team/lorraine.jpg" alt="Lorraine Radores" onerror="this.style.display='none';this.parentElement.style.background='linear-gradient(135deg, #3b82f6 0%, #1d4ed8 100%)';this.parentElement.innerHTML='<span style=color:#fff;font-weight:700;font-size:24px;line-height:84px;>LR</span>'">
                </div>
                <h3>Lorraine Radores</h3>
                <p>Web Developer</p>
            </div>
            <div class="member-card">
                <div class="avatar">
                    <img src="images/team/lyca.jpg" alt="Lyca Stephanie Roxas" onerror="this.style.display='none';this.parentElement.style.background='linear-gradient(135deg, #8b5cf6 0%, #6d28d9 100%)';this.parentElement.innerHTML='<span style=color:#fff;font-weight:700;font-size:24px;line-height:84px;>LSR</span>'">
                </div>
                <h3>Lyca Stephanie Roxas</h3>
                <p>Member</p>
            </div>
            <div class="member-card">
                <div class="avatar">
                    <img src="images/team/loriene.jpg" alt="Loriene Samarita" onerror="this.style.display='none';this.parentElement.style.background='linear-gradient(135deg, #10b981 0%, #047857 100%)';this.parentElement.innerHTML='<span style=color:#fff;font-weight:700;font-size:24px;line-height:84px;>LS</span>'">
                </div>
                <h3>Loriene Samarita</h3>
                <p>Member</p>
            </div>
            <div class="member-card">
                <div class="avatar">
                    <img src="images/team/jeric.jpg" alt="Jeric Toca" onerror="this.style.display='none';this.parentElement.style.background='linear-gradient(135deg, #ef4444 0%, #dc2626 100%)';this.parentElement.innerHTML='<span style=color:#fff;font-weight:700;font-size:24px;line-height:84px;>JT</span>'">
                </div>
                <h3>Jeric Toca</h3>
                <p>Member</p>
            </div>
            <div class="member-card">
                <div class="avatar">
                    <img src="images/team/apple.jpg" alt="Apple Jane Plaza" onerror="this.style.display='none';this.parentElement.style.background='linear-gradient(135deg, #f59e0b 0%, #d97706 100%)';this.parentElement.innerHTML='<span style=color:#fff;font-weight:700;font-size:24px;line-height:84px;>AJP</span>'">
                </div>
                <h3>Apple Jane Plaza</h3>
                <p>Member</p>
            </div>
            <div class="member-card">
                <div class="avatar">
                    <img src="images/team/daniel.jpg" alt="Aikroyd Daniel Rosaldo" onerror="this.style.display='none';this.parentElement.style.background='linear-gradient(135deg, #6366f1 0%, #4f46e5 100%)';this.parentElement.innerHTML='<span style=color:#fff;font-weight:700;font-size:24px;line-height:84px;>DNR</span>'">
                </div>
                <h3>Aikroyd Daniel Rosaldo</h3>
                <p>Member</p>
            </div>
            <div class="member-card">
                <div class="avatar">
                    <img src="images/team/inigo.jpg" alt="Inigo Rivamonte" onerror="this.style.display='none';this.parentElement.style.background='linear-gradient(135deg, #ec4899 0%, #db2777 100%)';this.parentElement.innerHTML='<span style=color:#fff;font-weight:700;font-size:24px;line-height:84px;>IR</span>'">
                </div>
                <h3>Inigo Rivamonte</h3>
                <p>Member</p>
            </div>
            <div class="member-card">
                <div class="avatar">
                    <img src="images/team/clarence.jpg" alt="Clarence Lanuza" onerror="this.style.display='none';this.parentElement.style.background='linear-gradient(135deg, #14b8a6 0%, #0d9488 100%)';this.parentElement.innerHTML='<span style=color:#fff;font-weight:700;font-size:24px;line-height:84px;>CL</span>'">
                </div>
                <h3>Clarence Lanuza</h3>
                <p>Member</p>
            </div>
            <div class="member-card">
                <div class="avatar">
                    <img src="images/team/prince.jpg" alt="Prince Lutao" onerror="this.style.display='none';this.parentElement.style.background='linear-gradient(135deg, #f97316 0%, #ea580c 100%)';this.parentElement.innerHTML='<span style=color:#fff;font-weight:700;font-size:24px;line-height:84px;>PL</span>'">
                </div>
                <h3>Prince Lutao</h3>
                <p>Member</p>
            </div>
            <div class="member-card">
                <div class="avatar">
                    <img src="images/team/lhian.jpg" alt="Lhian De Luna" onerror="this.style.display='none';this.parentElement.style.background='linear-gradient(135deg, #06b6d4 0%, #0891b2 100%)';this.parentElement.innerHTML='<span style=color:#fff;font-weight:700;font-size:24px;line-height:84px;>LDL</span>'">
                </div>
                <h3>Lhian De Luna</h3>
                <p>Member</p>
            </div>
            <div class="member-card">
                <div class="avatar">
                    <img src="images/team/kenneth.jpg" alt="Kenneth Magaro" onerror="this.style.display='none';this.parentElement.style.background='linear-gradient(135deg, #8b5cf6 0%, #7c3aed 100%)';this.parentElement.innerHTML='<span style=color:#fff;font-weight:700;font-size:24px;line-height:84px;>KM</span>'">
                </div>
                <h3>Kenneth Magaro</h3>
                <p>Member</p>
            </div>
            <div class="member-card">
                <div class="avatar">
                    <img src="images/team/arjillian.jpg" alt="Arjillian Cobo" onerror="this.style.display='none';this.parentElement.style.background='linear-gradient(135deg, #84cc16 0%, #65a30d 100%)';this.parentElement.innerHTML='<span style=color:#fff;font-weight:700;font-size:24px;line-height:84px;>AC</span>'">
                </div>
                <h3>Arjillian Cobo</h3>
                <p>Member</p>
            </div>
        </div>

        <div class="cta">
            <div>
                <h3>Ready to make schoolwork easier?</h3>
                <p>Create an account and start organizing your deadlines with Classbuzz.</p>
            </div>
            <a class="btn btn-primary" href="auth/register.php">Get Started</a>
        </div>
    </section>
</main>

<footer>
    &copy; 2026 Classbuzz. All rights reserved.
</footer>

</body>
</html>
