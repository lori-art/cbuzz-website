# Background Reminder Checker - Student Dashboard

## What Was Added

I've added automatic background reminder checking to the student dashboard. Now you'll receive push notifications **without needing to open a separate tab**.

## How It Works

### On Page Load
- When you open the student dashboard, it immediately checks for reminders
- If any reminders are due, they're sent to your device

### Every 5 Minutes
- While the dashboard is open, it checks for reminders every 5 minutes
- This ensures you get notifications for upcoming deadlines

### When You Switch Tabs
- If you switch away from the dashboard and come back, it checks again
- This catches any reminders that might have been triggered while you were away

## Features

✅ **Automatic Checking** - No manual action needed
✅ **Every 5 Minutes** - Checks while dashboard is open
✅ **Tab Switching** - Checks when you return to the tab
✅ **Background Operation** - Doesn't interfere with dashboard functionality
✅ **Console Logging** - Check browser console (F12) to see what's happening

## How to Use

1. **Log in to student dashboard:** `http://localhost/cbuzz/student/dashboard.php`
2. **Allow notifications** when prompted
3. **Keep the dashboard open** (or switch back to it periodically)
4. **Receive notifications** automatically when deadlines are due

## Verification

### Check Console Logs
1. Open student dashboard
2. Press `F12` to open DevTools
3. Go to **Console** tab
4. You should see logs like:
   ```
   Checking for reminders in background...
   Reminder check result: {ok: true, sent: 0, ...}
   ```

### Test It
1. Create a deadline for 35 minutes from now
2. Keep the dashboard open
3. Wait 5 minutes
4. You should receive a notification

## Code Added

The following JavaScript was added to the student dashboard:

```javascript
// Check for reminders every 5 minutes while dashboard is open
function checkRemindersInBackground() {
    console.log("Checking for reminders in background...");
    
    fetch("../api/check_reminders.php")
        .then(response => response.json())
        .then(data => {
            console.log("Reminder check result:", data);
            if (data.ok && data.sent > 0) {
                console.log("Reminders sent: " + data.sent);
            }
        })
        .catch(error => console.error("Error checking reminders:", error));
}

// Run immediately on page load
checkRemindersInBackground();

// Then run every 5 minutes (300000 milliseconds)
setInterval(checkRemindersInBackground, 300000);

// Also check when page becomes visible (user switches back to tab)
document.addEventListener("visibilitychange", function() {
    if (!document.hidden) {
        console.log("Dashboard became visible, checking reminders...");
        checkRemindersInBackground();
    }
});
```

## Customization

### Change Check Frequency

To check more or less frequently, edit the interval (in milliseconds):

```javascript
// Every 1 minute (60000 ms)
setInterval(checkRemindersInBackground, 60000);

// Every 10 minutes (600000 ms)
setInterval(checkRemindersInBackground, 600000);

// Every 30 minutes (1800000 ms)
setInterval(checkRemindersInBackground, 1800000);
```

### Disable Background Checking

If you want to disable this feature, comment out or remove the interval:

```javascript
// Disabled - no longer checks every 5 minutes
// setInterval(checkRemindersInBackground, 300000);
```

## How It Complements the Scheduler

### Background Checker (Dashboard)
- Runs while you have the dashboard open
- Checks every 5 minutes
- Immediate notifications while using the app

### Scheduler (Task Scheduler/Cron)
- Runs in the background on your server
- Checks every 5 minutes regardless of whether dashboard is open
- Ensures notifications are sent even if you're not using the app

**Together, they provide comprehensive coverage:**
- Using the app? → Dashboard checker sends notifications
- Not using the app? → Scheduler sends notifications
- Both running? → Notifications are sent (may be duplicated, but prevented by reminder logs)

## Troubleshooting

### Not receiving notifications while dashboard is open

1. **Check console logs:**
   - Press F12 on dashboard
   - Go to Console tab
   - Look for "Checking for reminders in background..."

2. **Verify device is registered:**
   - Should see "Push: Connected" in bottom-right corner

3. **Check if reminders are being triggered:**
   - Look at logs: `logs/reminders.log`
   - Verify deadline is within reminder window

### Console shows errors

1. **Check network tab:**
   - Press F12 > Network tab
   - Look for requests to `check_reminders.php`
   - Verify they return 200 status

2. **Check API response:**
   - Click on `check_reminders.php` request
   - Go to Response tab
   - Should show JSON with `"ok": true`

## Next Steps

1. ✅ Background checker is now active on student dashboard
2. ✅ Keep dashboard open to receive notifications
3. ✅ Also set up scheduler for notifications when dashboard is closed
4. ✅ Monitor console logs to verify it's working

## Summary

You now have **two ways to receive notifications:**

1. **Dashboard Background Checker** (NEW)
   - Active while dashboard is open
   - Checks every 5 minutes
   - Immediate notifications

2. **Server Scheduler** (Existing)
   - Active all the time
   - Checks every 5 minutes
   - Notifications even when not using app

**Result:** You'll receive push notifications automatically, whether you're using the app or not! 🎉
