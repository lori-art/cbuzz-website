@echo off
REM Classbuzz Reminder Scheduler - Windows Batch Script
REM This script runs the reminder checker
REM Can be scheduled with Windows Task Scheduler

setlocal enabledelayedexpansion

REM Get the directory where this script is located
set SCRIPT_DIR=%~dp0

REM PHP executable path (adjust if needed)
set PHP_EXE=C:\xampp\php\php.exe

REM Check if PHP exists
if not exist "%PHP_EXE%" (
    echo Error: PHP not found at %PHP_EXE%
    echo Please update the PHP_EXE path in this script
    exit /b 1
)

REM Run the scheduler
echo Running Classbuzz Reminder Scheduler...
echo Time: %date% %time%

"%PHP_EXE%" "%SCRIPT_DIR%api\scheduler.php"

if %errorlevel% equ 0 (
    echo Scheduler completed successfully
) else (
    echo Scheduler failed with error code %errorlevel%
)

exit /b %errorlevel%
