<?php
session_start();
include "../config/db.php";

if($_SERVER["REQUEST_METHOD"] == "POST"){

    $name = $_POST['name'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $confirm = $_POST['confirm'];
    if($password !== $confirm){
        $error = "Passwords do not match!";
    } else {

        $hashed = password_hash($password, PASSWORD_DEFAULT);

        $stmt = $conn->prepare("INSERT INTO users (name, email, password) VALUES (?, ?, ?)");
        $stmt->bind_param("sss", $name, $email, $hashed);

        if($stmt->execute()){
        header("Location: login.php");
        exit;
        } else {
        $error = "Registration failed. Try again.";
}
    }
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Register - Classbuzz</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<style>

*{
    box-sizing:border-box;
    font-family:'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
}

body{
    margin:0;
    background:linear-gradient(rgba(0,0,0,0.6), rgba(0,0,0,0.6)),
    url('https://images.unsplash.com/photo-1523580846011-d3a5bc25702b?auto=format&fit=crop&w=1470&q=80') center/cover no-repeat;
    height:100vh;
    display:flex;
    justify-content:center;
    align-items:center;
}

.form-container{
    background:#ffffff;
    padding:40px;
    width:100%;
    max-width:420px;
    border-radius:12px;
    box-shadow:0 15px 40px rgba(0,0,0,0.3);
}

h2{
    text-align:center;
    margin-bottom:25px;
    color:#1a1a1a;
}

input, select{
    width:100%;
    padding:12px;
    margin-bottom:15px;
    border:1px solid #ddd;
    border-radius:8px;
    font-size:14px;
}

input:focus, select:focus{
    outline:none;
    border-color:#cfa430;
}

button{
    width:100%;
    padding:12px;
    background:#cfa430;
    border:none;
    border-radius:8px;
    font-weight:bold;
    cursor:pointer;
    transition:0.3s;
}

button:hover{
    background:#b89328;
}

.error{
    color:red;
    text-align:center;
    margin-bottom:10px;
}

.login-link{
    text-align:center;
    margin-top:15px;
    font-size:14px;
}

.login-link a{
    color:#cfa430;
    text-decoration:none;
    font-weight:600;
}

.login-link a:hover{
    text-decoration:underline;
}

</style>
</head>
<body>

<div class="form-container">
    <h2>Create Account</h2>

    <?php if(isset($error)) echo "<div class='error'>$error</div>"; ?>

    <form method="POST">
        <input type="text" name="name" placeholder="Full Name" required>
        <input type="email" name="email" placeholder="Email Address" required>
        </select>

        <input type="password" name="password" placeholder="Password" required>
        <input type="password" name="confirm" placeholder="Confirm Password" required>

        <button type="submit">Register</button>
    </form>

    <div class="login-link">
        Already have an account? <a href="login.php">Login</a>
    </div>
</div>

</body>
</html>