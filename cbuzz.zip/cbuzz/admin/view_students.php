<?php
session_start();
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] != 'admin') {
    header("Location: ../auth/login.php");
    exit;
}
include "../config/db.php";

$adminName = isset($_SESSION['user']['name']) && $_SESSION['user']['name'] !== ''
    ? $_SESSION['user']['name']
    : 'Admin';

$hour = (int)date('H');
$greeting = 'Hello';
if ($hour < 12) {
    $greeting = 'Good morning';
} elseif ($hour < 18) {
    $greeting = 'Good afternoon';
} else {
    $greeting = 'Good evening';
}

// Get filter parameters
$sortBy = isset($_GET['sort']) ? $_GET['sort'] : 'name';
$filterSubject = isset($_GET['subject']) ? $_GET['subject'] : 'all';
$allowedSorts = ['name', 'completion', 'completed', 'pending'];
if (!in_array($sortBy, $allowedSorts, true)) {
    $sortBy = 'name';
}

// Get all subjects for filter
$subjects = ['PEH 300', 'ICT LECTURE', 'ICT 400', 'PILOSOPHY', 'RESEARCH', 'ENTREPRENEUR', 'IMMERSION'];

// Get all students with their performance
$studentsQuery = "
    SELECT 
        u.id,
        u.name,
        u.email,
        COUNT(DISTINCT d.id) AS total_deadlines,
        COUNT(DISTINCT dc.deadline_id) AS completed_deadlines
    FROM users u
    LEFT JOIN deadline_completions dc ON u.id = dc.user_id
    LEFT JOIN deadlines d ON d.id = dc.deadline_id
    WHERE u.role = 'student'
    GROUP BY u.id, u.name, u.email
";

$studentsResult = $conn->query($studentsQuery);
$students = [];

if ($studentsResult) {
    while ($row = $studentsResult->fetch_assoc()) {
        $total = (int)$row['total_deadlines'];
        $completed = (int)$row['completed_deadlines'];
        $row['completion_rate'] = $total > 0 ? round(($completed / $total) * 100) : 0;
        $row['pending_deadlines'] = $total - $completed;
        $students[] = $row;
    }
}

// Sort students
if ($sortBy === 'completion') {
    usort($students, function($a, $b) {
        return $b['completion_rate'] - $a['completion_rate'];
    });
} elseif ($sortBy === 'completed') {
    usort($students, function($a, $b) {
        return $b['completed_deadlines'] - $a['completed_deadlines'];
    });
} elseif ($sortBy === 'pending') {
    usort($students, function($a, $b) {
        return $b['pending_deadlines'] - $a['pending_deadlines'];
    });
} else {
    usort($students, function($a, $b) {
        return strcmp($a['name'], $b['name']);
    });
}

// Get overall stats
$totalStudents = count($students);
$avgCompletion = 0;
$totalCompletedAll = 0;
$totalPendingAll = 0;

if ($totalStudents > 0) {
    $sumCompletion = array_sum(array_column($students, 'completion_rate'));
    $avgCompletion = round($sumCompletion / $totalStudents);
    $totalCompletedAll = array_sum(array_column($students, 'completed_deadlines'));
    $totalPendingAll = array_sum(array_column($students, 'pending_deadlines'));
}

// Get subject-specific stats for each student if subject filter is selected
if ($filterSubject !== 'all') {
    foreach ($students as &$student) {
        $subjectQuery = "
            SELECT COUNT(DISTINCT d.id) AS total,
                   COUNT(DISTINCT dc.deadline_id) AS completed
            FROM users u
            LEFT JOIN deadline_completions dc ON u.id = dc.user_id
            LEFT JOIN deadlines d ON d.id = dc.deadline_id AND d.title = ?
            WHERE u.id = ?
        ";
        $stmt = $conn->prepare($subjectQuery);
        $stmt->bind_param("si", $filterSubject, $student['id']);
        $stmt->execute();
        $subjectResult = $stmt->get_result();
        if ($subjectRow = $subjectResult->fetch_assoc()) {
            $student['total_deadlines'] = (int)$subjectRow['total'];
            $student['completed_deadlines'] = (int)$subjectRow['completed'];
            $student['pending_deadlines'] = (int)$subjectRow['total'] - (int)$subjectRow['completed'];
            $student['completion_rate'] = $student['total_deadlines'] > 0 
                ? round(($student['completed_deadlines'] / $student['total_deadlines']) * 100) 
                : 0;
        }
    }
}

// Get total deadlines in system
$totalDeadlinesQuery = "SELECT COUNT(*) as cnt FROM deadlines";
$totalDeadlinesResult = $conn->query($totalDeadlinesQuery);
$totalDeadlines = $totalDeadlinesResult ? (int)$totalDeadlinesResult->fetch_assoc()['cnt'] : 0;
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>View Students - Classbuzz Admin</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Sora:wght@400;500;600;700;800&family=Source+Serif+4:wght@600;700&display=swap" rel="stylesheet">
<style>
:root {
    --bg: #f4f6f8;
    --surface: #ffffff;
    --text: #1e2228;
    --muted: #5d6674;
    --brand: #cfa430;
    --brand-deep: #9f7d1d;
    --ink: #101216;
    --line: #e6e9ef;
    --danger: #d94d4d;
    --success: #2f7a46;
}
* { box-sizing: border-box; margin: 0; padding: 0; }
body {
    font-family: "Sora", sans-serif;
    background: radial-gradient(circle at 10% -10%, #fff7de 0%, var(--bg) 46%), var(--bg);
    color: var(--text);
    min-height: 100vh;
}
a { text-decoration: none; }
.topbar {
    position: sticky;
    top: 0;
    z-index: 30;
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 14px 24px;
    background: rgba(255, 255, 255, 0.88);
    backdrop-filter: blur(8px);
    border-bottom: 1px solid var(--line);
}
.logo {
    display: flex;
    align-items: center;
    gap: 10px;
    color: var(--ink);
    font-weight: 700;
    font-size: 21px;
}
.logo img { width: 32px; height: 32px; }
.logout-btn {
    border: none;
    background: var(--danger);
    color: #fff;
    border-radius: 999px;
    padding: 9px 14px;
    cursor: pointer;
    font-weight: 600;
}
.topbar-right {
    display: flex;
    align-items: center;
    gap: 14px;
}
.datetime-wrap {
    display: flex;
    align-items: baseline;
    gap: 12px;
    color: #2f3339;
}
.datetime-time {
    font-size: 28px;
    font-weight: 700;
    line-height: 1;
    letter-spacing: 0.01em;
}
.datetime-date {
    font-size: 16px;
    color: #666c76;
    font-weight: 600;
    line-height: 1;
}
.layout {
    max-width: 1320px;
    margin: 18px auto;
    padding: 0 16px 24px;
    display: grid;
    grid-template-columns: 290px 1fr;
    gap: 18px;
}
.sidebar {
    background: var(--surface);
    border: 1px solid var(--line);
    border-radius: 16px;
    padding: 14px;
    align-self: start;
    position: sticky;
    top: 78px;
    max-height: calc(100vh - 96px);
    overflow-y: auto;
    box-shadow: 0 10px 22px rgba(30, 38, 53, 0.06);
}
.greeting {
    background: linear-gradient(120deg, #171a20 0%, #232834 100%);
    color: #fff;
    border-radius: 12px;
    padding: 12px;
    margin-bottom: 14px;
}
.greeting strong { display: block; font-size: 16px; }
.greeting span { color: #d4d9e7; font-size: 12px; }
.side-title {
    font-size: 11px;
    color: var(--muted);
    text-transform: uppercase;
    letter-spacing: 0.1em;
    margin: 12px 0 8px;
}
.side-links { display: grid; gap: 8px; }
.side-link {
    border: 1px solid var(--line);
    border-radius: 10px;
    padding: 9px 10px;
    color: #2d3440;
    font-size: 14px;
    font-weight: 600;
    transition: all 0.2s;
}
.side-link:hover { border-color: #dcc57f; }
.side-link.active {
    background: var(--brand);
    color: #18120a;
    border-color: var(--brand);
}
.subject-dropdown-form { margin-top: 4px; }
.subject-dropdown {
    width: 100%;
    border: 1px solid var(--line);
    border-radius: 10px;
    padding: 9px 10px;
    font-family: inherit;
    font-size: 13px;
    color: #2d3440;
    background: #fff;
}
.main { display: grid; gap: 14px; }
.stats-row {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 10px;
}
.stat-card {
    background: #fff;
    border: 1px solid var(--line);
    border-radius: 12px;
    padding: 14px;
    text-align: center;
}
.stat-card .icon {
    font-size: 24px;
    margin-bottom: 6px;
}
.stat-card .value {
    font-size: 28px;
    font-weight: 800;
    color: var(--brand);
}
.stat-card .label {
    font-size: 11px;
    color: var(--muted);
    margin-top: 4px;
}
.progress-card {
    background: linear-gradient(135deg, #fff 0%, #f8faf4 100%);
    border: 1px solid #d4dfb8;
    border-radius: 12px;
    padding: 16px;
}
.progress-card h3 {
    font-size: 14px;
    color: var(--ink);
    margin-bottom: 10px;
}
.progress-bar-container {
    height: 14px;
    background: #e8ebe4;
    border-radius: 999px;
    overflow: hidden;
}
.progress-bar {
    height: 100%;
    background: linear-gradient(90deg, #4caf50 0%, #8bc34a 100%);
    border-radius: 999px;
    transition: width 0.5s ease;
}
.progress-info {
    display: flex;
    justify-content: space-between;
    margin-top: 8px;
    font-size: 12px;
    color: var(--muted);
}
.row { display: grid; grid-template-columns: 1fr; gap: 14px; }
.card {
    background: var(--surface);
    border: 1px solid var(--line);
    border-radius: 16px;
    padding: 18px;
    box-shadow: 0 10px 24px rgba(24, 30, 43, 0.05);
}
.card h2 {
    font-family: "Source Serif 4", serif;
    font-size: 26px;
    margin-bottom: 4px;
}
.sub { color: var(--muted); font-size: 13px; margin-bottom: 12px; }
.filter-bar { display: flex; flex-wrap: wrap; gap: 8px; margin-bottom: 10px; align-items: center; }
.filter-chip {
    border: 1px solid var(--line);
    color: #2f3743;
    border-radius: 999px;
    padding: 6px 10px;
    font-size: 12px;
    font-weight: 700;
    cursor: pointer;
    transition: all 0.2s;
}
.filter-chip:hover { border-color: #d4c76a; }
.filter-chip.active {
    border-color: #dfc776;
    background: #fff8e2;
    color: #7c5c12;
}
.student-table {
    width: 100%;
    border-collapse: collapse;
}
.student-table th,
.student-table td {
    padding: 12px;
    text-align: left;
    border-bottom: 1px solid var(--line);
}
.student-table th {
    font-size: 11px;
    color: var(--muted);
    text-transform: uppercase;
    letter-spacing: 0.05em;
    font-weight: 700;
    background: #f8fafc;
}
.student-table th a {
    color: var(--muted);
    text-decoration: none;
}
.student-table th a:hover {
    color: var(--brand-deep);
}
.student-table tr:hover {
    background: #fafbfc;
}
.student-name {
    font-weight: 700;
    color: var(--ink);
}
.student-email {
    font-size: 12px;
    color: var(--muted);
}
.completion-cell {
    display: flex;
    align-items: center;
    gap: 10px;
}
.completion-bar {
    flex: 1;
    height: 8px;
    background: #e8ebe4;
    border-radius: 999px;
    overflow: hidden;
    min-width: 80px;
}
.completion-bar-fill {
    height: 100%;
    border-radius: 999px;
    transition: width 0.3s ease;
}
.completion-bar-fill.high { background: linear-gradient(90deg, #4caf50 0%, #8bc34a 100%); }
.completion-bar-fill.medium { background: linear-gradient(90deg, #ff9800 0%, #ffc107 100%); }
.completion-bar-fill.low { background: linear-gradient(90deg, #f44336 0%, #e91e63 100%); }
.completion-text {
    font-size: 12px;
    font-weight: 700;
    min-width: 40px;
}
.badge {
    border-radius: 999px;
    padding: 3px 8px;
    font-size: 11px;
    font-weight: 700;
}
.badge-success { color: #2b7340; background: #e7f7ec; border: 1px solid #bfe7ca; }
.badge-warning { color: #8a6100; background: #fff5db; border: 1px solid #f3e0a7; }
.badge-danger { color: #9a3333; background: #ffecec; border: 1px solid #f4caca; }
.empty { font-size: 13px; color: var(--muted); padding: 24px; border: 1px dashed #cfd6e3; border-radius: 10px; text-align: center; }
@media (max-width: 980px) {
    .layout { grid-template-columns: 1fr; }
    .sidebar { position: static; }
    .row { grid-template-columns: 1fr; }
    .stats-row { grid-template-columns: repeat(2, 1fr); }
    .datetime-wrap { flex-direction: column; align-items: flex-end; gap: 2px; }
    .datetime-time { font-size: 22px; }
    .datetime-date { font-size: 13px; }
    .student-table { display: block; overflow-x: auto; }
}
</style>
</head>
<body>
<header class="topbar">
    <a class="logo" href="../index.php">
        <img src="../images/classbuzz-logo.svg" alt="Classbuzz logo">
        <span>Classbuzz</span>
    </a>
    <div class="topbar-right">
        <div class="datetime-wrap" aria-live="polite">
            <span class="datetime-time" id="liveTime">--:--</span>
            <span class="datetime-date" id="liveDate">--</span>
        </div>
        <button class="logout-btn" onclick="location.href='../auth/logout.php'">Logout</button>
    </div>
</header>

<div class="layout">
    <aside class="sidebar">
        <div class="greeting">
            <strong><?php echo htmlspecialchars($greeting . ', ' . $adminName); ?></strong>
            <span>Administrator access panel</span>
        </div>

        <div class="side-title">Menu</div>
        <div class="side-links">
            <a class="side-link" href="dashboard.php">Dashboard</a>
            <a class="side-link active" href="view_students.php">View Students</a>
            <a class="side-link" href="calendar.php">Calendar</a>
            <a class="side-link" href="push_notifications.php">Push Notifications</a>
        </div>

        <div class="side-title">Filter by Subject</div>
        <form class="subject-dropdown-form" method="GET">
            <input type="hidden" name="sort" value="<?php echo htmlspecialchars($sortBy); ?>">
            <select class="subject-dropdown" name="subject" onchange="this.form.submit()">
                <option value="all" <?php echo $filterSubject === 'all' ? 'selected' : ''; ?>>
                    All Subjects
                </option>
                <?php foreach ($subjects as $subject): ?>
                    <option value="<?php echo htmlspecialchars($subject); ?>" <?php echo $filterSubject === $subject ? 'selected' : ''; ?>>
                        <?php echo htmlspecialchars($subject); ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </form>
    </aside>

    <main class="main">
        <!-- Stats Row -->
        <div class="stats-row">
            <div class="stat-card">
                <div class="icon">👥</div>
                <div class="value"><?php echo $totalStudents; ?></div>
                <div class="label">Total Students</div>
            </div>
            <div class="stat-card">
                <div class="icon">✅</div>
                <div class="value"><?php echo $totalCompletedAll; ?></div>
                <div class="label">Tasks Completed</div>
            </div>
            <div class="stat-card">
                <div class="icon">⏰</div>
                <div class="value"><?php echo $totalPendingAll; ?></div>
                <div class="label">Tasks Pending</div>
            </div>
            <div class="stat-card">
                <div class="icon">📊</div>
                <div class="value"><?php echo $avgCompletion; ?>%</div>
                <div class="label">Avg. Completion</div>
            </div>
        </div>

        <!-- Progress Card -->
        <div class="progress-card">
            <h3>Overall Class Performance</h3>
            <div class="progress-bar-container">
                <div class="progress-bar" style="width: <?php echo $avgCompletion; ?>%"></div>
            </div>
            <div class="progress-info">
                <span><?php echo $avgCompletion; ?>% Average Completion</span>
                <span><?php echo $totalCompletedAll; ?> completed of <?php echo $totalDeadlines; ?> total tasks</span>
            </div>
        </div>

        <section class="card">
            <h2>Student Performance</h2>
            <p class="sub">
                <?php if ($filterSubject !== 'all'): ?>
                    Showing performance for <strong><?php echo htmlspecialchars($filterSubject); ?></strong>
                <?php else: ?>
                    Overall performance across all subjects
                <?php endif; ?>
            </p>

            <div class="filter-bar">
                <span style="font-size: 12px; color: var(--muted); margin-right: 8px;">Sort by:</span>
                <a class="filter-chip <?php echo $sortBy === 'name' ? 'active' : ''; ?>" href="?sort=name&subject=<?php echo urlencode($filterSubject); ?>">Name</a>
                <a class="filter-chip <?php echo $sortBy === 'completion' ? 'active' : ''; ?>" href="?sort=completion&subject=<?php echo urlencode($filterSubject); ?>">Completion Rate</a>
                <a class="filter-chip <?php echo $sortBy === 'completed' ? 'active' : ''; ?>" href="?sort=completed&subject=<?php echo urlencode($filterSubject); ?>">Most Completed</a>
                <a class="filter-chip <?php echo $sortBy === 'pending' ? 'active' : ''; ?>" href="?sort=pending&subject=<?php echo urlencode($filterSubject); ?>">Most Pending</a>
            </div>

            <?php if (count($students) === 0): ?>
                <div class="empty">No students found in the system.</div>
            <?php else: ?>
                <table class="student-table">
                    <thead>
                        <tr>
                            <th><a href="?sort=name&subject=<?php echo urlencode($filterSubject); ?>">Student</a></th>
                            <th><a href="?sort=completed&subject=<?php echo urlencode($filterSubject); ?>">Completed</a></th>
                            <th><a href="?sort=pending&subject=<?php echo urlencode($filterSubject); ?>">Pending</a></th>
                            <th><a href="?sort=completion&subject=<?php echo urlencode($filterSubject); ?>">Completion Rate</a></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($students as $student): ?>
                            <?php
                            $rate = (int)$student['completion_rate'];
                            $barClass = 'high';
                            if ($rate < 50) $barClass = 'low';
                            elseif ($rate < 80) $barClass = 'medium';
                            
                            $badgeClass = 'badge-success';
                            $badgeText = 'On Track';
                            if ($rate < 50) {
                                $badgeClass = 'badge-danger';
                                $badgeText = 'Behind';
                            } elseif ($rate < 80) {
                                $badgeClass = 'badge-warning';
                                $badgeText = 'Improving';
                            }
                            ?>
                            <tr>
                                <td>
                                    <div class="student-name"><?php echo htmlspecialchars($student['name']); ?></div>
                                    <div class="student-email"><?php echo htmlspecialchars($student['email']); ?></div>
                                </td>
                                <td>
                                    <span class="badge badge-success">✓ <?php echo (int)$student['completed_deadlines']; ?></span>
                                </td>
                                <td>
                                    <?php if ((int)$student['pending_deadlines'] > 0): ?>
                                        <span class="badge badge-warning">⏳ <?php echo (int)$student['pending_deadlines']; ?></span>
                                    <?php else: ?>
                                        <span class="badge badge-success">Done</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <div class="completion-cell">
                                        <div class="completion-bar">
                                            <div class="completion-bar-fill <?php echo $barClass; ?>" style="width: <?php echo $rate; ?>%"></div>
                                        </div>
                                        <span class="completion-text"><?php echo $rate; ?>%</span>
                                        <span class="badge <?php echo $badgeClass; ?>"><?php echo $badgeText; ?></span>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </section>
    </main>
</div>

<script>
function updateTopbarDateTime() {
    const liveTime = document.getElementById('liveTime');
    const liveDate = document.getElementById('liveDate');
    if (!liveTime || !liveDate) return;

    const nowDt = new Date();
    liveTime.textContent = nowDt.toLocaleTimeString('en-US', {
        hour: 'numeric',
        minute: '2-digit',
        hour12: true
    });
    liveDate.textContent = nowDt.toLocaleDateString('en-US', {
        weekday: 'long',
        month: 'long',
        day: 'numeric'
    });
}

updateTopbarDateTime();
setInterval(updateTopbarDateTime, 30000);
</script>
</body>
</html>
