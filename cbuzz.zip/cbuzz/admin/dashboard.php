<?php
session_start();
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] != 'admin') {
    header("Location: ../auth/login.php");
    exit;
}
include "../config/db.php";

$adminName = isset($_SESSION['user']['name']) && $_SESSION['user']['name'] !== ''
    ? $_SESSION['user']['name']
    : 'Admin';

$hour = (int)date('H');
$greeting = 'Hello';
if ($hour < 12) {
    $greeting = 'Good morning';
} elseif ($hour < 18) {
    $greeting = 'Good afternoon';
} else {
    $greeting = 'Good evening';
}

$flashSuccess = isset($_SESSION['flash_success']) ? $_SESSION['flash_success'] : '';
$flashError = isset($_SESSION['flash_error']) ? $_SESSION['flash_error'] : '';
unset($_SESSION['flash_success'], $_SESSION['flash_error']);

$view = isset($_GET['view']) ? $_GET['view'] : 'upcoming';
$allowedViews = ['all', 'upcoming', 'completed', 'past_due', 'new'];
if (!in_array($view, $allowedViews, true)) {
    $view = 'upcoming';
}

$hasCompletionTable = false;
$tableCheck = $conn->query("SHOW TABLES LIKE 'deadline_completions'");
if ($tableCheck && $tableCheck->num_rows > 0) {
    $hasCompletionTable = true;
}

if ($hasCompletionTable) {
    $query = "
        SELECT
            d.id,
            d.title,
            d.description,
            d.deadline_datetime,
            COALESCE(c.completed_users, 0) AS completed_users,
            COALESCE(c.completion_rate, 0) AS completion_rate
        FROM deadlines d
        LEFT JOIN (
            SELECT 
                deadline_id, 
                COUNT(*) AS completed_users,
                ROUND(COUNT(*) * 100.0 / (SELECT COUNT(*) FROM users WHERE role='student'), 1) AS completion_rate
            FROM deadline_completions
            GROUP BY deadline_id
        ) c ON c.deadline_id = d.id
        ORDER BY d.deadline_datetime ASC
    ";
} else {
    $query = "
        SELECT
            d.id,
            d.title,
            d.description,
            d.deadline_datetime,
            0 AS completed_users,
            0 AS completion_rate
        FROM deadlines d
        ORDER BY d.deadline_datetime ASC
    ";
}

$res = $conn->query($query);
$allDeadlines = [];
$counts = [
    'all' => 0,
    'upcoming' => 0,
    'completed' => 0,
    'past_due' => 0,
    'new' => 0
];

$nowTs = time();
$subjectStats = [];

while ($res && $row = $res->fetch_assoc()) {
    $deadlineTs = strtotime($row['deadline_datetime']);
    if ((int)$row['completed_users'] > 0) {
        $state = 'completed';
    } elseif ($deadlineTs !== false && $deadlineTs < $nowTs) {
        $state = 'past_due';
    } else {
        $state = 'upcoming';
    }

    $row['state'] = $state;
    $allDeadlines[] = $row;

    $counts['all']++;
    $counts[$state]++;

    $subject = trim($row['title']);
    if (!isset($subjectStats[$subject])) {
        $subjectStats[$subject] = ['total' => 0, 'completed' => 0];
    }
    $subjectStats[$subject]['total']++;
    if ($state === 'completed' || $deadlineTs !== false && $deadlineTs < $nowTs) {
        $subjectStats[$subject]['completed']++;
    }
}

$subjects = ['PEH 300', 'ICT LECTURE', 'ICT 400', 'PILOSOPHY', 'RESEARCH', 'ENTREPRENEUR', 'IMMERSION'];
$subjectFilter = isset($_GET['subject']) ? trim($_GET['subject']) : 'all';
if ($subjectFilter !== 'all' && !in_array($subjectFilter, $subjects, true) && $subjectFilter !== 'Other') {
    $subjectFilter = 'all';
}

$viewFilteredDeadlines = [];
foreach ($allDeadlines as $deadline) {
    if ($view === 'all' || $deadline['state'] === $view) {
        $viewFilteredDeadlines[] = $deadline;
    }
}

$subjectCounts = [];
foreach ($subjects as $subject) {
    $subjectCounts[$subject] = 0;
}
$subjectCounts['Other'] = 0;
foreach ($viewFilteredDeadlines as $deadline) {
    $subject = isset($deadline['title']) ? trim($deadline['title']) : '';
    if (isset($subjectCounts[$subject])) {
        $subjectCounts[$subject]++;
    } else {
        $subjectCounts['Other']++;
    }
}

$filteredDeadlines = [];
$newDeadlineIds = [];
$newRes = $conn->query("SELECT id FROM deadlines ORDER BY id DESC LIMIT 8");
if ($newRes) {
    while ($newRow = $newRes->fetch_assoc()) {
        $newDeadlineIds[] = (int)$newRow['id'];
    }
}
$counts['new'] = count($newDeadlineIds);

foreach ($viewFilteredDeadlines as $deadline) {
    $taskSubject = isset($deadline['title']) ? trim($deadline['title']) : '';
    $normalizedTaskSubject = in_array($taskSubject, $subjects, true) ? $taskSubject : 'Other';
    $isNew = in_array((int)$deadline['id'], $newDeadlineIds, true);
    $viewMatch = ($view === 'new') ? $isNew : true;
    if (($subjectFilter === 'all' || $subjectFilter === $normalizedTaskSubject) && $viewMatch) {
        $filteredDeadlines[] = $deadline;
    }
}

$subjectColumns = [];
foreach ($subjects as $subject) {
    $subjectColumns[$subject] = [];
}
$subjectColumns['Other'] = [];

foreach ($filteredDeadlines as $deadline) {
    $subject = isset($deadline['title']) ? trim($deadline['title']) : '';
    if (isset($subjectColumns[$subject])) {
        $subjectColumns[$subject][] = $deadline;
    } else {
        $subjectColumns['Other'][] = $deadline;
    }
}

$calendarStatusByDate = [];
$statusPriority = ['completed' => 1, 'upcoming' => 2, 'past_due' => 3];
foreach ($allDeadlines as $deadline) {
    $taskSubject = isset($deadline['title']) ? trim($deadline['title']) : '';
    $normalizedTaskSubject = in_array($taskSubject, $subjects, true) ? $taskSubject : 'Other';
    if ($subjectFilter !== 'all' && $subjectFilter !== $normalizedTaskSubject) {
        continue;
    }

    $dateKey = substr((string)$deadline['deadline_datetime'], 0, 10);
    if ($dateKey === '') {
        continue;
    }

    $state = isset($deadline['state']) ? $deadline['state'] : 'upcoming';
    if (!isset($statusPriority[$state])) {
        continue;
    }

    if (!isset($calendarStatusByDate[$dateKey])) {
        $calendarStatusByDate[$dateKey] = $state;
        continue;
    }

    $existingState = $calendarStatusByDate[$dateKey];
    if ($statusPriority[$state] > $statusPriority[$existingState]) {
        $calendarStatusByDate[$dateKey] = $state;
    }
}

$defaultDeadline = date('Y-m-d\TH:i', strtotime('+1 day'));
$minDeadline = date('Y-m-d\TH:i');

$studentCount = 0;
$studentRes = $conn->query("SELECT COUNT(*) as cnt FROM users WHERE role = 'student'");
if ($studentRes) {
    $studentCount = (int)$studentRes->fetch_assoc()['cnt'];
}

$overallCompletion = $counts['all'] > 0 ? round(($counts['completed'] / $counts['all']) * 100) : 0;
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Admin Dashboard - Classbuzz</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Sora:wght@400;500;600;700;800&family=Source+Serif+4:wght@600;700&display=swap" rel="stylesheet">
<style>
:root {
    --bg: #f4f6f8;
    --surface: #ffffff;
    --text: #1e2228;
    --muted: #5d6674;
    --brand: #cfa430;
    --brand-deep: #9f7d1d;
    --ink: #101216;
    --line: #e6e9ef;
    --danger: #d94d4d;
    --success: #2f7a46;
}
* { box-sizing: border-box; margin: 0; padding: 0; }
body {
    font-family: "Sora", sans-serif;
    background: radial-gradient(circle at 10% -10%, #fff7de 0%, var(--bg) 46%), var(--bg);
    color: var(--text);
    min-height: 100vh;
}
a { text-decoration: none; }
.topbar {
    position: sticky;
    top: 0;
    z-index: 30;
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 14px 24px;
    background: rgba(255, 255, 255, 0.88);
    backdrop-filter: blur(8px);
    border-bottom: 1px solid var(--line);
}
.logo {
    display: flex;
    align-items: center;
    gap: 10px;
    color: var(--ink);
    font-weight: 700;
    font-size: 21px;
}
.logo img { width: 32px; height: 32px; }
.logout-btn {
    border: none;
    background: var(--danger);
    color: #fff;
    border-radius: 999px;
    padding: 9px 14px;
    cursor: pointer;
    font-weight: 600;
}
.topbar-right {
    display: flex;
    align-items: center;
    gap: 14px;
}
.datetime-wrap {
    display: flex;
    align-items: baseline;
    gap: 12px;
    color: #2f3339;
}
.datetime-time {
    font-size: 28px;
    font-weight: 700;
    line-height: 1;
    letter-spacing: 0.01em;
}
.datetime-date {
    font-size: 16px;
    color: #666c76;
    font-weight: 600;
    line-height: 1;
}
.layout {
    max-width: 1320px;
    margin: 18px auto;
    padding: 0 16px 24px;
    display: grid;
    grid-template-columns: 290px 1fr;
    gap: 18px;
}
.sidebar {
    background: var(--surface);
    border: 1px solid var(--line);
    border-radius: 16px;
    padding: 14px;
    align-self: start;
    position: sticky;
    top: 78px;
    max-height: calc(100vh - 96px);
    overflow-y: auto;
    box-shadow: 0 10px 22px rgba(30, 38, 53, 0.06);
}
.greeting {
    background: linear-gradient(120deg, #171a20 0%, #232834 100%);
    color: #fff;
    border-radius: 12px;
    padding: 12px;
    margin-bottom: 14px;
}
.greeting strong { display: block; font-size: 16px; }
.greeting span { color: #d4d9e7; font-size: 12px; }
.side-title {
    font-size: 11px;
    color: var(--muted);
    text-transform: uppercase;
    letter-spacing: 0.1em;
    margin: 12px 0 8px;
}
.side-links { display: grid; gap: 8px; }
.side-link {
    border: 1px solid var(--line);
    border-radius: 10px;
    padding: 9px 10px;
    color: #2d3440;
    font-size: 14px;
    font-weight: 600;
    transition: all 0.2s;
}
.side-link:hover { border-color: #dcc57f; }
.side-link.active {
    background: var(--brand);
    color: #18120a;
    border-color: var(--brand);
}
.subject-dropdown-form { margin-top: 4px; }
.subject-dropdown {
    width: 100%;
    border: 1px solid var(--line);
    border-radius: 10px;
    padding: 9px 10px;
    font-family: inherit;
    font-size: 13px;
    color: #2d3440;
    background: #fff;
}
.calendar-widget {
    border: 1px solid #d8e5f7;
    border-radius: 14px;
    background: #fff;
    overflow: hidden;
}
.cal-head {
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 8px;
    padding: 10px;
    background: linear-gradient(90deg, #e9f5ff 0%, #edf3ff 100%);
    border-bottom: 1px solid #d8e5f7;
}
.cal-left { display: flex; align-items: center; gap: 8px; }
.cal-title { font-size: 13px; font-weight: 800; color: #2b3340; min-width: 112px; text-align: center; }
.cal-nav {
    border: 1px solid #bfd7f2;
    background: #f8fcff;
    border-radius: 8px;
    width: 30px;
    height: 30px;
    cursor: pointer;
}
.cal-view { display: flex; gap: 6px; align-items: center; }
.cal-pill {
    border: 1px solid #bcd7f7;
    background: #f7fbff;
    color: #2e76c9;
    border-radius: 999px;
    font-size: 11px;
    font-weight: 700;
    padding: 5px 10px;
}
.cal-pill.active { background: #1990e6; color: #fff; border-color: #1990e6; }
.cal-today {
    border: 1px solid #1990e6;
    background: #fff;
    color: #1990e6;
    border-radius: 10px;
    font-size: 11px;
    font-weight: 800;
    padding: 6px 9px;
    cursor: pointer;
}
.cal-weekdays, .cal-days {
    display: grid;
    grid-template-columns: repeat(7, 1fr);
    gap: 4px;
    padding: 8px 10px 0;
}
.cal-weekdays span { font-size: 10px; color: var(--muted); text-align: center; padding: 2px 0; font-weight: 700; }
.cal-day {
    border: 1px solid transparent;
    background: #fff;
    border-radius: 8px;
    height: 32px;
    font-size: 12px;
    cursor: pointer;
    color: #2e3745;
    position: relative;
}
.cal-day:hover { border-color: #b8d5f5; }
.cal-day.muted { color: #aab2bf; }
.cal-day.active {
    outline: 2px solid #2f80e7;
    border-color: #2f80e7;
    z-index: 2;
}
.cal-day.today { border-color: #cfd7e6; }
.cal-day.status-upcoming { background: #eaf3ff; border-color: #9fc1ee; color: #2c65bc; font-weight: 700; }
.cal-day.status-past_due { background: #ffecee; border-color: #edb0b5; color: #b43a3f; font-weight: 700; }
.cal-day.status-completed { background: #eaf9ef; border-color: #a8d9b6; color: #2f7c47; font-weight: 700; }
.cal-clear {
    margin: 8px 10px 10px;
    width: calc(100% - 20px);
    border: 1px solid #d8e3f2;
    background: #f9fbff;
    color: var(--muted);
    border-radius: 8px;
    padding: 7px;
    font-size: 12px;
    font-weight: 600;
    cursor: pointer;
}
.cal-legend {
    display: flex;
    gap: 10px;
    padding: 0 10px 8px;
    align-items: center;
    flex-wrap: wrap;
}
.cal-legend span {
    font-size: 10px;
    color: #4f5968;
    display: inline-flex;
    align-items: center;
    gap: 5px;
}
.dot {
    width: 8px;
    height: 8px;
    border-radius: 999px;
    display: inline-block;
}
.dot-red { background: #d86060; }
.dot-blue { background: #4f89d7; }
.dot-green { background: #3fa464; }
.main { display: grid; gap: 14px; }
.quick-overview {
    display: grid;
    grid-template-columns: repeat(4, minmax(0, 1fr));
    gap: 10px;
}
.overview-item {
    display: block;
    border: 1px solid var(--line);
    border-radius: 12px;
    background: #fff;
    padding: 10px;
    transition: all 0.2s;
}
.overview-item:hover {
    border-color: #d8c38a;
    box-shadow: 0 6px 16px rgba(26, 33, 45, 0.06);
    transform: translateY(-2px);
}
.overview-item strong {
    display: block;
    font-size: 18px;
    color: #1f2735;
}
.overview-item span {
    font-size: 11px;
    color: var(--muted);
}
.stats-row {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 10px;
}
.stat-card {
    background: #fff;
    border: 1px solid var(--line);
    border-radius: 12px;
    padding: 14px;
    text-align: center;
}
.stat-card .icon {
    font-size: 24px;
    margin-bottom: 6px;
}
.stat-card .value {
    font-size: 28px;
    font-weight: 800;
    color: var(--brand);
}
.stat-card .label {
    font-size: 11px;
    color: var(--muted);
    margin-top: 4px;
}
.progress-card {
    background: linear-gradient(135deg, #fff 0%, #f8faf4 100%);
    border: 1px solid #d4dfb8;
    border-radius: 12px;
    padding: 16px;
}
.progress-card h3 {
    font-size: 14px;
    color: var(--ink);
    margin-bottom: 10px;
}
.progress-bar-container {
    height: 14px;
    background: #e8ebe4;
    border-radius: 999px;
    overflow: hidden;
}
.progress-bar {
    height: 100%;
    background: linear-gradient(90deg, #4caf50 0%, #8bc34a 100%);
    border-radius: 999px;
    transition: width 0.5s ease;
}
.progress-info {
    display: flex;
    justify-content: space-between;
    margin-top: 8px;
    font-size: 12px;
    color: var(--muted);
}
.row { display: grid; grid-template-columns: 1fr; gap: 14px; }
.card {
    background: var(--surface);
    border: 1px solid var(--line);
    border-radius: 16px;
    padding: 18px;
    box-shadow: 0 10px 24px rgba(24, 30, 43, 0.05);
}
.card h2 {
    font-family: "Source Serif 4", serif;
    font-size: 26px;
    margin-bottom: 4px;
}
.sub { color: var(--muted); font-size: 13px; margin-bottom: 12px; }
.alert {
    border-radius: 10px;
    padding: 9px 10px;
    font-size: 13px;
    margin-bottom: 10px;
}
.alert-success { background: #e9f8ed; color: var(--success); border: 1px solid #bde4c8; }
.alert-error { background: #fff1f1; color: #a62d2d; border: 1px solid #ffd5d5; }
.field { margin-bottom: 10px; }
label { display: block; font-size: 12px; color: var(--muted); margin-bottom: 5px; font-weight: 600; }
input, textarea, select {
    width: 100%;
    border: 1px solid var(--line);
    border-radius: 10px;
    padding: 10px 11px;
    font-size: 14px;
    font-family: inherit;
}
textarea { min-height: 90px; resize: vertical; }
.quick-picks { display: flex; gap: 6px; flex-wrap: wrap; margin-bottom: 8px; }
.pick-btn {
    border: 1px solid var(--line);
    background: #fff;
    color: var(--muted);
    border-radius: 999px;
    padding: 5px 9px;
    font-size: 11px;
    cursor: pointer;
    transition: all 0.2s;
}
.pick-btn:hover {
    border-color: var(--brand);
    color: var(--brand-deep);
}
.btn-row { display: grid; grid-template-columns: 1fr auto; gap: 8px; }
.submit-btn {
    border: none;
    border-radius: 10px;
    padding: 10px 12px;
    background: var(--brand);
    color: #18120a;
    font-weight: 700;
    cursor: pointer;
    transition: background 0.2s;
}
.submit-btn:hover {
    background: var(--brand-deep);
}
.reset-btn {
    border: 1px solid var(--line);
    border-radius: 10px;
    padding: 10px 12px;
    background: #fff;
    color: var(--muted);
    font-weight: 600;
    cursor: pointer;
}
.filter-bar { display: flex; flex-wrap: wrap; gap: 8px; margin-bottom: 10px; }
.filter-chip {
    border: 1px solid var(--line);
    color: #2f3743;
    border-radius: 999px;
    padding: 6px 10px;
    font-size: 12px;
    font-weight: 700;
    cursor: pointer;
    transition: all 0.2s;
}
.filter-chip:hover { border-color: #d4c76a; }
.filter-chip.active {
    border-color: #dfc776;
    background: #fff8e2;
    color: #7c5c12;
}
.task-list { display: grid; gap: 8px; }
.task-scroll {
    max-height: 60vh;
    overflow-y: auto;
    padding-right: 6px;
}
.task-scroll::-webkit-scrollbar { width: 8px; }
.task-scroll::-webkit-scrollbar-thumb {
    background: #d6dce8;
    border-radius: 999px;
}
.task-scroll::-webkit-scrollbar-track { background: #f4f6fa; border-radius: 999px; }

/* Reminder dropdown styles */
.reminder-dropdown-container { display: flex; flex-direction: column; gap: 8px; }
.reminder-dropdown-container select { width: 100%; border: 1px solid var(--line); border-radius: 10px; padding: 10px 11px; font-size: 14px; font-family: inherit; background: #fff; }
.reminder-hint { color: var(--muted); font-size: 11px; }
.selected-reminders { display: flex; flex-wrap: wrap; gap: 6px; min-height: 28px; }
.reminder-tag { display: inline-flex; align-items: center; gap: 6px; background: linear-gradient(120deg, #fff8e6 0%, #fff3cc 100%); border: 1px solid #e6c86e; border-radius: 999px; padding: 4px 10px; font-size: 12px; font-weight: 600; color: #7c5c12; }
.reminder-tag button { background: none; border: none; color: #8f6b1a; cursor: pointer; font-size: 16px; line-height: 1; padding: 0; width: 16px; height: 16px; display: flex; align-items: center; justify-content: center; border-radius: 50%; }
.reminder-tag button:hover { background: #e6c86e; color: #18120a; }

.subject-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));
    gap: 12px;
}
.subject-col {
    border: 1px solid var(--line);
    border-radius: 12px;
    padding: 12px;
    background: #fbfcff;
}
.subject-col h3 {
    font-size: 13px;
    color: #273040;
    margin-bottom: 8px;
    display: flex;
    align-items: center;
    justify-content: space-between;
}
.subject-progress {
    font-size: 10px;
    background: #e8f5e9;
    color: #2e7d32;
    padding: 2px 6px;
    border-radius: 999px;
    font-weight: 600;
}
.task-item {
    border: 1px solid var(--line);
    border-left: 4px solid #d4b458;
    border-radius: 10px;
    padding: 10px;
    background: #fff;
    transition: transform 0.2s, box-shadow 0.2s;
}
.task-item:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(0,0,0,0.08);
}
.task-item[data-state="completed"] { border-left-color: #55a76a; background: #f8fcf9; }
.task-item[data-state="past_due"] { border-left-color: #d46363; background: #fff8f8; }
.task-head { display: flex; justify-content: space-between; gap: 10px; align-items: center; }
.task-title { font-size: 14px; font-weight: 700; color: #202734; }
.badge {
    border-radius: 999px;
    padding: 3px 8px;
    font-size: 11px;
    font-weight: 700;
}
.badge-upcoming { color: #8e6510; background: #fff5db; border: 1px solid #f3e0a7; }
.badge-completed { color: #2b7340; background: #e7f7ec; border: 1px solid #bfe7ca; }
.badge-past { color: #9a3333; background: #ffecec; border: 1px solid #f4caca; }
.task-desc { margin-top: 5px; color: #505968; font-size: 13px; }
.task-meta {
    display: flex;
    gap: 12px;
    margin-top: 6px;
    font-size: 11px;
    color: var(--muted);
}
.task-meta .students {
    color: var(--success);
    font-weight: 600;
}
.empty { font-size: 13px; color: var(--muted); padding: 8px; border: 1px dashed #cfd6e3; border-radius: 10px; text-align: center; }
.quick-actions {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 8px;
    margin-bottom: 12px;
}
.action-btn {
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 6px;
    padding: 8px;
    border: 1px solid var(--line);
    border-radius: 8px;
    background: #fff;
    color: var(--text);
    font-size: 12px;
    font-weight: 600;
    cursor: pointer;
    transition: all 0.2s;
}
.action-btn:hover {
    border-color: var(--brand);
    background: #fffbf0;
}
@media (max-width: 980px) {
    .layout { grid-template-columns: 1fr; }
    .sidebar { position: static; }
    .row { grid-template-columns: 1fr; }
    .quick-overview { grid-template-columns: repeat(2, minmax(0, 1fr)); }
    .stats-row { grid-template-columns: repeat(2, 1fr); }
    .datetime-wrap { flex-direction: column; align-items: flex-end; gap: 2px; }
    .datetime-time { font-size: 22px; }
    .datetime-date { font-size: 13px; }
    .quick-actions { grid-template-columns: 1fr 1fr; }
}
@media (max-width: 1200px) {
    .layout { grid-template-columns: 270px 1fr; }
    .subject-grid { grid-template-columns: repeat(auto-fit, minmax(230px, 1fr)); }
}
</style>
</head>
<body>
<header class="topbar">
    <a class="logo" href="../index.php">
        <img src="../images/classbuzz-logo.svg" alt="Classbuzz logo">
        <span>Classbuzz</span>
    </a>
    <div class="topbar-right">
        <div class="datetime-wrap" aria-live="polite">
            <span class="datetime-time" id="liveTime">--:--</span>
            <span class="datetime-date" id="liveDate">--</span>
        </div>
        <button class="logout-btn" onclick="location.href='../auth/logout.php'">Logout</button>
    </div>
</header>

<div class="layout">
    <aside class="sidebar">
        <div class="greeting">
            <strong><?php echo htmlspecialchars($greeting . ', ' . $adminName); ?></strong>
            <span>Administrator access panel</span>
        </div>

        <div class="side-title">Menu</div>
        <div class="side-links">
            <a class="side-link" href="dashboard.php">Dashboard</a>
            <a class="side-link" href="view_students.php">View Students</a>
            <a class="side-link" href="calendar.php">Calendar</a>
            <a class="side-link" href="push_notifications.php">Push Notifications</a>
        </div>

        <div class="side-title">Subjects</div>
        <form class="subject-dropdown-form" method="GET">
            <input type="hidden" name="view" value="<?php echo htmlspecialchars($view); ?>">
            <select class="subject-dropdown" name="subject" onchange="this.form.submit()">
                <option value="all" <?php echo $subjectFilter === 'all' ? 'selected' : ''; ?>>
                    All Subjects (<?php echo count($viewFilteredDeadlines); ?>)
                </option>
                <?php foreach ($subjectCounts as $subjectName => $count): ?>
                    <option value="<?php echo htmlspecialchars($subjectName); ?>" <?php echo $subjectFilter === $subjectName ? 'selected' : ''; ?>>
                        <?php echo htmlspecialchars($subjectName); ?> (<?php echo (int)$count; ?>)
                    </option>
                <?php endforeach; ?>
            </select>
        </form>

        <div class="side-title">Calendar</div>
        <div class="calendar-widget" id="miniCalendar">
            <div class="cal-head">
                <div class="cal-left">
                    <button class="cal-nav" type="button" id="calPrev">&#8249;</button>
                    <div class="cal-title" id="calTitle"></div>
                    <button class="cal-nav" type="button" id="calNext">&#8250;</button>
                </div>
                <button class="cal-today" type="button" id="calToday">Today</button>
            </div>
            <div class="cal-weekdays">
                <span>Su</span><span>Mo</span><span>Tu</span><span>We</span><span>Th</span><span>Fr</span><span>Sa</span>
            </div>
            <div class="cal-days" id="calDays"></div>
            <div class="cal-legend">
                <span><i class="dot dot-red"></i>Due</span>
                <span><i class="dot dot-blue"></i>Upcoming</span>
                <span><i class="dot dot-green"></i>Done</span>
            </div>
            <button class="cal-clear" type="button" id="calClear">Show All</button>
        </div>
    </aside>

    <main class="main" id="dashboard">
        <div class="stats-row">
            <div class="stat-card">
                <div class="icon">📚</div>
                <div class="value"><?php echo $counts['all']; ?></div>
                <div class="label">Total Deadlines</div>
            </div>
            <div class="stat-card">
                <div class="icon">✅</div>
                <div class="value"><?php echo $counts['completed']; ?></div>
                <div class="label">Completed</div>
            </div>
            <div class="stat-card">
                <div class="icon">⏰</div>
                <div class="value"><?php echo $counts['upcoming']; ?></div>
                <div class="label">Upcoming</div>
            </div>
            <div class="stat-card">
                <div class="icon">👥</div>
                <div class="value"><?php echo $studentCount; ?></div>
                <div class="label">Students</div>
            </div>
        </div>

        <div class="progress-card">
            <h3>Overall Completion Rate</h3>
            <div class="progress-bar-container">
                <div class="progress-bar" style="width: <?php echo $overallCompletion; ?>%"></div>
            </div>
            <div class="progress-info">
                <span><?php echo $overallCompletion; ?>% Complete</span>
                <span><?php echo $counts['completed']; ?> of <?php echo $counts['all']; ?> tasks</span>
            </div>
        </div>

        <section class="quick-overview">
            <a class="overview-item" href="?view=upcoming&subject=<?php echo urlencode($subjectFilter); ?>">
                <strong><?php echo (int)$counts['upcoming']; ?></strong>
                <span>Upcoming</span>
            </a>
            <a class="overview-item" href="?view=completed&subject=<?php echo urlencode($subjectFilter); ?>">
                <strong><?php echo (int)$counts['completed']; ?></strong>
                <span>Completed</span>
            </a>
            <a class="overview-item" href="?view=past_due&subject=<?php echo urlencode($subjectFilter); ?>">
                <strong><?php echo (int)$counts['past_due']; ?></strong>
                <span>Past Due</span>
            </a>
            <a class="overview-item" href="?view=all&subject=all">
                <strong><?php echo htmlspecialchars($subjectFilter === 'all' ? 'All' : $subjectFilter); ?></strong>
                <span>Subject View</span>
            </a>
        </section>

        <section class="row">
            <section class="card">
                <h2>Add Deadline</h2>
                <p class="sub">Create tasks with subject, description, and due time.</p>

                <?php if ($flashSuccess !== ''): ?>
                    <div class="alert alert-success"><?php echo htmlspecialchars($flashSuccess); ?></div>
                <?php endif; ?>
                <?php if ($flashError !== ''): ?>
                    <div class="alert alert-error"><?php echo htmlspecialchars($flashError); ?></div>
                <?php endif; ?>

                <div class="quick-actions">
                    <button class="action-btn" onclick="sendTestPush()">📣 Send Test Push</button>
                    <button class="action-btn" onclick="runScheduler()">⏱ Run Scheduler</button>
                    <button class="action-btn" onclick="checkReminders()">🔔 Check Reminders</button>
                    <button class="action-btn" onclick="run30sScheduler()">⚡ 30s Reminder</button>
                </div>

                <form action="add_deadline.php" method="POST">
                    <div class="field">
                        <label for="title">Subject</label>
                        <select id="title" name="title" required>
                            <?php foreach ($subjects as $subject): ?>
                                <option value="<?php echo htmlspecialchars($subject); ?>"><?php echo htmlspecialchars($subject); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="field">
                        <label for="description">Description</label>
                        <textarea id="description" name="description" placeholder="Add instructions or notes (optional)"></textarea>
                    </div>
                    
                    <div class="field">
                        <label>Reminder Times (select up to 3)</label>
                        <div class="reminder-dropdown-container">
                            <select id="reminderSelect" onchange="addReminderTime()">
                                <option value="">Add reminder time...</option>
                                <option value="1">1 minute before</option>
                                <option value="5">5 minutes before</option>
                                <option value="15">15 minutes before</option>
                                <option value="30">30 minutes before</option>
                                <option value="60">1 hour before</option>
                                <option value="120">2 hours before</option>
                                <option value="360">6 hours before</option>
                                <option value="720">12 hours before</option>
                                <option value="1440">24 hours before</option>
                            </select>
                            <div id="selectedReminders" class="selected-reminders"></div>
                            <input type="hidden" name="reminder_times" id="reminderTimes">
                            <small class="reminder-hint">Select up to 3 reminder times</small>
                        </div>
                    </div>
                    
                    <div class="field">
                        <label>Assign To (select students)</label>
                        <div class="student-select-container">
                            <select id="studentSelect" onchange="addStudent()">
                                <option value="">Select a student...</option>
                                <?php
                                $students = $conn->query("SELECT id, name, email FROM users WHERE role = 'student' ORDER BY name");
                                while ($student = $students->fetch_assoc()) {
                                    echo '<option value="' . $student['id'] . '">' . htmlspecialchars($student['name']) . ' (' . htmlspecialchars($student['email']) . ')</option>';
                                }
                                ?>
                            </select>
                            <div id="selectedStudents" class="selected-students"></div>
                            <input type="hidden" name="assigned_students" id="assignedStudents">
                        </div>
                    </div>
                    
                    <div class="field">
                        <label for="deadline">Deadline</label>
                        <div class="quick-picks">
                            <button class="pick-btn" type="button" data-hours="24">+24h</button>
                            <button class="pick-btn" type="button" data-hours="48">+48h</button>
                            <button class="pick-btn" type="button" data-hours="72">+72h</button>
                            <button class="pick-btn" type="button" data-days="7">+1 Week</button>
                        </div>
                        <input id="deadline" type="datetime-local" name="deadline" min="<?php echo $minDeadline; ?>" value="<?php echo $defaultDeadline; ?>" required>
                    </div>
                    <div class="btn-row">
                        <button class="submit-btn" type="submit">Add Deadline</button>
                        <button class="reset-btn" type="reset">Clear</button>
                    </div>
                </form>
            </section>
        </section>

        <section class="card">
            <h2>Task Overview</h2>
            <p class="sub">View deadlines by subject and status.</p>

            <div class="filter-bar">
                <a class="filter-chip <?php echo $view === 'all' ? 'active' : ''; ?>" href="?view=all&subject=<?php echo urlencode($subjectFilter); ?>">All (<?php echo (int)$counts['all']; ?>)</a>
                <a class="filter-chip <?php echo $view === 'upcoming' ? 'active' : ''; ?>" href="?view=upcoming&subject=<?php echo urlencode($subjectFilter); ?>">Upcoming (<?php echo (int)$counts['upcoming']; ?>)</a>
                <a class="filter-chip <?php echo $view === 'completed' ? 'active' : ''; ?>" href="?view=completed&subject=<?php echo urlencode($subjectFilter); ?>">Completed (<?php echo (int)$counts['completed']; ?>)</a>
                <a class="filter-chip <?php echo $view === 'past_due' ? 'active' : ''; ?>" href="?view=past_due&subject=<?php echo urlencode($subjectFilter); ?>">Past Due (<?php echo (int)$counts['past_due']; ?>)</a>
                <a class="filter-chip <?php echo $view === 'new' ? 'active' : ''; ?>" href="?view=new&subject=<?php echo urlencode($subjectFilter); ?>">New (<?php echo (int)$counts['new']; ?>)</a>
            </div>

            <div class="task-scroll">
            <div class="subject-grid" id="taskList">
                <?php if (count($filteredDeadlines) === 0): ?>
                    <div class="empty">No tasks found for this filter.</div>
                <?php else: ?>
                    <?php foreach ($subjectColumns as $subject => $items): ?>
                        <?php if ($subjectFilter === 'all' && count($items) === 0) { continue; } ?>
                        <section class="subject-col">
                            <h3>
                                <?php echo htmlspecialchars($subject); ?>
                                (<?php echo count($items); ?>)
                            </h3>
                            <?php if (count($items) === 0): ?>
                                <div class="empty">No tasks.</div>
                            <?php else: ?>
                                <div class="task-list">
                                    <?php foreach ($items as $d): ?>
                                        <?php
                                        $badgeClass = 'badge-upcoming';
                                        $badgeText = 'Upcoming';
                                        if ($d['state'] === 'completed') {
                                            $badgeClass = 'badge-completed';
                                            $badgeText = 'Completed';
                                        } elseif ($d['state'] === 'past_due') {
                                            $badgeClass = 'badge-past';
                                            $badgeText = 'Past Due';
                                        }
                                        ?>
                                        <article class="task-item" data-state="<?php echo htmlspecialchars($d['state']); ?>" data-date="<?php echo htmlspecialchars(substr($d['deadline_datetime'], 0, 10)); ?>">
                                            <div class="task-head">
                                                <div class="task-title"><?php echo htmlspecialchars($d['title']); ?></div>
                                                <span class="badge <?php echo $badgeClass; ?>"><?php echo $badgeText; ?></span>
                                            </div>
                                            <div class="task-desc"><?php echo trim((string)$d['description']) !== '' ? htmlspecialchars($d['description']) : 'No description provided.'; ?></div>
                                            <div class="task-meta">
                                                <span>📅 <?php echo htmlspecialchars($d['deadline_datetime']); ?></span>
                                                <span class="students">✓ <?php echo (int)$d['completed_users']; ?> students completed</span>
                                            </div>
                                        </article>
                                    <?php endforeach; ?>
                                </div>
                            <?php endif; ?>
                        </section>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
            </div>
        </section>

    </main>
</div>

<script>
function updateTopbarDateTime() {
    const liveTime = document.getElementById('liveTime');
    const liveDate = document.getElementById('liveDate');
    if (!liveTime || !liveDate) return;

    const nowDt = new Date();
    liveTime.textContent = nowDt.toLocaleTimeString('en-US', {
        hour: 'numeric',
        minute: '2-digit',
        hour12: true
    });
    liveDate.textContent = nowDt.toLocaleDateString('en-US', {
        weekday: 'long',
        month: 'long',
        day: 'numeric'
    });
}

updateTopbarDateTime();
setInterval(updateTopbarDateTime, 30000);

const deadlineInput = document.getElementById('deadline');
document.querySelectorAll('.pick-btn').forEach((btn) => {
    btn.addEventListener('click', () => {
        const hours = parseInt(btn.dataset.hours, 10);
        const days = parseInt(btn.dataset.days, 10);
        const now = new Date();
        if (hours) {
            now.setHours(now.getHours() + hours);
        } else if (days) {
            now.setDate(now.getDate() + days);
        }
        const localIso = new Date(now.getTime() - now.getTimezoneOffset() * 60000)
            .toISOString()
            .slice(0, 16);
        deadlineInput.value = localIso;
    });
});

function sendTestPush() {
    if (confirm('Send test push notification to all registered devices?')) {
        fetch('../api/send_push.php?test=1')
            .then(r => r.json())
            .then(data => {
                alert('Test push sent!\nSent: ' + data.sent + '\nFailed: ' + data.failed);
            })
            .catch(err => alert('Error: ' + err.message));
    }
}

function runScheduler() {
    if (confirm('Run scheduler now? This will check and send pending reminders.')) {
        fetch('../api/scheduler.php')
            .then(r => r.text())
            .then(data => {
                alert('Scheduler completed!');
            })
            .catch(err => alert('Error: ' + err.message));
    }
}

function checkReminders() {
    if (confirm('Check and send all reminders?')) {
        fetch('../api/check_reminders.php?force_all=1')
            .then(r => r.json())
            .then(data => {
                alert('Reminder check completed!\nTriggered: ' + data.triggered + '\nSent: ' + data.sent + '\nFailed: ' + data.failed);
            })
            .catch(err => alert('Error: ' + err.message));
    }
}

function run30sScheduler() {
    if (confirm('Run 30-second reminder scheduler now?')) {
        fetch('../api/scheduler_30s.php?force_all=1')
            .then(r => r.json())
            .then(data => {
                alert('30s Scheduler completed!\nTriggered: ' + data.triggered + '\nSent: ' + data.sent + '\nFailed: ' + data.failed);
            })
            .catch(err => alert('Error: ' + err.message));
    }
}

let selectedStudentsList = [];
let selectedRemindersList = [];

function addReminderTime() {
    const select = document.getElementById('reminderSelect');
    const value = select.value;
    const text = select.options[select.selectedIndex].text;
    
    if (value && !selectedRemindersList.some(r => r.value === value)) {
        if (selectedRemindersList.length >= 3) {
            alert('You can only select up to 3 reminder times.');
            select.value = '';
            return;
        }
        selectedRemindersList.push({ value: value, text: text });
        renderSelectedReminders();
    }
    select.value = '';
}

function removeReminderTime(value) {
    selectedRemindersList = selectedRemindersList.filter(r => r.value !== value);
    renderSelectedReminders();
}

function renderSelectedReminders() {
    const container = document.getElementById('selectedReminders');
    if (!container) return;
    container.innerHTML = selectedRemindersList.map(r => {
        return '<span class="reminder-tag">' + r.text + ' <button type="button" onclick="removeReminderTime(' + r.value + ')">×</button></span>';
    }).join('');
    const hiddenInput = document.getElementById('reminderTimes');
    if (hiddenInput) {
        hiddenInput.value = selectedRemindersList.map(r => r.value).join(',');
    }
}

function addStudent() {
    const select = document.getElementById('studentSelect');
    const studentId = select.value;
    if (studentId && !selectedStudentsList.includes(studentId)) {
        selectedStudentsList.push(studentId);
        renderSelectedStudents();
    }
    select.value = '';
}

function removeStudent(studentId) {
    selectedStudentsList = selectedStudentsList.filter(id => id !== studentId);
    renderSelectedStudents();
}

function renderSelectedStudents() {
    const container = document.getElementById('selectedStudents');
    if (!container) return;
    container.innerHTML = selectedStudentsList.map(id => {
        return '<span class="student-tag">' + getStudentName(id) + ' <button type="button" onclick="removeStudent(' + id + ')">×</button></span>';
    }).join('');
    const hiddenInput = document.getElementById('assignedStudents');
    if (hiddenInput) {
        hiddenInput.value = selectedStudentsList.join(',');
    }
}

function getStudentName(studentId) {
    const select = document.getElementById('studentSelect');
    if (!select) return 'Student ' + studentId;
    for (let i = 0; i < select.options.length; i++) {
        if (select.options[i].value === studentId) {
            return select.options[i].text.split(' (')[0];
        }
    }
    return 'Student ' + studentId;
}

// Update form submission to include reminder times
document.addEventListener('DOMContentLoaded', function() {
    const form = document.querySelector('form[action="add_deadline.php"]');
    if (form) {
        form.addEventListener('submit', function(e) {
            const checkboxes = document.querySelectorAll('#reminderCheckboxes input[type="checkbox"]:checked');
            const times = Array.from(checkboxes).map(cb => cb.value);
            const reminderTimesInput = document.getElementById('reminderTimes');
            if (reminderTimesInput) {
                reminderTimesInput.value = times.join(',');
            }
        });
    }
});

const taskItems = document.querySelectorAll('#taskList .task-item');
let selectedDate = '';
let viewYear;
let viewMonth;
const now = new Date();
viewYear = now.getFullYear();
viewMonth = now.getMonth();

const calTitle = document.getElementById('calTitle');
const calDays = document.getElementById('calDays');
const calPrev = document.getElementById('calPrev');
const calNext = document.getElementById('calNext');
const calClear = document.getElementById('calClear');
const calToday = document.getElementById('calToday');
const calendarStatusByDate = <?php echo json_encode($calendarStatusByDate); ?>;

function applyDateFilter() {
    taskItems.forEach((item) => {
        const itemDate = item.getAttribute('data-date');
        item.style.display = !selectedDate || selectedDate === itemDate ? '' : 'none';
    });
}

function formatDate(y, m, d) {
    const mm = String(m + 1).padStart(2, '0');
    const dd = String(d).padStart(2, '0');
    return `${y}-${mm}-${dd}`;
}

function renderCalendar() {
    calDays.innerHTML = '';
    const firstDay = new Date(viewYear, viewMonth, 1);
    const startWeekday = firstDay.getDay();
    const daysInMonth = new Date(viewYear, viewMonth + 1, 0).getDate();

    calTitle.textContent = firstDay.toLocaleString('en-US', { month: 'long', year: 'numeric' });

    for (let i = 0; i < startWeekday; i++) {
        const blank = document.createElement('button');
        blank.type = 'button';
        blank.className = 'cal-day muted';
        blank.disabled = true;
        blank.textContent = '';
        calDays.appendChild(blank);
    }

    const today = new Date();
    const todayStr = formatDate(today.getFullYear(), today.getMonth(), today.getDate());

    for (let d = 1; d <= daysInMonth; d++) {
        const btn = document.createElement('button');
        btn.type = 'button';
        btn.className = 'cal-day';
        const dateStr = formatDate(viewYear, viewMonth, d);
        btn.textContent = d;
        const status = calendarStatusByDate[dateStr];
        if (status === 'past_due') btn.classList.add('status-past_due');
        if (status === 'upcoming') btn.classList.add('status-upcoming');
        if (status === 'completed') btn.classList.add('status-completed');
        if (dateStr === selectedDate) btn.classList.add('active');
        if (dateStr === todayStr) btn.classList.add('today');
        btn.addEventListener('click', () => {
            selectedDate = dateStr;
            applyDateFilter();
            renderCalendar();
        });
        calDays.appendChild(btn);
    }
}

calPrev.addEventListener('click', () => {
    viewMonth--;
    if (viewMonth < 0) {
        viewMonth = 11;
        viewYear--;
    }
    renderCalendar();
});

calNext.addEventListener('click', () => {
    viewMonth++;
    if (viewMonth > 11) {
        viewMonth = 0;
        viewYear++;
    }
    renderCalendar();
});

calClear.addEventListener('click', () => {
    selectedDate = '';
    applyDateFilter();
    renderCalendar();
});

calToday.addEventListener('click', () => {
    const t = new Date();
    viewYear = t.getFullYear();
    viewMonth = t.getMonth();
    selectedDate = formatDate(viewYear, viewMonth, t.getDate());
    applyDateFilter();
    renderCalendar();
});

renderCalendar();
</script>
</body>
</html>
