<?php
session_start();
include "../config/db.php";

// Check if admin
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] != 'admin') {
    header("Location: ../auth/login.php");
    exit;
}

$action = isset($_GET['action']) ? $_GET['action'] : '';
$result = null;

if ($action === 'check_reminders') {
    // Call check_reminders endpoint
    $ch = curl_init("http://localhost/cbuzz/api/check_reminders.php");
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 30);
    $response = curl_exec($ch);
    curl_close($ch);
    $result = json_decode($response, true);
}

// Get statistics
$deadlineCount = 0;
$deadlineRes = $conn->query("SELECT COUNT(*) as cnt FROM deadlines");
if ($deadlineRes) {
    $row = $deadlineRes->fetch_assoc();
    $deadlineCount = (int)$row['cnt'];
}

$upcomingCount = 0;
$now = date('Y-m-d H:i:s');
$upcomingRes = $conn->query("SELECT COUNT(*) as cnt FROM deadlines WHERE deadline_datetime > '$now'");
if ($upcomingRes) {
    $row = $upcomingRes->fetch_assoc();
    $upcomingCount = (int)$row['cnt'];
}

$tokenCount = 0;
$tokenRes = $conn->query("SELECT COUNT(*) as cnt FROM fcm_tokens");
if ($tokenRes) {
    $row = $tokenRes->fetch_assoc();
    $tokenCount = (int)$row['cnt'];
}

// Get recent reminders
$recentReminders = [];
$remindersRes = $conn->query("
    SELECT drl.*, d.title
    FROM deadline_reminder_logs drl
    LEFT JOIN deadlines d ON d.id = drl.deadline_id
    ORDER BY drl.sent_at DESC
    LIMIT 20
");
if ($remindersRes) {
    while ($row = $remindersRes->fetch_assoc()) {
        $recentReminders[] = $row;
    }
}

// Get upcoming deadlines
$upcomingDeadlines = [];
$upcomingDeadlinesRes = $conn->query("
    SELECT id, title, deadline_datetime
    FROM deadlines
    WHERE deadline_datetime > NOW()
    ORDER BY deadline_datetime ASC
    LIMIT 10
");
if ($upcomingDeadlinesRes) {
    while ($row = $upcomingDeadlinesRes->fetch_assoc()) {
        $upcomingDeadlines[] = $row;
    }
}

// Read scheduler log
$schedulerLog = [];
$logFile = __DIR__ . '/../logs/scheduler.log';
if (file_exists($logFile)) {
    $lines = array_reverse(file($logFile));
    $schedulerLog = array_slice($lines, 0, 20);
}

$remindersLog = [];
$logFile = __DIR__ . '/../logs/reminders.log';
if (file_exists($logFile)) {
    $lines = array_reverse(file($logFile));
    $remindersLog = array_slice($lines, 0, 20);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Reminder Scheduler - Classbuzz</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Sora:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<style>
:root {
    --bg: #f4f6f8;
    --surface: #ffffff;
    --text: #1e2228;
    --muted: #5d6674;
    --brand: #cfa430;
    --ink: #101216;
    --line: #e6e9ef;
    --success: #2f7a46;
    --warning: #8f5e12;
    --danger: #d94d4d;
}
* { box-sizing: border-box; margin: 0; padding: 0; }
body {
    font-family: "Sora", sans-serif;
    background: var(--bg);
    color: var(--text);
    min-height: 100vh;
}
.topbar {
    background: var(--surface);
    border-bottom: 1px solid var(--line);
    padding: 16px 24px;
    display: flex;
    justify-content: space-between;
    align-items: center;
}
.logo {
    font-weight: 700;
    font-size: 20px;
    color: var(--ink);
}
.container {
    max-width: 1400px;
    margin: 24px auto;
    padding: 0 16px;
}
h1 {
    font-size: 28px;
    margin-bottom: 24px;
}
.grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 16px;
    margin-bottom: 24px;
}
.stat-card {
    background: var(--surface);
    border: 1px solid var(--line);
    border-radius: 12px;
    padding: 20px;
}
.stat-card h3 {
    font-size: 12px;
    color: var(--muted);
    text-transform: uppercase;
    letter-spacing: 0.1em;
    margin-bottom: 8px;
}
.stat-card .value {
    font-size: 32px;
    font-weight: 700;
    color: var(--ink);
}
.actions {
    display: flex;
    gap: 8px;
    margin-bottom: 24px;
    flex-wrap: wrap;
}
.btn {
    padding: 10px 16px;
    border: none;
    border-radius: 8px;
    font-weight: 600;
    cursor: pointer;
    font-family: inherit;
    font-size: 14px;
    text-decoration: none;
    display: inline-block;
}
.btn-primary {
    background: var(--brand);
    color: #1f180a;
}
.btn-primary:hover {
    background: #b8932a;
}
.btn-secondary {
    background: var(--surface);
    border: 1px solid var(--line);
    color: var(--text);
}
.btn-secondary:hover {
    border-color: var(--brand);
}
.section {
    background: var(--surface);
    border: 1px solid var(--line);
    border-radius: 12px;
    padding: 20px;
    margin-bottom: 24px;
}
.section h2 {
    font-size: 18px;
    margin-bottom: 16px;
    padding-bottom: 12px;
    border-bottom: 1px solid var(--line);
}
.result {
    background: #f9fafb;
    border: 1px solid var(--line);
    border-radius: 8px;
    padding: 12px;
    margin-bottom: 16px;
    font-family: monospace;
    font-size: 12px;
    max-height: 200px;
    overflow-y: auto;
}
.result pre {
    margin: 0;
    white-space: pre-wrap;
    word-wrap: break-word;
}
table {
    width: 100%;
    border-collapse: collapse;
}
th {
    background: #f9fafb;
    padding: 12px;
    text-align: left;
    font-weight: 600;
    font-size: 12px;
    color: var(--muted);
    text-transform: uppercase;
    letter-spacing: 0.05em;
    border-bottom: 1px solid var(--line);
}
td {
    padding: 12px;
    border-bottom: 1px solid var(--line);
    font-size: 13px;
}
tr:last-child td {
    border-bottom: none;
}
.badge {
    display: inline-block;
    padding: 4px 8px;
    border-radius: 4px;
    font-size: 11px;
    font-weight: 600;
}
.badge-success {
    background: #e7f7ec;
    color: var(--success);
}
.badge-warning {
    background: #fff5db;
    color: var(--warning);
}
.badge-danger {
    background: #ffe7e7;
    color: var(--danger);
}
.empty {
    text-align: center;
    padding: 24px;
    color: var(--muted);
}
.log-line {
    font-family: monospace;
    font-size: 11px;
    padding: 4px 0;
    border-bottom: 1px solid #f0f0f0;
    color: #666;
}
.log-line:last-child {
    border-bottom: none;
}
.info-box {
    background: #e8f4f8;
    border-left: 4px solid #0288d1;
    padding: 12px;
    border-radius: 4px;
    margin-bottom: 16px;
    font-size: 13px;
    color: #01579b;
}
</style>
</head>
<body>

<header class="topbar">
    <div class="logo">Classbuzz - Reminder Scheduler</div>
    <a href="dashboard.php" style="color: var(--muted); text-decoration: none;">← Back to Dashboard</a>
</header>

<div class="container">
    <h1>Automatic Reminder Scheduler</h1>

    <div class="info-box">
        ℹ️ The scheduler automatically checks for upcoming deadlines every 5 minutes and sends push notifications to all registered devices.
    </div>

    <div class="grid">
        <div class="stat-card">
            <h3>Total Deadlines</h3>
            <div class="value"><?php echo $deadlineCount; ?></div>
        </div>
        <div class="stat-card">
            <h3>Upcoming</h3>
            <div class="value"><?php echo $upcomingCount; ?></div>
        </div>
        <div class="stat-card">
            <h3>Registered Devices</h3>
            <div class="value"><?php echo $tokenCount; ?></div>
        </div>
        <div class="stat-card">
            <h3>Recent Reminders</h3>
            <div class="value"><?php echo count($recentReminders); ?></div>
        </div>
    </div>

    <div class="actions">
        <a href="?action=check_reminders" class="btn btn-primary">Check Reminders Now</a>
        <a href="../api/diagnose_push.php" class="btn btn-secondary" target="_blank">Run Diagnostics</a>
        <a href="../SCHEDULER_SETUP.md" class="btn btn-secondary" target="_blank">Setup Guide</a>
    </div>

    <?php if ($result): ?>
        <div class="section">
            <h2>Last Check Result</h2>
            <div class="result">
                <pre><?php echo json_encode($result, JSON_PRETTY_PRINT); ?></pre>
            </div>
        </div>
    <?php endif; ?>

    <div class="section">
        <h2>Upcoming Deadlines</h2>
        <?php if (count($upcomingDeadlines) === 0): ?>
            <div class="empty">No upcoming deadlines.</div>
        <?php else: ?>
            <table>
                <thead>
                    <tr>
                        <th>Title</th>
                        <th>Due Date</th>
                        <th>Time Until Due</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($upcomingDeadlines as $deadline): ?>
                        <?php
                        $dueTime = strtotime($deadline['deadline_datetime']);
                        $now = time();
                        $diff = $dueTime - $now;
                        
                        if ($diff > 86400) {
                            $timeStr = ceil($diff / 86400) . ' days';
                        } elseif ($diff > 3600) {
                            $timeStr = ceil($diff / 3600) . ' hours';
                        } else {
                            $timeStr = ceil($diff / 60) . ' minutes';
                        }
                        ?>
                        <tr>
                            <td><?php echo htmlspecialchars($deadline['title']); ?></td>
                            <td><?php echo htmlspecialchars($deadline['deadline_datetime']); ?></td>
                            <td><?php echo $timeStr; ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>

    <div class="section">
        <h2>Recent Reminders Sent</h2>
        <?php if (count($recentReminders) === 0): ?>
            <div class="empty">No reminders sent yet.</div>
        <?php else: ?>
            <table>
                <thead>
                    <tr>
                        <th>Deadline</th>
                        <th>Reminder Type</th>
                        <th>Sent</th>
                        <th>Failed</th>
                        <th>Sent At</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($recentReminders as $reminder): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($reminder['title'] ?? 'Unknown'); ?></td>
                            <td><span class="badge badge-warning"><?php echo htmlspecialchars($reminder['reminder_type']); ?></span></td>
                            <td><span class="badge badge-success"><?php echo (int)$reminder['sent_count']; ?></span></td>
                            <td><?php echo (int)$reminder['failed_count'] > 0 ? '<span class="badge badge-danger">' . (int)$reminder['failed_count'] . '</span>' : '0'; ?></td>
                            <td><?php echo htmlspecialchars($reminder['sent_at']); ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>

    <div class="section">
        <h2>Scheduler Logs</h2>
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 16px;">
            <div>
                <h3 style="font-size: 14px; margin-bottom: 8px;">Reminders Log</h3>
                <div class="result" style="max-height: 300px;">
                    <?php if (count($remindersLog) === 0): ?>
                        <div style="color: var(--muted);">No logs yet</div>
                    <?php else: ?>
                        <?php foreach ($remindersLog as $line): ?>
                            <div class="log-line"><?php echo htmlspecialchars(trim($line)); ?></div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>
            <div>
                <h3 style="font-size: 14px; margin-bottom: 8px;">Scheduler Log</h3>
                <div class="result" style="max-height: 300px;">
                    <?php if (count($schedulerLog) === 0): ?>
                        <div style="color: var(--muted);">No logs yet</div>
                    <?php else: ?>
                        <?php foreach ($schedulerLog as $line): ?>
                            <div class="log-line"><?php echo htmlspecialchars(trim($line)); ?></div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <div class="section">
        <h2>Setup Instructions</h2>
        <p style="margin-bottom: 12px;">To enable automatic reminders, set up a scheduled task:</p>
        <ul style="margin-left: 20px; margin-bottom: 12px;">
            <li><strong>Windows:</strong> Use Task Scheduler to run the scheduler every 5 minutes</li>
            <li><strong>Linux/Mac:</strong> Add a cron job: <code>*/5 * * * * /usr/bin/php /path/to/cbuzz/api/scheduler.php</code></li>
        </ul>
        <p><a href="../SCHEDULER_SETUP.md" target="_blank" class="btn btn-secondary">View Full Setup Guide</a></p>
    </div>
</div>

</body>
</html>
