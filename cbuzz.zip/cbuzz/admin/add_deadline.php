<?php
session_start();
include "../config/db.php";

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: dashboard.php");
    exit;
}

$title = isset($_POST['title']) ? trim($_POST['title']) : '';
$desc = isset($_POST['description']) ? trim($_POST['description']) : '';
$deadline = isset($_POST['deadline']) ? trim($_POST['deadline']) : '';

// Get selected reminder times (comma-separated)
$reminderTimes = isset($_POST['reminder_times']) ? $_POST['reminder_times'] : '';

// Get assigned students (comma-separated string or array)
$assignedStudentsInput = isset($_POST['assigned_students']) ? $_POST['assigned_students'] : '';
if (is_string($assignedStudentsInput) && strpos($assignedStudentsInput, ',') !== false) {
    $assignedStudents = array_filter(array_map('trim', explode(',', $assignedStudentsInput)));
} elseif (is_array($assignedStudentsInput)) {
    $assignedStudents = array_filter(array_map('intval', $assignedStudentsInput));
} else {
    $assignedStudents = [];
}

if ($title === '' || $deadline === '') {
    $_SESSION['flash_error'] = "Title and deadline are required.";
    header("Location: dashboard.php");
    exit;
}

$stmt = $conn->prepare("
    INSERT INTO deadlines (title, description, deadline_datetime)
    VALUES (?, ?, ?)
");
$stmt->bind_param("sss", $title, $desc, $deadline);
$ok = $stmt->execute();

if (!$ok) {
    $_SESSION['flash_error'] = "Failed to add deadline. Please try again.";
    header("Location: dashboard.php");
    exit;
}

$deadlineId = $conn->insert_id;

// Save custom reminder settings (if the table exists)
if ($reminderTimes !== '') {
    $tableCheck = $conn->query("SHOW TABLES LIKE 'deadline_reminder_settings'");
    if ($tableCheck && $tableCheck->num_rows > 0) {
        $times = explode(',', $reminderTimes);
        foreach ($times as $minutes) {
            $minutes = (int)trim($minutes);
            if ($minutes > 0) {
                $reminderStmt = $conn->prepare("
                    INSERT INTO deadline_reminder_settings (deadline_id, reminder_minutes)
                    VALUES (?, ?)
                    ON DUPLICATE KEY UPDATE reminder_minutes = VALUES(reminder_minutes)
                ");
                $reminderStmt->bind_param("ii", $deadlineId, $minutes);
                $reminderStmt->execute();
            }
        }
    }
}

// Save student assignments (if the table exists)
if (!empty($assignedStudents)) {
    $tableCheck = $conn->query("SHOW TABLES LIKE 'deadline_assignments'");
    if ($tableCheck && $tableCheck->num_rows > 0) {
        foreach ($assignedStudents as $studentId) {
            $studentId = (int)$studentId;
            if ($studentId > 0) {
                $assignStmt = $conn->prepare("
                    INSERT INTO deadline_assignments (deadline_id, student_id)
                    VALUES (?, ?)
                    ON DUPLICATE KEY UPDATE student_id = VALUES(student_id)
                ");
                $assignStmt->bind_param("ii", $deadlineId, $studentId);
                $assignStmt->execute();
            }
        }
    }
}

// Send email immediately
include "../api/send_email.php";

$_SESSION['flash_success'] = "Deadline added successfully.";
header("Location: dashboard.php");
exit;
?>
