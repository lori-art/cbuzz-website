# 🔔 Push Notifications & Scheduler Setup - Complete Guide

## 📖 Documentation Index

### 🚀 Start Here
- **SCHEDULER_SETUP_COMPLETE.md** - Overview and quick start guide

### 🪟 Windows Users
- **WINDOWS_TASK_SCHEDULER_GUIDE.md** - Step-by-step Windows setup (10 min)

### 🍎 Mac & 🐧 Linux Users
- **LINUX_MAC_CRON_GUIDE.md** - Step-by-step Mac/Linux setup (5 min)

### 📚 Reference
- **SCHEDULER_INSTALLATION.md** - Detailed technical reference
- **SCHEDULER_DOCUMENTATION.md** - Complete documentation index

---

## ⚡ Quick Start (Choose Your Platform)

### Windows (10 minutes)
1. Open: **WINDOWS_TASK_SCHEDULER_GUIDE.md**
2. Follow steps 1-11
3. Done! ✅

### Mac or Linux (5 minutes)
1. Open: **LINUX_MAC_CRON_GUIDE.md**
2. Follow steps 1-8
3. Done! ✅

---

## 🎯 What You're Setting Up

**Automatic push notifications** that remind you about upcoming deadlines.

### How It Works
- Scheduler runs every 5 minutes
- Checks for upcoming deadlines
- Sends notifications at: 24h, 12h, 1h, 30m before deadline
- Works even when you're not using the app

### What Gets Installed
- **Windows:** Task in Task Scheduler
- **Mac/Linux:** Cron job in crontab

---

## ✅ Prerequisites

Before starting, verify:

- [ ] XAMPP is running (Apache and MySQL)
- [ ] Database tables created: `http://localhost/cbuzz/api/setup_push.php`
- [ ] Device registered: See "Push: Connected" on student dashboard
- [ ] At least one deadline exists in database

---

## 📋 Setup Checklist

### Phase 1: Database (Already Done)
- [x] Tables created
- [x] Service account configured
- [x] Firebase connected

### Phase 2: Device Registration (Already Done)
- [x] Student dashboard shows "Push: Connected"
- [x] Notifications permission granted

### Phase 3: Scheduler Setup (Do This Now)
- [ ] Choose your platform (Windows, Mac, or Linux)
- [ ] Follow the setup guide
- [ ] Verify scheduler is running
- [ ] Test with a deadline

---

## 🔧 Setup by Platform

### Windows Task Scheduler
**File:** WINDOWS_TASK_SCHEDULER_GUIDE.md

**Quick Setup:**
1. Open Task Scheduler
2. Create Basic Task
3. Name: "Classbuzz Reminder Scheduler"
4. Trigger: Daily, repeat every 5 minutes
5. Action: Run `C:\xampp\php\php.exe` with arguments `C:\xampp\htdocs\cbuzz\api\scheduler.php`
6. Check "Run whether user is logged in or not"
7. Done!

### Linux/Mac Cron
**File:** LINUX_MAC_CRON_GUIDE.md

**Quick Setup:**
1. Open Terminal
2. Run: `crontab -e`
3. Add line: `*/5 * * * * /usr/bin/php /var/www/html/cbuzz/api/scheduler.php >> /var/www/html/cbuzz/logs/cron.log 2>&1`
4. Save and exit
5. Done!

---

## 🧪 Verify It Works

After setup:

1. **Check logs:**
   - Windows: `C:\xampp\htdocs\cbuzz\logs\scheduler.log`
   - Linux/Mac: `/var/www/html/cbuzz/logs/scheduler.log`

2. **Create test deadline:**
   - Set for 35 minutes from now
   - Wait 5 minutes
   - Check for notification

3. **Visit admin panel:**
   - `http://localhost/cbuzz/admin/scheduler.php`
   - Should show recent reminders

---

## 🐛 Troubleshooting

### Scheduler doesn't run
- **Windows:** Check "Run whether user is logged in or not"
- **Linux/Mac:** Check cron service: `sudo service cron status`

### Nothing happens
- Check logs: `logs/scheduler.log`
- Run diagnostics: `http://localhost/cbuzz/api/diagnose_push.php`
- Verify database has deadlines

### No notifications
- Verify device is registered (see "Push: Connected")
- Check if deadline is within reminder window
- Check logs for errors

---

## 📊 Reminder Schedule

| Reminder | Time Before Deadline |
|----------|---------------------|
| 1st | 24 hours |
| 2nd | 12 hours |
| 3rd | 1 hour |
| 4th | 30 minutes |

---

## 🔗 Quick Links

| Purpose | URL |
|---------|-----|
| Setup Database | `http://localhost/cbuzz/api/setup_push.php` |
| Run Diagnostics | `http://localhost/cbuzz/api/diagnose_push.php` |
| Admin Panel | `http://localhost/cbuzz/admin/scheduler.php` |
| Student Dashboard | `http://localhost/cbuzz/student/dashboard.php` |

---

## 📚 All Documentation Files

### Setup Guides
- `SCHEDULER_SETUP_COMPLETE.md` - Overview and quick start
- `WINDOWS_TASK_SCHEDULER_GUIDE.md` - Windows detailed guide
- `LINUX_MAC_CRON_GUIDE.md` - Linux/Mac detailed guide
- `SCHEDULER_INSTALLATION.md` - Technical reference

### Push Notifications
- `PUSH_NOTIFICATIONS_QUICK_START.md` - Quick start guide
- `PUSH_SETUP_GUIDE.md` - Troubleshooting guide
- `README_PUSH_NOTIFICATIONS.md` - Overview
- `IMPLEMENTATION_COMPLETE.md` - Technical summary

### Checklists
- `SETUP_CHECKLIST.md` - Step-by-step checklist

---

## ⏱️ Time Estimates

| Task | Time |
|------|------|
| Windows setup | 10 minutes |
| Linux/Mac setup | 5 minutes |
| Verification | 5 minutes |
| Testing | 10 minutes |
| **Total** | **15-30 minutes** |

---

## 🎯 Next Steps

1. **Choose your platform:**
   - Windows → WINDOWS_TASK_SCHEDULER_GUIDE.md
   - Mac/Linux → LINUX_MAC_CRON_GUIDE.md

2. **Follow the setup guide** (10-15 minutes)

3. **Verify it works:**
   - Check logs
   - Create test deadline
   - Receive notification

4. **Monitor regularly:**
   - Check admin panel
   - Review logs

---

## ✨ Success Indicators

You'll know it's working when:

✅ Scheduler runs every 5 minutes (check logs)
✅ Reminders are triggered for upcoming deadlines
✅ Notifications appear on your device
✅ Admin panel shows recent reminders
✅ No errors in logs

---

## 📞 Support

**Need help?**

1. Check the setup guide for your platform
2. Run diagnostics: `http://localhost/cbuzz/api/diagnose_push.php`
3. Check logs: `logs/scheduler.log`
4. Visit admin panel: `http://localhost/cbuzz/admin/scheduler.php`

---

## 🎉 You're Ready!

Everything is set up and documented. 

**Choose your platform and follow the guide.**

Your push notification system will automatically remind you about upcoming deadlines!

---

## 📋 File Structure

```
cbuzz/
├── SCHEDULER_SETUP_COMPLETE.md          ← Start here
├── WINDOWS_TASK_SCHEDULER_GUIDE.md      ← Windows users
├── LINUX_MAC_CRON_GUIDE.md              ← Mac/Linux users
├── SCHEDULER_INSTALLATION.md            ← Technical reference
├── SCHEDULER_DOCUMENTATION.md           ← Documentation index
├── PUSH_NOTIFICATIONS_QUICK_START.md
├── PUSH_SETUP_GUIDE.md
├── README_PUSH_NOTIFICATIONS.md
├── IMPLEMENTATION_COMPLETE.md
├── SETUP_CHECKLIST.md
├── api/
│   ├── scheduler.php                    ← Scheduler script
│   ├── check_reminders.php
│   ├── send_push.php
│   └── ...
├── admin/
│   ├── scheduler.php                    ← Admin panel
│   └── ...
└── logs/
    ├── scheduler.log                    ← Scheduler logs
    ├── reminders.log
    ├── push_tokens.log
    └── push_send.log
```

---

**Start with SCHEDULER_SETUP_COMPLETE.md or choose your platform guide above!** 🚀
